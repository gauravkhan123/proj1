<?php
/**
 * Plugin Name:       Mapbox Customize
 * Plugin URI:        https://tedsvintageart.com/plugins/mapbox-customize/
 * Description:       Handle the customize of the map.
 * Version:           1.10.3
 * Author:            Sachin Parmar
 * Author URI:        https://author.tedsvintageart.com/
 */
function enqueue_my_scripts()
{

    global $wp;
    $url = home_url($wp->request);
    if (strpos($url, 'mapbox') !== false || strpos($url, 'starmap') !== false) {
        wp_enqueue_style('bootstrapCss', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');
        wp_enqueue_script('mapboxScript');
		wp_enqueue_script('mapboxD3', plugin_dir_url(__FILE__) . 'js/d3.min.js', array('jquery'), rand(1, 1000));
        wp_enqueue_script('mapboxProjection', plugin_dir_url(__FILE__) . 'js/d3.geo.projection.min.js', array('jquery'), rand(1, 1000));
        wp_enqueue_script('mapboxCelestial', plugin_dir_url(__FILE__) . 'js/celestial.js', array('jquery'), rand(1, 1000));
        wp_enqueue_script('mapboxScript', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), rand(1, 1000));
        wp_enqueue_script('mapboxScriptFont', plugin_dir_url(__FILE__) . 'js/script-font.js', array('jquery'), rand(1, 1000));


        wp_localize_script('mapboxScript', 'flatsomeVars', array('ajaxurl' => admin_url('admin-ajax.php')));

        wp_enqueue_script('mapboxGlScript', 'https://api.mapbox.com/mapbox-gl-js/v1.6.1/mapbox-gl.js');
        wp_enqueue_script('mapboxgeocoderScript', 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.2/mapbox-gl-geocoder.min.js');
        wp_enqueue_script('mapboxpromiseScript', 'https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.min.js');
        wp_enqueue_script('mapboxpromiseautoScript', 'https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js');
        wp_enqueue_script('bootstrapScript', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
        wp_enqueue_script('ajaxScript', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
        wp_enqueue_script('html2Canvas', 'https://html2canvas.hertzen.com/dist/html2canvas.js');
        wp_enqueue_script('momentJs', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js');
        wp_enqueue_script('timeJs', 'https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js');
        wp_enqueue_script('fabricCss', 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/4.0.0/fabric.js');
        wp_enqueue_style('fontawesomeCss', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
        wp_enqueue_style('timeCss', 'https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css');
        wp_enqueue_style('mapboxCss', plugin_dir_url(__FILE__) . 'css/style.css', array(), rand(1, 1000));
        wp_enqueue_style('mapboxCelestial', plugin_dir_url(__FILE__) . 'css/celestial.css', array(), rand(1, 1000));
    }

}

add_action('wp_enqueue_scripts', 'enqueue_my_scripts');

function style_script()
{
    global $wp;
    $url = home_url($_SERVER['REQUEST_URI']);

    if (strpos($url, 'style_plugin_options') !== false || strpos($url, 'style-lists') !== false) {
        wp_enqueue_script('mapboxScript');
        wp_enqueue_script('mapboxScript', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), rand(1, 1000));
        wp_enqueue_script('mapboxGlScript', 'https://api.mapbox.com/mapbox-gl-js/v1.6.1/mapbox-gl.js');
        wp_enqueue_script('mapboxgeocoderScript', 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v4.4.2/mapbox-gl-geocoder.min.js');
        wp_enqueue_script('mapboxpromiseScript', 'https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.min.js');
        wp_enqueue_script('mapboxpromiseautoScript', 'https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js');
        wp_enqueue_script('bootstrapScript', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
        wp_enqueue_style('mapboxCss', plugin_dir_url(__FILE__) . '/css/style.css');
    }
}

add_action('admin_enqueue_scripts', 'style_script');

function custom_style_table_install()
{
    global $wpdb;
    $custom_style_table_install_db_version = '1.10.3';
    $charset_collate = $wpdb->get_charset_collate();

    $table_name = $wpdb->prefix . 'style_design'; // do not forget about tables prefix

    $sql = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
			id int(11) NOT NULL AUTO_INCREMENT,
			style_image LONGTEXT NOT NULL,
			value VARCHAR(100) NULL,
			label VARCHAR(100) NULL,
			water VARCHAR(100) NULL,
			building VARCHAR(100) NULL,
			style_name VARCHAR(255) NULL,
			style_id VARCHAR(255) NULL,
			landuse VARCHAR(255) NULL,
			longitude FLOAT NULL,
			latitude FLOAT NULL,
			zoom FLOAT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NULL,
			PRIMARY KEY  (id)
			) " . $charset_collate . ";";

    // $wpdb->query($sql);
    // we do not execute sql directly
    // we are calling dbDelta which cant migrate database
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    add_option('custom_style_table_db_version', $custom_style_table_install_db_version);
}

register_activation_hook(__FILE__, 'custom_style_table_install');
add_action( 'wp_ajax_star_map',        'star_map_callback' );
add_action( 'wp_ajax_nopriv_star_map', 'star_map_callback' );
function star_map_callback(){
	wp_send_json_success(array(
      'text' => 'Added star map'
    ));
	die();
}
add_shortcode('starmap', 'starmap_shortcode');
function starmap_shortcode(){
?>
<script>
var pluginUrl = '<?php echo plugin_dir_url(__FILE__) ?>' ;
</script>
<?php
ob_start();
require plugin_dir_path( __FILE__ ) . 'inc/starmap.php';
return ob_get_clean();
}

add_shortcode('mapbox', 'mapbox_shortcode');

function mapbox_shortcode()
{
		?>
	<script>
	var pluginUrl = '<?php echo plugin_dir_url(__FILE__) ?>' ;
	</script>
	<?php
    global $wpdb;
    $table_name = $wpdb->prefix . 'style_design';
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id desc");
    $currency = wc_price(59.99);

    $output = '
	<div class="container outer">
		<div class="row customize-tab">
			<div class="col-md-7 col-lg-7 maxMapHeight mobileView">

			</div>
			<div class="col-md-5 col-lg-5 map-left mapbox-sidebar">
				<div id="sidebar-info">
					<span><strong>Customize your design</strong>
						Change location, labels and appearance
					</span>
				</div>
				<div id="sidebar" class="sidebar">
					<div class="sidebar-group active">
						<div class="sidebar-group-header"><h2 class="title">Location and date</h2></div>
						<div class="sidebar-group-content">
							<div id="geocoder" class="geocoder"></div>
							<div class="field-date" id="date_form">
								<div class="date-inputs">
									<input name="day" data-starmap-input-date class="date-input-1 datte" placeholder="Day" type="number" value="17" min="1" max="31">
									<select name="month" data-starmap-input-date class="date-input-2 monnth">
										<option value="0">January</option>
										<option value="1">February</option>
										<option value="2">March</option>
										<option value="3">April</option>
										<option value="4">May</option>
										<option value="5">June</option>
										<option value="6">July</option>
										<option value="7">August</option>
										<option value="8">September</option>
										<option value="9">October</option>
										<option value="10">November</option>
										<option value="11">December</option>
									</select>
									<input name="year" data-starmap-input-date class="date-input-3 yearr" placeholder="Year" type="number" min="1000" max="9999">
								</div>
							</div>
							<div class="time-row">
								<div class="field-time">
									<h5>Time</h5>
									<input type="text" id="timepicker" placeholder="12:00 AM" />
								</div>
								<div class="field-checkbox">
									<h5>Print Time</h5>
									<div class="editor-btns small">
										<div>
											<div data-timemap="time" data-value="on" class="time_label active">
												ON
											</div>
										</div>

										<div> 
											<div data-timemap="time" data-value="off" class="time_label">
												OFF
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="sidebar-group">
						<div class="sidebar-group-header"><h2 class="title">Customize the style</h2></div>
						<div class="sidebar-group-content">
							<div class="options" data-single="">';
								$default='<div class="color-btn ">
										<div class="layout-light map-style-layout style1 active">
												<div style="background-image: url(' . plugin_dir_url(__FILE__) . 'images/style-light.jpg)">
												</div>
												<span class="text-label">
													   Light
												</span>
												<span class="tick">
												</span>
										</div>
									</div>
									<div class="color-btn">
										<div class="layout-dark map-style-layout">
												<div style="background-image: url(' . plugin_dir_url(__FILE__) . 'images/black.png)">
												</div>
												<span class="text-label">
													   Dark
												</span>
												<span class="tick">
												</span>
										</div>
									</div>';
									if (!empty($results)) {
										foreach ($results as $key => $value) {
											if (strlen($value->style_name) > 6)
												$name = substr($value->style_name, 0, 6) . '...';
											else
												$name = $value->style_name;
											if ($key == 0) {
												$default .= '<div class="color-btn ">
																<div data-citymap="style" data-styles="' . $value->style_id . '" data-value="' . $value->value . '" data-styles="' . $value->style_id . '" data-label="' . $value->label . '" data-holo="#000" data-water="' . $value->water . '" data-building="' . $value->building . '" data-landuse="' . $value->landuse . '" class="styles-essentials style1 map-style-layout">
																		<div style="background-image: url(' . $value->style_image . ')">
																		</div>
																		<span class="text-label">
																				' . ucfirst($name) . '
																		</span>
																		<span class="tick">
																		</span>
																</div>
															</div>';
											} else {
												$default .= '<div class="color-btn ">
																<div data-citymap="style" data-styles="' . $value->style_id . '" data-value="' . $value->value . '" data-styles="' . $value->style_id . '" data-label="' . $value->label . '" data-holo="#000" data-water="' . $value->water . '" data-building="' . $value->building . '" class="styles-essentials map-style-layout">
																		<div style="background-image: url(' . $value->style_image . ')">
																		</div>
																		<span class="text-label">
																				' . ucfirst($name) . '
																		</span>
																		<span class="tick">
																		</span>
																</div>
															</div>';
											}
										}
									} else {
										/* $output .= '<div class="color-btn ">
						                           No Style Found.
										</div>'; */
							}
							$output .=$default;
							$output .= '</div>
							<div class="style-options-wrap" style="display: none;">
								<div class="style-item constellations-input">
									<label class="item_label">Constellations</label>
									<div class="item_content">
										<div role="switch" class="el-switch item-switch constellations-swich">
											<input type="checkbox" name="" true-value="true" class="switch_input">
											<span class="switch_core" style="width: 40px;"></span>
										</div>
									</div>
								</div>
								<div class="style-item">
									<label class="item_label">Enable grid</label>
									<div class="item_content"">
										<div role="switch" class="item-switch el-switch grid-swich">
											<input type="checkbox" name="" true-value="true" class="switch_input">
											<span class="switch_core" style="width: 40px;"></span>
										</div>
									</div>
								</div>
							</div>';
    $output .= '</div>
				</div>
					<div class="sidebar-group">
						<div class="sidebar-group-header">
							<h2 class="title">Customize the text</h2>
						</div>
						<div class="sidebar-group-content">
							<h5>Title</h5>
							<input type="text" class="title-customize title-cus" placeholder="Titel" value="The Windy City" maxlength="100">
							<h5>Subtitle</h5>
							<input type="text" class="title-customize subtitle-customize" placeholder="Subtitel" value="Chicago, Illinois" maxlength="100">
							<h5>Message</h5>
							<input class="message-customize" maxlength="180" name="text" placeholder="Message">
							<input type="text" class="title-customize tagline-customize" hidden placeholder="
							" value="-87.74838796981078 / 41.909905163235294" maxlength="150">
							
						</div>
					</div>
					<div class="sidebar-group">
						<div class="sidebar-group-header">
							<h2 class="title">Select Print Size and Add on a Frame</h2>
						</div>
						<div class="sidebar-group-content">
							<div class="row col-md-12 col-lg-12 hidden" >
								<!--<h5>Font Size</h5>
								<select class="fontSizeChange">';

								$output .= '<option value="small" selected>Small</option>';
								$output .= '<option value="medium">Medium</option>';
								$output .= '<option value="large">Large</option>';
								$output .= '</select>-->

							</div>
							<div class="row col-md-12 col-lg-12" style="display: none">
								<h5>Oriëntatie </h5>							
								<div class="editor-btns small">
									<div>
										<div data-citymap="orientation" data-value="portrait" class="active orientation_finalize orientation-portrait">
											Staand
										</div>
									</div>
									<div>
										<div data-citymap="orientation" data-value="landscape" class="orientation_finalize orientation-landscape">
											Liggend
										</div>
									</div>
								</div>
							</div>
							<div class="row col-md-12 col-lg-12">
								<h5>List</h5>
								<div class="editor-btns small">
                                <div>
                                <div data-citymap="frame" data-value="black" class="frame_finalize frame-black">
                                40X50cm 
                                </div>
                            </div>
                            <div>
                                <div data-citymap="frame" data-value="white" class="frame_finalize frame-white">
                                50X70cm
                                </div>
                            </div>
                            <!--<div>
                                <div data-citymap="frame" data-value="non" class="frame_finalize frame-non active padding25px">
                                    Geen<br>
                                </div>
                            </div>
                            <div>
                                <div data-citymap="frame" data-value="black" class="frame_finalize frame-black">
                                Aluminium zwart (10 mm)
                                </div>
                            </div>
                            <div>
                                <div data-citymap="frame" data-value="white" class="frame_finalize frame-white">
                                Aluminium goud (10 mm)
                                </div>
                            </div>
                            <div>
                                <div data-citymap="frame" data-value="oak" class="frame_finalize frame-oak">
                                Hout zwart (15 mm)
                                </div>
                            </div>
                            <div>
                                <div data-citymap="frame" data-value="silver" class="frame_finalize frame-silver">
                                Hout blank (15 mm)
                                </div>
                            </div>-->

								</div>
							</div>
							<div class="row col-md-12 col-lg-12">
								<h5>Format</h5>
								<div class="editor-btns small">
                                <div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="40x50" data-milimeter="40x50" class="active format_finalize 40x50">40X50cm</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="35.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="50x70" data-milimeter="50x70" class="active format_finalize 50x70">50X70cm</div>
                            </div>
                            <!--<div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="12x8" data-milimeter="210x297" class="active format_finalize A4_format">A4</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="17x12" data-milimeter="297x420" class="format_finalize A3_format">A3</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-milimeter="420x594" data-value="23x17" class="format_finalize A2_format">
                                A2</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="33x23" data-milimeter="594x841" class=" format_finalize A1_format">
                                A1</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="47x33" data-milimeter="1189x841" class=" format_finalize A0_format">
                                A0</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="40.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="28x20" data-milimeter="500x707" class="format_finalize B2_format">
                                B2</div>
                            </div>
                            <div>
                                <div data-citymap="format" data-format-price-usd="34.99" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="39x28" data-milimeter="707x1000" class="format_finalize B1_format">
                                B1</div>
                            </div>-->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="Cart">
					<span class="product_price_amount_span" style="display:none">20</span>
					<button class="addToCart btn btn-primary btn-lg">Add to cart(<span class="product_price_amount">'. wc_price(20) .'</span>)</button>
				</div>
			</div>
			<div class="col-md-7 col-lg-7 maxMapHeight DesktopView mobileView">



			</div>
		</div>
		</div>
	</div>';

    return $output;
}
echo"<pre>";
print_r($output);
echo"</pre>";
function wocommerce_add_to_card()
{
    $price = $_POST['price'];
    $size = $_POST['size'];
    $tagline = $_POST['tagline'];
    $subtitle = $_POST['subtitle'];
    $title = $_POST['title'];
    $product_image = $_POST['product_image'];
    $upload_dir = wp_upload_dir(); // Set upload folder
    $image_data = file_get_contents($_FILES); // Get image data
    $link = $_POST['link'];

    $base_studio_address = "https://studio.mapbox.com/styles/monikasharma/";

    if (wp_mkdir_p($upload_dir['path'])) {
        $file = $upload_dir['path'] . '/' . time() . '.png';
    } else {
        $file = $upload_dir['basedir'] . '/' . time() . '.png';
    }

    move_uploaded_file($_FILES['product_image']['tmp_name'], $file);

    $size = $_POST['mainSize'];
    $size = preg_replace('/[0-9]+/', '', $size);
    $size = str_replace('£', '', $size);
    $size = str_replace('.', '', $size);
    $size = str_replace('–', '', $size);

    $size = $size . ' ' . $_POST['sizeMilimeter'];


    $fontFamily = $_POST['fontFamily'];
    $fontSize = $_POST['fontSize'];
    $backgroundColor = $_POST['backgroundColor'];
    $fontWeight = $_POST['fontWeight'];
    $orientation = $_POST['orientation'];

    $productAttributes = array(
        'title' => $title,
        'subtitle' => $subtitle,
        'tagline' => $tagline,
        'size' => $size,
        'product_image' => $product_image,
        'Font Family' => $fontFamily,
        'Font Size' => $fontSize,
        'Background Color' => $backgroundColor,
        'Font Weight' => $fontWeight,
        'Orientation' => $orientation,
        'link' => $base_studio_address . $link
    );


    //file_put_contents( $file, $product_image );

    global $user_ID, $wpdb;


    $post_id = wp_insert_post(array(
        'post_title' => $title,
        'post_content' => 'Here is city map builder where you can take the image of search location.',
        'post_status' => 'publish',
        'post_type' => "product",
        'product_cat' => 'Customized Map Product'
    ));

    $ss = wp_set_object_terms($post_id, 'Map customizations1', 'product_cat');
    $ss = wp_set_object_terms($post_id, 'simple', 'product_type');

    update_post_meta($post_id, '_visibility', 'hidden');
    update_post_meta($post_id, '_stock_status', 'instock');
    update_post_meta($post_id, 'total_sales', '0');
    update_post_meta($post_id, '_downloadable', 'no');
    update_post_meta($post_id, '_virtual', 'yes');
    update_post_meta($post_id, '_regular_price', !empty($price) ? $price : '');
    update_post_meta($post_id, '_sale_price', '');
    update_post_meta($post_id, '_purchase_note', '');
    update_post_meta($post_id, '_featured', 'no');
    update_post_meta($post_id, '_weight', '');
    update_post_meta($post_id, '_length', '');
    update_post_meta($post_id, '_width', '');
    update_post_meta($post_id, '_height', '');
    update_post_meta($post_id, '_sku', '');
    //update_post_meta( $post_id, '_product_attributes', array( 'title' => $title, 'subtitle' => $subtitle, 'tagline' => $tagline, 'size' => $size, 'product_image' => $product_image) );
    update_post_meta($post_id, '_product_attributes', $productAttributes);
    update_post_meta($post_id, '_sale_price_dates_from', '');
    update_post_meta($post_id, '_sale_price_dates_to', '');
    update_post_meta($post_id, '_price', !empty($price) ? $price : '');
    update_post_meta($post_id, '_sold_individually', '');
    update_post_meta($post_id, '_manage_stock', 'no');
    update_post_meta($post_id, '_backorders', 'no');
    update_post_meta($post_id, '_stock', '');
    //exit( wp_redirect( get_permalink( woocommerce_get_page_id( 'cart' ) ) ) );
    /* }	 */
    //$item = ['subtitle' => $subtitle, 'tagline' => $tagline, 'size' => $size, 'link' => $base_studio_address . $link];

    $productAttributes = array(
        'Title' => $title,
        'Subtitle' => $subtitle,
        'Tagline' => $tagline,
        'Size' => $size,
        //'product_image' => $product_image,
        'Font Family' => $fontFamily,
        'Font Size' => $fontSize,
        'Background Color' => $backgroundColor,
        'Font Weight' => $fontWeight,
        'Orientation' => $orientation,
        'link' => $base_studio_address . $link
    );

    $product_attributes = array();
    $i = 1;
    foreach ($productAttributes as $key => $value) {
        $product_attributes[sanitize_title($key)] = array(
            'name' => wc_clean($key), // set attribute name
            'value' => $value, // set attribute value
            'position' => $i,
            'is_visible' => 1,
            'is_variation' => 0,
            'is_taxonomy' => 0
        );
        $i++;
    }

    echo "<pre>"; print_r($product_attributes); die;

    update_post_meta($post_id, '_product_attributes', $product_attributes);

    /*
      $child_product = wc_get_product($post_id);
      $child_product->set_catalog_visibility('hidden');
      $child_product->save(); */

    $attachment = array(
        'post_mime_type' => 'image/png',
        'post_title' => sanitize_file_name($title) . '_wocommerce_image',
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $file, $post_id);

    $attach_data = wp_generate_attachment_metadata($attach_id, $file);

    wp_update_attachment_metadata($attach_id, $attach_data);

    set_post_thumbnail($post_id, $attach_id);

    WC()->cart->add_to_cart($post_id, 1);

    do_action('woocommerce_ajax_added_to_cart', $post_id);
    wc_add_to_cart_message($post_id);

    $checkout_url = WC()->cart->get_cart_url();

    echo json_encode(array('status' => true, 'data' => $checkout_url, 'Message' => 'Product is successfully added to the cart.'));
    die;
}

add_action('wp_ajax_wocommerce_add_to_card', 'wocommerce_add_to_card');
add_action('wp_ajax_nopriv_wocommerce_add_to_card', 'wocommerce_add_to_card');
// function lh_cart_item_sub_title( $cart_item ) {
//    // $shpng = get_field( 'shpng', $cart_item['product_id'] );
//     echo "<div class='small custom-cart-shipping-date'>My Custom Shipping Date: $product_attributes.</div>";
// }
// add_action( 'woocommerce_after_cart_item_name', 'lh_cart_item_sub_title', 10, 1 );
//add menu page
//add menu page
add_action('admin_menu', 'test');

function test()
{
    add_menu_page('Create Style', 'Create a new style', 'manage_options', 'style_plugin_options', 'test_plugin_admin_options');
    add_submenu_page('style_plugin_options', 'Style Lists', 'Map Lists', 'manage_options', 'style-lists', 'style_list_admin_option');
}

function style_list_admin_option()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'style_design';
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id desc");

    //echo "<pre>"; print_r($results); die;
    ?>
    <table class="style-table">
        <thead>
        <tr>
            <th>S.No</th>
            <th>Style Image</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (!empty($results)) {
            $i = 0;
            foreach ($results as $key => $value) {
                $i++;
                ?>
                <tr>
                    <td><?php echo $i; ?>
                        <!-- <input type="hidden" name="data-value" value="<?php echo $value->value; ?>">
                                <input type="hidden" name="data-label" value="<?php echo $value->label; ?>">
                                <input type="hidden" name="data-water" value="<?php echo $value->water; ?>">
                                <input type="hidden" name="data-building" value="<?php echo $value->building; ?>"> -->
                    </td>
                    <td><img src="<?php echo $value->style_image; ?>" width="150px"></td>
                    <td>
                        <button class="button button-primary edit-style" rel="<?php echo $value->id; ?>">Edit</button>
                        <button class="button button-primary delete-style" rel="<?php echo $value->id; ?>">Delete
                        </button>
                    </td>
                </tr>
                <?php
            }
        } else {
        ?>
        <tr>
            <td colspan="3">No Results Found.
            </th>
        </tr>
        </tbody>
        <?php
        }
        ?>
    </table>
    <script type="text/javascript">Select Your Font

    </script>
    <?php
}

function delete_style_design()
{
    global $wpdb;
    $id = $_POST['id'];
    $table_name = $wpdb->prefix . 'style_design';
    $wpdb->delete($table_name, array('id' => $id));
    echo json_encode(array('status' => true, 'Message' => 'Deleted Successfully'));
    die;
}

add_action('wp_ajax_delete_style_design', 'delete_style_design');
add_action('wp_ajax_nopriv_delete_style_design', 'delete_style_design');

//create page content and options
function test_plugin_admin_options()
{

    global $wpdb;
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $id = $_GET['id'];
        $table_name = $wpdb->prefix . 'style_design';
        $results = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id");
        $title = 'Edit: ' . $results->style_name;
    } else {
        $id = 0;
        $table_name = $wpdb->prefix . 'style_design';
        $results = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id");
        $title = 'City Map Plugin';
    }
    ?>
    <div class="row">
        <div class="style-meta">
            <h1><?php echo $title; ?></h1>

            <form method="post" class="style-save-data">
                <?php settings_fields('test-plugin-settings-group'); ?>
                <?php do_settings_sections('test-plugin-settings-group'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Background Color:</th>
                        <td>
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="text" id="value-color" name="data-value"
                                   value="<?php isset($results->value) && !empty($results->value) ? print_r($results->value) : '' ?>" <?php isset($results->value) && !empty($results->value) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <input type="color" name="data-value" class="value-color"
                                   value="<?php isset($results->value) && !empty($results->value) ? print_r($results->value) : '' ?>" <?php isset($results->value) && !empty($results->value) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <!--<input type="checkbox" class="value-visible layer-visiblity" value="" <?php isset($results->value) && !empty($results->value) ? '' : !empty($results->id) ? print_r('checked="checked"') : ''; ?>> -->
                        </td>
                        <input type="hidden" class="style-image-value" name="style-image-value"
                               value="<?php isset($results->style_image) && !empty($results->style_image) ? print_r($results->style_image) : '' ?>">
                    </tr>
                    <tr valign="top">
                        <th scope="row">Street Color:</th>
                        <td>
                            <input type="text" id="label-color" name="data-label"
                                   value="<?php isset($results->label) && !empty($results->label) ? print_r($results->label) : '' ?>" <?php isset($results->label) && !empty($results->label) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?> />
                            <input type="color" name="data-label" class="label-color"
                                   value="<?php isset($results->label) && !empty($results->label) ? print_r($results->label) : '' ?>" <?php isset($results->label) && !empty($results->label) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <!--<input type="checkbox" class="label-visible layer-visiblity" value="" <?php isset($results->label) && !empty($results->label) ? '' : !empty($results->id) ? print_r('checked="checked"') : ''; ?> > -->
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row">Water Color:</th>
                        <td>
                            <input type="text" id="water-color" name="data-water"
                                   value="<?php isset($results->water) && !empty($results->water) ? print_r($results->water) : '' ?>" <?php isset($results->water) && !empty($results->water) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <input type="color" name="data-water" class="water-color"
                                   value="<?php isset($results->water) && !empty($results->water) ? print_r($results->water) : '' ?>" <?php isset($results->water) && !empty($results->water) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <!--<input type="checkbox" class="water-visible layer-visiblity" value="" <?php isset($results->water) && !empty($results->water) ? '' : !empty($results->id) ? print_r('checked="checked"') : ''; ?>> -->
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Building Color:</th>
                        <td>
                            <input type="text" name="data-building" id="building-color"
                                   value="<?php isset($results->building) && !empty($results->building) ? print_r($results->building) : '' ?>" <?php isset($results->building) && !empty($results->building) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <input type="color" name="data-building" class="building-color"
                                   value="<?php isset($results->building) && !empty($results->building) ? print_r($results->building) : '' ?>" <?php isset($results->building) && !empty($results->building) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <!--<input type="checkbox" class="building-visible layer-visiblity" value="" <?php isset($results->building) && !empty($results->building) ? '' : !empty($results->id) ? print_r('checked="checked"') : ''; ?>> -->
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Landuse Color:</th>
                        <td>
                            <input type="text" name="data-landuse" id="landuse-color"
                                   value="<?php isset($results->landuse) && !empty($results->landuse) ? print_r($results->landuse) : '' ?>" <?php isset($results->landuse) && !empty($results->landuse) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <input type="color" name="data-landuse" class="landuse-color"
                                   value="<?php isset($results->landuse) && !empty($results->landuse) ? print_r($results->landuse) : '' ?>" <?php isset($results->landuse) && !empty($results->landuse) ? '' : !empty($results->id) ? print_r('disabled="disabled"') : ''; ?>/>
                            <!-- <input type="checkbox" class="landuse-visible layer-visiblity" value="" <?php isset($results->landuse) && !empty($results->landuse) ? '' : !empty($results->id) ? print_r('checked="checked"') : ''; ?>> -->
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Color Name:</th>
                        <td>
                            <input type="text" name="data-style_name" id="style_name-color"
                                   value="<?php isset($results->style_name) && !empty($results->style_name) ? print_r($results->style_name) : '' ?>"/>
                        </td>
                    </tr>
                </table>
                <button type="button" name="preview" class="style-preview styles-essentials button button-primary"
                        data-value="<?php isset($results->value) && !empty($results->value) ? print_r($results->value) : '#000' ?>"
                        data-label="<?php isset($results->label) && !empty($results->label) ? print_r($results->label) : '#000' ?>"
                        data-water="<?php isset($results->water) && !empty($results->water) ? print_r($results->water) : '#000' ?>"
                        data-building="<?php isset($results->building) && !empty($results->building) ? print_r($results->building) : '#000' ?>"
                        data-landuse="<?php isset($results->landuse) && !empty($results->landuse) ? print_r($results->landuse) : '#000' ?>">
                    Preview
                </button>


                <input type="button" name="submit" id="submit" class="button button-primary save_style" value="<?php
                if (!empty($id)) {
                    echo 'Update Changes';
                } else {
                    echo 'Save Changes';
                }
                ?>">

            </form>
        </div>

        <div class="style-meta">
            <div id="geocoder" class="geocoder"></div>
            <div class="outter landscape size-12x12">
                <div class="layout-outside-design layout-0 format-12x12">
                    <div class="map-design">
                        <div id="map" class="">
                        </div>
                        <div class="border-1" style="zoom: 1;"></div>
                        <div class="border-2" style="zoom: 1;"></div>
                    </div>
                </div>
            </div>
            <div class="vertical-dimension l-eighteen-vertical-dimension"></div>
            <span class="vertical-dimension-text l-vertical-dimension-text"></span>

            <div class="horizontal-dimension l-twelve-horizontal-dimension"></div>
            <span class="horizonal-dimension-text l-twelve-horizonal-dimension-text"></span>

        </div>
    </div>
<?php
}

function save_style_design()
{

    global $wpdb;
    $table_name = $wpdb->prefix . 'style_design';

    //echo $table_name; die;

    $values = '';
    $label = '';
    $water = '';
    $building = '';
    $landuse = '';
    $image = '';
    $zoom = $_POST['zoom'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $initialBuilding = $_POST['initialBuilding'];
    $initialLanduse = $_POST['initialLanduse'];
    $initialWater = $_POST['initialWater'];
    $initialLabel = $_POST['initialLabel'];
    $initialColor = $_POST['initialColor'];

    $obj = new stdClass();
    $curl = curl_init();

    foreach ($_POST['formData'] as $key => $value) {
        switch ($value['name']) {
            case "data-value":
                if (!empty($value['value']))
                    $values = $value['value'];
                break;
            case "style-image-value":
                if (!empty($value['value']))
                    $image = $value['value'];
                break;
            case "data-label":
                if (!empty($value['value']))
                    $label = $value['value'];
                break;
            case "data-water":
                if (!empty($value['value']))
                    $water = $value['value'];
                break;
            case "data-building":
                if (!empty($value['value']))
                    $building = $value['value'];
                break;
            case "data-landuse":
                if (!empty($value['value']))
                    $landuse = $value['value'];
                break;
            case 'id':
                if (!empty($value['value']))
                    $id = $value['value'];
                break;
            case 'data-style_name':
                if (!empty($value['value']))
                    $style_name = $value['value'];
                break;
            default:
                break;
        }
    }

    $saved_label = !empty($label) ? $label : '';
    $saved_value = !empty($values) ? $values : '';
    $saved_water = !empty($water) ? $water : '';
    $saved_building = !empty($building) ? $building : '';
    $saved_landuse = !empty($landuse) ? $landuse : '';

    $label = !empty($label) ? $label : $initialLabel;
    $values = !empty($values) ? $values : $initialColor;
    $water = !empty($water) ? $water : $initialWater;
    $building = !empty($building) ? $building : $initialBuilding;
    $landuse = !empty($landuse) ? $landuse : $initialLanduse;

    $style_id = '';
    if (!empty($id)) {
        $style_datas = $wpdb->get_results("SELECT * FROM $table_name WHERE id = $id");
        $style_id = $style_datas[0]->style_id;
    }

    $sprites = isset($id) && !empty($id) ? "mapbox://sprites/monikasharma/'.$style_id.'" : "mapbox://sprites/examples/cji3d7gpt1i8m2rn7l7w0vl99";
    $a = '{
                "version": 8,
                "name": "Mapbox Style",
                "metadata": {
                        "mapbox:origin": "basic-template-v1",
                        "mapbox:autocomposite": true,
                        "mapbox:type": "template",
                        "mapbox:sdk-support": {
                                "js": "0.45.0",
                                "android": "6.0.0",
                                "ios": "4.0.0"
                        }
                },
                "center": [-122.4080683594193, 37.744170160022705],
                "zoom": 10,
                "bearing": 0,
                "pitch": 0,
                "sources": {
                        "mapbox-streets": {
                                "url": "mapbox://mapbox.mapbox-streets-v7",
                                "type": "vector"
                        }
                },
                "sprite": "' . $sprites . '",
                "glyphs": "mapbox://fonts/examples/{fontstack}/{range}.pbf",
                "layers": [{
                        "id": "background",
                        "type": "background",
                        "layout": {},
                        "paint": {
                                "background-color": ["interpolate", ["linear"],
                                        ["zoom"], 5, "' . $values . '", 12, "' . $values . '"
                                ]
                        }
                }, {
                        "layout": {},
                        "filter": ["==", "class", "national_park"],
                        "type": "fill",
                        "source": "mapbox-streets",
                        "id": "national_park",
                        "paint": {
                                "fill-color": "' . $values . '",
                                "fill-opacity": ["interpolate", ["linear"],
                                        ["zoom"], 5, 0, 6, 0.5
                                ]
                        },
                        "source-layer": "landuse_overlay"
                }, {
                        "layout": {},
                        "filter": ["in", "class", "hospital", "park", "pitch", "school"],
                        "type": "fill",
                        "source": "mapbox-streets",
                        "id": "landuse",
                        "paint": {
                                "fill-color": "' . $landuse . '",
                                "fill-opacity": ["interpolate", ["linear"],
                                        ["zoom"], 5, 0, 6, 1
                                ]
                        },
                        "source-layer": "landuse"
                }, {
                        "minzoom": 8,
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["in", "class", "canal", "river"]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "waterway",
                        "paint": {
                                "line-color": "' . $water . '",
                                "line-width": ["interpolate", ["exponential", 1.3],
                                        ["zoom"], 8.5, 0.1, 20, 8
                                ],
                                "line-opacity": ["interpolate", ["linear"],
                                        ["zoom"], 8, 0, 8.5, 1
                                ]
                        },
                        "source-layer": "waterway"
                }, {
                        "id": "water",
                        "type": "fill",
                        "source": "mapbox-streets",
                        "source-layer": "water",
                        "layout": {},
                        "paint": {
                                "fill-color": "' . $water . '"
                        }
                }, {
                        "layout": {},
                        "filter": ["all", ["==", "$type", "Polygon"],
                                ["in", "type", "helipad", "runway", "taxiway"]
                        ],
                        "type": "fill",
                        "source": "mapbox-streets",
                        "id": "aeroway-polygon",
                        "paint": {
                                "fill-color": "' . $label . '"
                        },
                        "source-layer": "aeroway"
                }, {
                        "layout": {},
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["in", "type", "runway", "taxiway"]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "aeroway-line",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 10, 0.5, 18, 20
                                ],
                                "line-color": "' . $label . '"
                        },
                        "source-layer": "aeroway"
                }, {
                        "minzoom": 15,
                        "layout": {},
                        "filter": ["all", ["!=", "type", "building:part"],
                                ["==", "underground", "false"]
                        ],
                        "type": "fill",
                        "source": "mapbox-streets",
                        "id": "building",
                        "paint": {
                                "fill-color": ["interpolate", ["linear"],
                                        ["zoom"], 15, "' . $building . '", 16, "' . $building . '"
                                ],
                                "fill-opacity": ["interpolate", ["linear"],
                                        ["zoom"], 15.5, 0, 16, 1
                                ]
                        },
                        "source-layer": "building"
                }, {
                        "minzoom": 14,
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["all", ["!=", "type", "platform"],
                                        ["in", "class", "path", "pedestrian"]
                                ]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "pedestrian-path",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 14, ["match", ["get", "class"], "pedestrian", 1, "path", 0.75, 0.75], 20, ["match", ["get", "class"], "pedestrian", 8, "path", 5, 5]
                                ],
                                "line-color": ["match", ["get", "type"], "sidewalk", "' . $label . '", "crossing", "' . $label . '", "' . $label . '"]
                        },
                        "source-layer": "road"
                }, {
                        "layout": {
                                "line-join": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["all", ["!=", "type", "service:parking_aisle"],
                                        ["==", "structure", "tunnel"],
                                        ["in", "class", "link", "motorway", "motorway_link", "primary", "secondary", "service", "street", "street_limited", "tertiary", "track", "trunk"]
                                ]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "tunnel",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 5, ["match", ["get", "class"], "motorway", 0.5, "trunk", 0.5, "primary", 0.5, "secondary", 0.01, "tertiary", 0.01, "street", 0, "street_limited", 0, "motorway_link", 0, "service", 0, "track", 0, "link", 0, 0], 12, ["match", ["get", "class"], "motorway", 3, "trunk", 3, "primary", 3, "secondary", 2, "tertiary", 2, "street", 0.5, "street_limited", 0.5, "motorway_link", 0.5, "service", 0, "track", 0, "link", 0, 0], 18, ["match", ["get", "class"], "motorway", 30, "trunk", 30, "primary", 30, "secondary", 24, "tertiary", 24, "street", 12, "street_limited", 12, "motorway_link", 12, "service", 10, "track", 10, "link", 10, 10]
                                ],
                                "line-color": ["match", ["get", "class"], "street", "' . $label . '", "street_limited", "' . $label . '", "service", "' . $label . '", "track", "' . $label . '", "link", "' . $label . '", "' . $label . '"],
                                "line-dasharray": [0.2, 0.2]
                        },
                        "source-layer": "road"
                }, {
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["all", ["!=", "type", "service:parking_aisle"],
                                        ["!in", "structure", "bridge", "tunnel"],
                                        ["in", "class", "link", "motorway", "motorway_link", "primary", "secondary", "service", "street", "street_limited", "tertiary", "track", "trunk"]
                                ]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "road",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 5, ["match", ["get", "class"], "motorway", 0.5, "trunk", 0.5, "primary", 0.5, "secondary", 0.01, "tertiary", 0.01, "street", 0, "street_limited", 0, "motorway_link", 0, "service", 0, "track", 0, "link", 0, 0], 12, ["match", ["get", "class"], "motorway", 3, "trunk", 3, "primary", 3, "secondary", 2, "tertiary", 2, "street", 0.5, "street_limited", 0.5, "motorway_link", 0.5, "service", 0, "track", 0, "link", 0, 0], 18, ["match", ["get", "class"], "motorway", 30, "trunk", 30, "primary", 30, "secondary", 24, "tertiary", 24, "street", 12, "street_limited", 12, "motorway_link", 12, "service", 10, "track", 10, "link", 10, 10]
                                ],
                                "line-color": ["match", ["get", "class"], "street", "' . $label . '", "street_limited", "' . $label . '", "service", "' . $label . '", "track", "' . $label . '", "link", "' . $label . '", "' . $label . '"]
                        },
                        "source-layer": "road"
                }, {
                        "layout": {
                                "line-join": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["all", ["!=", "type", "service:parking_aisle"],
                                        ["==", "structure", "bridge"],
                                        ["in", "class", "link", "motorway", "motorway_link", "primary", "secondary", "service", "street", "street_limited", "tertiary", "track", "trunk"]
                                ]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "bridge-case",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 10, 1, 16, 2
                                ],
                                "line-color": "' . $label . '",
                                "line-gap-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 5, ["match", ["get", "class"], "motorway", 0.5, "trunk", 0.5, "primary", 0.5, "secondary", 0.01, "tertiary", 0.01, "street", 0, "street_limited", 0, "motorway_link", 0, "service", 0, "track", 0, "link", 0, 0], 12, ["match", ["get", "class"], "motorway", 3, "trunk", 3, "primary", 3, "secondary", 2, "tertiary", 2, "street", 0.5, "street_limited", 0.5, "motorway_link", 0.5, "service", 0, "track", 0, "link", 0, 0], 18, ["match", ["get", "class"], "motorway", 30, "trunk", 30, "primary", 30, "secondary", 24, "tertiary", 24, "street", 12, "street_limited", 12, "motorway_link", 12, "service", 10, "track", 10, "link", 10, 10]
                                ]
                        },
                        "source-layer": "road"
                }, {
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["==", "$type", "LineString"],
                                ["all", ["!=", "type", "service:parking_aisle"],
                                        ["==", "structure", "bridge"],
                                        ["in", "class", "link", "motorway", "motorway_link", "primary", "secondary", "service", "street", "street_limited", "tertiary", "track", "trunk"]
                                ]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "bridge",
                        "paint": {
                                "line-width": ["interpolate", ["exponential", 1.5],
                                        ["zoom"], 5, ["match", ["get", "class"], "motorway", 0.5, "trunk", 0.5, "primary", 0.5, "secondary", 0.01, "tertiary", 0.01, "street", 0, "street_limited", 0, "motorway_link", 0, "service", 0, "track", 0, "link", 0, 0], 12, ["match", ["get", "class"], "motorway", 3, "trunk", 3, "primary", 3, "secondary", 2, "tertiary", 2, "street", 0.5, "street_limited", 0.5, "motorway_link", 0.5, "service", 0, "track", 0, "link", 0, 0], 18, ["match", ["get", "class"], "motorway", 30, "trunk", 30, "primary", 30, "secondary", 24, "tertiary", 24, "street", 12, "street_limited", 12, "motorway_link", 12, "service", 10, "track", 10, "link", 10, 10]
                                ],
                                "line-color": ["match", ["get", "class"], "street", "' . $label . '", "street_limited", "' . $label . '", "service", "' . $label . '", "track", "' . $label . '", "link", "' . $label . '", "' . $label . '"]
                        },
                        "source-layer": "road"
                }, {
                        "minzoom": 2,
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["==", "maritime", 0],
                                [">=", "admin_level", 3]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "admin-state-province",
                        "paint": {
                                "line-dasharray": ["step", ["zoom"],
                                        ["literal", [2, 0]], 7, ["literal", [2, 2, 6, 2]]
                                ],
                                "line-width": ["interpolate", ["linear"],
                                        ["zoom"], 7, 0.75, 12, 1.5
                                ],
                                "line-opacity": ["interpolate", ["linear"],
                                        ["zoom"], 2, 0, 3, 1
                                ],
                                "line-color": ["step", ["zoom"], "' . $label . '", 4, "' . $label . '"]
                        },
                        "source-layer": "admin"
                }, {
                        "minzoom": 1,
                        "layout": {
                                "line-join": "round",
                                "line-cap": "round"
                        },
                        "filter": ["all", ["<=", "admin_level", 2],
                                ["==", "disputed", 0],
                                ["==", "maritime", 0]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "admin-country",
                        "paint": {
                                "line-color": "' . $label . '",
                                "line-width": ["interpolate", ["linear"],
                                        ["zoom"], 3, 0.5, 10, 2
                                ]
                        },
                        "source-layer": "admin"
                }, {
                        "minzoom": 1,
                        "layout": {
                                "line-join": "round"
                        },
                        "filter": ["all", ["<=", "admin_level", 2],
                                ["==", "disputed", 1],
                                ["==", "maritime", 0]
                        ],
                        "type": "line",
                        "source": "mapbox-streets",
                        "id": "admin-country-disputed",
                        "paint": {
                                "line-color": "' . $label . '",
                                "line-width": ["interpolate", ["linear"],
                                        ["zoom"], 3, 0.5, 10, 2
                                ],
                                "line-dasharray": [1.5, 1.5]
                        },
                        "source-layer": "admin"
                }],
                "owner": "monikasharma"
        }';

    $url = "https://api.mapbox.com/styles/v1/monikasharma?access_token=sk.eyJ1IjoibW9uaWthc2hhcm1hIiwiYSI6ImNrNmx0bnVpdDBoNnEza3FnYmJmNHdtdTkifQ.NJk9VJ3BhH8HSTYXU-_uNA";
    $post = 'POST';
    if (!empty($id)) {
        $post = 'PATCH';
        $url = "https://api.mapbox.com/styles/v1/monikasharma/" . $style_id . "?access_token=sk.eyJ1IjoibW9uaWthc2hhcm1hIiwiYSI6ImNrNmx0bnVpdDBoNnEza3FnYmJmNHdtdTkifQ.NJk9VJ3BhH8HSTYXU-_uNA";
    }

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $post,
        CURLOPT_POSTFIELDS => $a,
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $style_data = json_decode($response);
    $style_id = $style_data->id;

    if (!empty($id)) {
        $saved = $wpdb->update(
            $table_name, array(
            'style_image' => $image,
            'value' => $saved_value,
            'label' => $saved_label,
            'water' => $saved_water,
            'building' => $saved_building,
            'landuse' => $saved_landuse,
            'style_name' => $style_name,
            'style_id' => $style_id,
            'longitude' => $longitude,
            'latitude' => $latitude,
            'zoom' => $zoom,
            'updated_at' => date('Y-m-d h:i:s')
        ), array('id' => $id)
        );
        $text = 'updated';
    } else {
        $saved = $wpdb->insert(
            $table_name, array(
                'style_image' => $image,
                'value' => $saved_value,
                'label' => $saved_label,
                'water' => $saved_water,
                'building' => $saved_building,
                'landuse' => $saved_landuse,
                'style_name' => $style_name,
                'style_id' => $style_id,
                'longitude' => $longitude,
                'latitude' => $latitude,
                'zoom' => $zoom,
                'created_at' => date('Y-m-d h:i:s'),
                'updated_at' => date('Y-m-d h:i:s')
            )
        );
        $text = 'saved';
    }

    echo json_encode(array('status' => true, 'message' => 'Style is ' . $text . ' successfully.'));
    die;
}

add_action('wp_ajax_save_style_design', 'save_style_design');
add_action('wp_ajax_nopriv_save_style_design', 'save_style_design');


/*
  function custom_pre_get_posts_query( $q ) {

  $tax_query = (array) $q->get( 'tax_query' );

  $tax_query[] = array(
  'taxonomy' => 'product_cat',
  'field' => 'slug',
  'terms' => array( 'musthaves' ), // Don't display products with category "musthave" on the shop.
  'operator' => 'NOT IN'
  );

  $q->set( 'tax_query', $tax_query );

  }
  add_action( 'woocommerce_product_query', 'custom_pre_get_posts_query' ); */

add_action('woocommerce_admin_order_preview_end', 'lets_show_something_in_preview');

function lets_show_something_in_preview()
{
    global $post;
    $order = new WC_Order($post->ID);
    $items = $order->get_items();

    $flag = 0;
    echo '<div class="wc-order-preview-additional-information" style="padding:10px">';
    foreach ($items as $item) {
        $pid = $item['product_id'];
        $p = new WC_Product($pid);
        $attributes = $p->get_attributes();


        if (isset($attributes['subtitle']['options'][0]) && isset($attributes['size']['options'][0]) && isset($attributes['tagline']['options'][0])) {
            if ($flag == 0) {

                echo '<h2>Additional Information</h2>';
            }
        }

        echo '<br><b>' . $p->name . '</b>';

        isset($attributes['subtitle']['options'][0]) ? print_r('<br><b>Subtitle</b>  :' . ' ' . $attributes['subtitle']['options'][0] . '<br><br>') : '';
        isset($attributes['size']['options'][0]) ? print_r('<b>Size</b>  :' . ' ' . $attributes['size']['options'][0] . '<br><br>') : '';
        isset($attributes['tagline']['options'][0]) ? print_r('<b>Tagline</b>  :' . ' ' . $attributes['tagline']['options'][0] . '<br><br>') : '';


        if (!isset($attributes['subtitle']['options'][0]) && !isset($attributes['size']['options'][0]) && !isset($attributes['tagline']['options'][0])) {
            echo '<br>No attributes available<br>';
        }


        $flag++;
    }

    echo "</div>";
}

add_filter('manage_edit-shop_order_columns', 'lets_add_a_new_column_to_admin_order_page');

function lets_add_a_new_column_to_admin_order_page($columns)
{
    $columns['attribute'] = 'Attribute';
    return $columns;
}

add_action('manage_shop_order_posts_custom_column', 'column_content_with_custom_text');

function column_content_with_custom_text($column)
{
    global $post;

    if ('attribute' === $column) {
        $order = new WC_Order($post->ID);
        $items = $order->get_items();

        foreach ($items as $item) {
            $pid = $item['product_id'];
            $p = new WC_Product($pid);
            $image = wp_get_attachment_image_src(get_post_thumbnail_id($pid), 'single-post-thumbnail');

            $attributes = $p->get_attributes();

            echo '<br><b>' . $p->name . '</b>';

            isset($attributes['subtitle']['options'][0]) ? print_r('<br><b>Subtitle</b>  :' . ' ' . $attributes['subtitle']['options'][0] . '<br>') : '';
            isset($attributes['size']['options'][0]) ? print_r('<b>Size</b>  :' . ' ' . $attributes['size']['options'][0] . '<br>') : '';
            isset($attributes['tagline']['options'][0]) ? print_r('<b>Tagline</b>  :' . ' ' . $attributes['tagline']['options'][0] . '<br>') : '';
            isset($attributes['link']['options'][0]) ? print_r('<a href="' . $attributes['link']['options'][0] . '" class="button button-primary button-large" target="_blank">Export Map</a>') . '' : '';
            isset($attributes['link']['options'][0]) ? print_r('<a href="' . $image[0] . '" class="button button-primary button-large" target="_blank" style="margin:3px 0;">Export Image</a>') . '' : '';

            if (!isset($attributes['subtitle']['options'][0]) && !isset($attributes['size']['options'][0]) && !isset($attributes['tagline']['options'][0])) {
                echo '<br>No attributes available<br>';
            }
        }
    }
}

add_action('woocommerce_admin_order_item_headers', 'custom_admin_order_items_headers', 20, 1);

function custom_admin_order_items_headers($order)
{

    echo '<th>';
    echo __('Attributes', 'woocommerce') . '</th>';
}

add_action('woocommerce_admin_order_item_values', 'custom_admin_order_item_values', 20, 4);

function custom_admin_order_item_values($_product, $item, $item_id)
{

    $attributes = $_product->attributes;

    // echo '<pre>'; print_r($attributes); die;
    //  $p = new WC_Product($id);
    // if $p->get_attributes() !== null) {
    //  $attributes = $p->get_attributes();
    //  print_r($attributes);
    // }
//    echo '<pre>'; print_r(); die;
//    $subtitle = $_product->get_attribute('subtitle');
//    $size = $_product->get_attribute('size');
//    $tagline = $_product->get_attribute('tagline');
//   $subtitle = isset($attributes['subtitle']) ? $attributes['subtitle'] : '';
//   $size = isset($attributes['size']) ? $attributes['size'] : '';
//   $tagline = isset($attributes['tagline']) ? $attributes['tagline'] : '';

$subtitle = isset($attributes['subtitle']) && !empty($attributes['subtitle']['options'][0]) ? $attributes['subtitle']['options'][0].'<br>' : '';
$size = isset($attributes['size']) && !empty($attributes['size']['options'][0]) ? $attributes['size']['options'][0].'<br>' : '';
$tagline = isset($attributes['tagline']) && !empty($attributes['tagline']['options'][0]) ? $attributes['tagline']['options'][0].'<br>' : '';
$orientation = isset($attributes['orientation']) && !empty($attributes['orientation']['options'][0]) ? $attributes['orientation']['options'][0].'<br>' : '';
$fontfamily = isset($attributes['font-family']) && !empty($attributes['font-family']['options'][0]) ? $attributes['font-family']['options'][0].'<br>' : '';
$fontsize = isset($attributes['font-size']) && !empty($attributes['font-size']['options'][0]) ? $attributes['font-size']['options'][0].'<br>' : '';
$fontweight = isset($attributes['font-weight']) && !empty($attributes['font-weight']['options'][0]) ? $attributes['font-weight']['options'][0].'<br>' : '';
$backgroundcolor = isset($attributes['background-color']) && !empty($attributes['background-color']['options'][0]) ? $attributes['background-color']['options'][0].'<br>' : '';

if (!empty($subtitle) || !empty($tagline) || !empty($size) || !empty($orientation) || !empty($fontfamily) || !empty($fontsize) || !empty($fontweight) || !empty($backgroundcolor)) {
   
    echo '<td>' . "<b>Subtitle:</b>".' '.$subtitle . '<br>' . "<b>Size:</b>".' '.$size . '<br>' . "<b>Tagline:</b>".' '.$tagline . '<br>' . "<b>Orientation:</b>".' '.$orientation .
     '<br>' . "<b>Font family:</b>".' '.$fontfamily . '<br>' . "<b>Font Size:</b>".' '.$fontsize . '<br>' . "<b>Font weight:</b>".' '.$fontweight . '<br>' . "<b>Backgroundcolor:</b>".' '.$backgroundcolor .'</td>';
} else if (empty($subtitle) && empty($tagline) && empty($size)) {
    echo '<td> Not Available</td>';
   
   
}
}


//show attributes after summary in product single view
add_action('woocommerce_single_product_summary', function () {
    global $product;

    if (!empty($product->get_attributes())) {
        $attributes = $product->get_attributes();
        $terms = get_the_terms($product->get_id(), 'product_cat');
        if (!empty($terms)) {
            foreach ($terms as $term) {
                if (!empty($term->name) && ($term->name === 'Map customizations')) {
                    echo '<div class="print-products-area">';
                    echo '<ul class="product-attributes-list" style="word-break: break-word;">';
                    foreach ($attributes as $attribute => $attribute_name) {
                        $term = get_term_by('slug', $attribute_name, $attribute);
                        echo '<li>' . ucfirst(wc_attribute_label($attribute)) . ': <strong>' . $product->get_attribute($attribute) . '</strong></li>';
                    }
                    echo '</ul>';
                    echo '</div>';
                }
            }
        }
    }

}, 25);


add_filter('woocommerce_get_item_data', 'display_cart_item_custom_data_on_cart_and_checkout', 10, 2);
function display_cart_item_custom_data_on_cart_and_checkout($cart_item_data, $cart_item)
{
    $item_data = $cart_item['data'];

    if (!empty($item_data->get_attributes())) {
        $attributes = $item_data->get_attributes();
        $terms = get_the_terms($item_data->get_id(), 'product_cat');
        if (!empty($terms)) {
            foreach ($terms as $term) {
                if (!empty($term->name) && ($term->name === 'Map customizations')) {
                    echo '<div class="print-products-area">';
                    echo '<ul class="product-attributes-list" style="word-break: break-word;">';
                    foreach ($attributes as $attribute => $attribute_name) {
                        $term = get_term_by('slug', $attribute_name, $attribute);
                        if (wc_attribute_label($attribute) !== 'link') {
                            echo '<li>' . ucfirst(wc_attribute_label($attribute)) . ': <strong>' . $item_data->get_attribute($attribute) . '</strong></li>';
                        }
                    }
                    echo '</ul>';
                    echo '</div>';
                }
            }
        }
    }
    return $cart_item_data;
}
