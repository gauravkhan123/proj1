  jQuery(document).ready(function () {
      var zoominout='<div class="zoom-buttons">'+
          '<button type="button" class=" zoom-btn zoom-in btn btn-default">'+
          '<span class="glyphicon glyphicon-plus"></span>'+
          '</button>'+
          '<button type="button" class="zoom-btn  zoom-out btn btn-default">'+
          '<span class="glyphicon glyphicon-minus"></span>'+
          '</button>'+

          '</div>';
	var append = zoominout+'<div class="outter portrait size-23x17 sel_outer_frame sel_frame_non on_label">'+
                    '<i class="horizontal"><i>210 mm</i></i>'+
                    '<i class="vertical"><i>297 mm</i></i>'+
                    '<div class="layout-outside-design-outer-borer">'+
						'<div class="layout-outside-design layout-0 format-23x17">'+
							'<div class="map-design">'+
								'<div id="map" class="map">'+			
								'</div>'+
								'<div class="border-1" style="zoom: 1;"></div>'+
								'<div class="border-2" style="zoom: 1;"></div>'	+
							'</div>'+

							'<div class="map-overlay top">'+
								'<div class="map-overlay-inner" style="display:none">'+
									'<fieldset>'+
										'<label>Select layer</label>'+
										'<select id="layer" name="layer">'+
											'<option value="water">Water</option>'+
											'<option value="building">Buildings</option>'+
										'</select>'+	
									'</fieldset>'+
									'<fieldset>'+
										'<label>Choose a color</label>'+
										'<div id="swatches"></div>'+
									'</fieldset>'+
								'</div>'+
							'</div>'+
							'<div class="layout-customize smallFont">'+
								'<div class="title">'+
									'<h1 class="fusion-responsive-typography-calculated title font-D-DIN-Condensed" >The Windy City</h1>'+
									'<p class="cus-subtitle font-Euphemia-UCAS">Chicago, Illinois</p>'+
									'<p class="date-subtitle"></p>'+
									'<p class="starmap-message"></p>'+
									'<p class="time-label">12:00 AM</p>'+
									'<p class="cus-tag">-87.74838796981078 / 41.909905163235294 </p>'+
								'</div>'+
							'</div>'+							
						'</div>'+
                    '</div>'+
                '</div>';
		
		if(jQuery(window).width() < 769){
			var width = jQuery(window).width()-100;
			Celestial.resize({width:parseInt(width)});
			jQuery('.mobileView').html(append);
			jQuery('.DesktopView').html('');
		} else {
			jQuery('.mobileView').html('');
			jQuery('.DesktopView').html(append);
		}
		/* if(jQuery(window).width() < 767){
			var width = jQuery(window).width()-100;
			Celestial.resize({width:parseInt(width)});
		}
		if(jQuery(window).width() > 767 && jQuery(window).width() < 1366){
			Celestial.resize({width:425});
		} */
		
    jQuery('.styles-essentials').each(function () {
        if (jQuery(this).hasClass('active')) {
            styles_design = jQuery(this).attr('data-styles');
           // alert(styles_design);
		   if(typeof styles_design !== 'undefined' && styles_design !== ''){
			   map.setStyle('mapbox://styles/monikasharma/' + styles_design);
		   }         

        }            
    });

    //var c_symbol = jQuery('span.product_price_amount_span span.woocommerce-Price-amount.amount span.woocommerce-Price-currencySymbol').text();
    //alert(c_symbol);

    jQuery('ul.nav.nav-tabs li a').click(function(){
		var link = jQuery(this).attr('href');
		//alert(link);
		jQuery('ul.nav.nav-tabs li').each(function () {
			jQuery(this).removeClass('active');
		});
		jQuery(this).addClass('active');

		jQuery('.customize-tab .tab-content .tab-pane').each(function () {
			jQuery(this).removeClass('in active');
		});
		jQuery('div'+link).addClass('active in');
	});
   
	jQuery('.sidebar-group').on('click', function(){
		jQuery('.sidebar-group').each(function () {
			jQuery(this).removeClass('active');
		});
		jQuery(this).addClass('active');
	});
//      jQuery(document).on('click', '#heart_shape', function () {
//       var canvas = document.getElementsByClassName('mapboxgl-canvas');
//       var ctx = canvas[0].getContext("2d");;
//      // console.log(context);
// //alert(context);
//        ctx.beginPath();
//     ctx.moveTo(75, 40);
//     ctx.bezierCurveTo(75, 37, 70, 25, 50, 25);
//     ctx.bezierCurveTo(20, 25, 20, 62.5, 20, 62.5);
//     ctx.bezierCurveTo(20, 80, 40, 102, 75, 120);
//     ctx.bezierCurveTo(110, 102, 130, 80, 130, 62.5);
//     ctx.bezierCurveTo(130, 62.5, 130, 25, 100, 25);
//     ctx.bezierCurveTo(85, 25, 75, 37, 75, 40);
//     ctx.fill();
 
//      })



        //jQuery(document).on('click', '#heart_shape', function () {
        //draw();
        // jQuery("#heart_shape").click(function(){
        // jQuery("canvasMap").removeClass("hide");
        // var canvas = document.getElementById("canvas");
        // //var canvas = document.getElementsByClassName('mapboxgl-canvas');
        // var context = canvas.getContext("2d");
        // canvas.x = 150;
        // canvas.y = 150;


        // var w = 200, h = 200;

        // context.strokeStyle = "#000000";
        // context.strokeWeight = 3;
        // context.shadowOffsetX = 4.0;
        // context.shadowOffsetY = 4.0;
        // context.lineWidth = 10.0;
        // context.fillStyle = "#FF0000";
        // var d = Math.min(w, h);
        // var k = 120;

        // context.moveTo(k, k + d / 4);
        // context.quadraticCurveTo(k, k, k + d / 4, k);
        // context.quadraticCurveTo(k + d / 2, k, k + d / 2, k + d / 4);
        // context.quadraticCurveTo(k + d / 2, k, k + d * 3/4, k);
        // context.quadraticCurveTo(k + d, k, k + d, k + d / 4);
        // context.quadraticCurveTo(k + d, k + d / 2, k + d * 3/4, k + d * 3/4);
        // context.lineTo(k + d / 2, k + d);
        // context.lineTo(k + d / 4, k + d * 3/4);
        // context.quadraticCurveTo(k, k + d / 2, k, k + d / 4);
        // context.stroke();
        // context.fill();
        //     });
    
});
    

jQuery(document).ready(function () {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    var initial_building;
    var initial_label;
    var initial_color;
    var initial_water;
    var initial_landuse;
	
    jQuery('.style-table').on('click', '.edit-style', function () {
        var id = jQuery(this).attr('rel');
        var url = getUrl.origin + window.location.pathname + '?page=style_plugin_options&id=' + id;
        window.location.href = url;
    });
	
    jQuery('.style-meta').on('click', '.layer-visiblity', function () {
        var error = 1;
        jQuery('.layer-visiblity').each(function () {
            if (jQuery(this).prop('checked')) {
                error++;
            }
        });

        if (error > 3){
            jQuery(this).prop('checked', false);
            alert('You can not disable more than two attributes.');
        }
    });
	 
	
	jQuery(document).on('change', '.fontSizeChange', function(){
		var value = jQuery(this).val();
		if(typeof value !== 'undefined' && value !== ''){
			if(value === 'small'){
				jQuery('.layout-customize').removeClass('mediumFont largeFont');
			} else if(value === 'medium') {
				jQuery('.layout-customize').removeClass('smallFont largeFont');
			} else if(value === 'large'){
				jQuery('.layout-customize').removeClass('smallFont mediumFont');
			}
			jQuery('.layout-customize').addClass(value+'Font');
		} 		
	});

    jQuery('.style-meta').on('click', '.value-visible', function () {
        console.log(jQuery(this));
        if (jQuery(this).prop('checked')) {
            jQuery('#value-color').val('');
            jQuery('.value-color').val('');
            jQuery('.style-meta').find('input[name="data-value"]').removeAttr('enabled');
            jQuery('.style-meta').find('input[name="data-value"]').attr('disabled', 'disabled');
            jQuery('.style-preview').attr('data-value', '');
        } else {
            jQuery('.style-meta').find('input[name="data-value"]').removeAttr('disabled');
            jQuery('.style-meta').find('input[name="data-value"]').attr('enabled', 'enabled');
        }
		jQuery('.save_style').hide();
    });

    jQuery('.style-meta').on('click', '.label-visible', function () {
        if (jQuery(this).prop('checked')) {
            jQuery('#label-color').val('');
            jQuery('.label-color').val('');
            jQuery('.style-meta').find('input[name="data-label"]').removeAttr('enabled');
            jQuery('.style-meta').find('input[name="data-label"]').attr('disabled', 'disabled');
            jQuery('.style-preview').attr('data-label', '');
        } else {
            jQuery('.style-meta').find('input[name="data-label"]').removeAttr('disabled');
            jQuery('.style-meta').find('input[name="data-label"]').attr('enabled', 'enabled');
        }
		jQuery('.save_style').hide();
    });

    jQuery('.style-meta').on('click', '.water-visible', function () {
        if (jQuery(this).prop('checked')) {
            jQuery('#water-color').val('');
            jQuery('.water-color').val('');
            jQuery('.style-meta').find('input[name="data-water"]').removeAttr('enabled');
            jQuery('.style-meta').find('input[name="data-water"]').attr('disabled', 'disabled');
            jQuery('.style-preview').attr('data-water', '');
        } else {
            jQuery('.style-meta').find('input[name="data-water"]').removeAttr('disabled');
            jQuery('.style-meta').find('input[name="data-water"]').attr('enabled', 'enabled');
        }
		jQuery('.save_style').hide();
    });

    jQuery('.style-meta').on('click', '.building-visible', function () {
        if (jQuery(this).prop('checked')) {
            jQuery('#building-color').val('');
            jQuery('.building-color').val('');
            jQuery('.style-meta').find('input[name="data-building"]').removeAttr('enabled');
            jQuery('.style-meta').find('input[name="data-building"]').attr('disabled', 'disabled');
            jQuery('.style-preview').attr('data-building', '');
        } else {
            jQuery('.style-meta').find('input[name="data-building"]').removeAttr('disabled');
            jQuery('.style-meta').find('input[name="data-building"]').attr('enabled', 'enabled');
        }
		jQuery('.save_style').hide();
    });
	
	jQuery('.style-meta').on('click', '.landuse-visible', function () {
        if (jQuery(this).prop('checked')) {
            jQuery('#landuse-color').val('');
            jQuery('.landuse-color').val('');
            jQuery('.style-meta').find('input[name="data-landuse"]').removeAttr('enabled');
            jQuery('.style-meta').find('input[name="data-landuse"]').attr('disabled', 'disabled');
            jQuery('.style-preview').attr('data-landuse', '');
        } else {
            jQuery('.style-meta').find('input[name="data-landuse"]').removeAttr('disabled');
            jQuery('.style-meta').find('input[name="data-landuse"]').attr('enabled', 'enabled');
        }
		
		jQuery('.save_style').hide();
    });


    var flag = 0;
    jQuery('.style-meta').on('click', '.style-preview, .save_style', function () {
        var err = 0;
        if (flag > 0) {
            var e = 0;
            if (jQuery('.value-color').attr('disabled')) {
            } else {
                var value = jQuery('#value-color').val();
                if (value == '') {
                    e++;
                }
            }
            if (jQuery('.label-color').attr('disabled')) {
            } else {
                var label = jQuery('#label-color').val();
                if (label == '') {
                    e++;
                }
            }

            if (jQuery('.water-color').attr('disabled')) {
            } else {
                var water = jQuery('#water-color').val();

                if (water == '') {
                    e++;
                }
            }

            if (jQuery('.building-color').attr('disabled')) {
            } else {
                var building = jQuery('#building-color').val();

                if (building == '') {
                    e++;
                }
            }
			
			if (jQuery('.landuse-color').attr('disabled')) {
            } else {
                var landuse = jQuery('#landuse-color').val();
                if (landuse == '') {
                    e++;
                }
            }

            var style_name = jQuery('#style_name-color').val();
            if (style_name == '') {
                err++;
            }

            if ((e < 4 && e != 0) || e == 4) {
                alert('Please fill the colors');
                return false;
            } else if (err > 0) {
                alert('Plaese fill the color name.');
                return false;
            }
        } else {
            flag++;
        }
		
		jQuery('.save_style').show(); 
    }); 

    jQuery('.style-table').on('click', '.delete-style', function () {
        var id = jQuery(this).attr('rel');
        var data = {
            action: 'delete_style_design',
            id: id
        };

        if (confirm('Are You Sure You want to delete it?')) {
            jQuery.ajax({
                type: "post",
                url: ajaxurl,
                data: data,
                dataType: 'json',
                success: function (response) {
                    if (response.status) {
                        location.reload();
                    }
                }
            });
        }
    });

    jQuery(document).on('change', '.value-color, .label-color, .water-color, .building-color, .landuse-color ', function () {
        var color = jQuery(this).val();
        var name = jQuery(this).attr('class');
        jQuery('#' + name).val(color);
        var color_map = jQuery(this).attr('name');
        jQuery('.styles-essentials').attr(color_map, color);		
		jQuery('.save_style').hide();
    });

    //var styles_design = 'mapbox://styles/examples/cji3d7gpt1i8m2rn7l7w0vl99';

    var zoom;
    var latitude;
    var longitude;  

    //mapboxgl.accessToken = 'sk.eyJ1IjoiemVyYWx5bngiLCJhIjoiY2tnYzdhNXJqMDZnczJzbGUxdHZvYjg3eiJ9.xshQTa6ma-7k0dmwPyklJg';
    //mapboxgl.accessToken = 'pk.eyJ1IjoibW9uaWthc2hhcm1hIiwiYSI6ImNrNWNjemhncjFramYzbnBzMzBrMHB1ZWUifQ.YNms0f4VzNiQfvSaxtTIgA';
    mapboxgl.accessToken = 'pk.eyJ1IjoicHVudHBvc3RlcnMiLCJhIjoiY2ttYWtyOTZ2MXN2dDJvbnhpajVpY3c2OCJ9.SPJnXzOoG2UuPQYADfImKg';  // RIck
    var map = new mapboxgl.Map({
        container: 'map',
        //style: 'mapbox://styles/mapbox/light-v10',
        style: 'mapbox://styles/puntposters/ckmakt9f7g9sx17lbue9qkij9',
        //center: [-122.25948, 37.87221], 
        center: [-87.74838796981078 , 41.909905163235294],
        zoom: 10,
        preserveDrawingBuffer: true
    });

    //map.addControl(new mapboxgl.NavigationControl());
	var mapCenter = map.getCenter();
	
	zoom = map.getZoom();
	
	map.on('zoom', function () {
		zoom = map.getZoom();
		//console.log(zoom);
	});

    //zoom in zoom out
    jQuery(document).on('click','.zoom-in',function(){
       zoom = map.getZoom();
       map.setZoom(zoom+1);
    });
    jQuery(document).on('click','.zoom-out',function(){
        zoom = map.getZoom();
        map.setZoom(zoom-1);
    });
    jQuery(document).on('click','.layout-dark',function(){
		jQuery(document).find('.DesktopView .map-design').show();
		jQuery(document).find('.DesktopView #celestial-map').remove();
        jQuery('.layout-customize .title').css('background','white');
        jQuery('.layout-customize').addClass('gradientBG');
       // map.setStyle('mapbox://styles/mapbox/dark-v10');
        map.setStyle('mapbox://styles/puntposters/cknylugu00j9u17qc9okcen6b');
        //map.setStyle('');
    });
    jQuery(document).on('click','.layout-light',function(){
		jQuery(document).find('.DesktopView .map-design').show();
		jQuery(document).find('.DesktopView #celestial-map').remove();
        jQuery('.layout-customize .title').css('background','transparent');
        jQuery('.layout-customize').removeClass('gradientBG');
       // map.setStyle('mapbox://styles/mapbox/light-v10');
        map.setStyle('mapbox://styles/puntposters/ckmakt9f7g9sx17lbue9qkij9');
    });


    var marker = new mapboxgl.Marker()
        .setLngLat(mapCenter)
        .addTo(map);    

    jQuery(document).on('click', '.styles-essentials', function () {
        styles_design = jQuery(this).attr('data-styles');
		if(typeof styles_design !== 'undefined' && styles_design !== ''){
		   map.setStyle('mapbox://styles/monikasharma/' + styles_design);
		}         
    });

    jQuery('.layout-outside-design').hide();

    map.on('load', function () {        
       // marker.remove(); 
		marker.setLngLat(map.getCenter());	
        var layers = map.getStyle().layers;  
		
		map.on('render', function(e){
			marker.setLngLat(map.getCenter());	
		});
		
		map.on('sourcedataloading', function(e){
			marker.setLngLat(map.getCenter());	
		});
		
        map.on('mousemove', function (e) {	
			marker.setLngLat(map.getCenter());				
            zoom = map.getZoom();
            latitude = JSON.stringify(e.lngLat.wrap().lat);
            longitude = JSON.stringify(e.lngLat.wrap().lng);
            jQuery('.tagline-customize').attr('value', JSON.stringify(e.lngLat.wrap().lng) + ' / ' + JSON.stringify(e.lngLat.wrap().lat));
            jQuery('.title').find('.cus-tag').html(JSON.stringify(e.lngLat.wrap().lng) + ' / ' + JSON.stringify(e.lngLat.wrap().lat));
        });

        layers.forEach(function (layer) {
            if (layer.id === 'background') {
                jQuery.each(layer.paint, function (i, v) {
                    initial_color = v[4];
                });
            }
            if (layer.id === 'road') {
                jQuery.each(layer.paint, function (i, v) {
                    if (i == 'line-color') {
                        initial_label = v[3];
                    }
                });
            }
            if (layer.id === 'building') {
                var flagss = 0;
                jQuery.each(layer.paint, function (i, v) {
                    if (flagss == 0) {
                        initial_building = v[4];
                        flagss++;
                    }
                });
            }
            if (layer.id === 'water') {
                jQuery.each(layer.paint, function (i, v) {
                    initial_water = v;
                });
            }
			
			if (layer.id === 'landuse') {
                jQuery.each(layer.paint, function (i, v) {
					if(i === 'fill-color'){
						initial_landuse = v; 
					}
                });
            }
        });
        
        console.log(initial_color, + '  ' + initial_label + '  ' + initial_building + '  ' + initial_water);

        jQuery(document).on('click', '.styles-essentials', function () {
            var color = jQuery(this).attr('data-value');
            //var holo = jQuery(this).attr('data-holo');
            var label = jQuery(this).attr('data-label');
            var building = jQuery(this).attr('data-building');
            var water = jQuery(this).attr('data-water');
            var landuse = jQuery(this).attr('data-landuse');
			

            layers.forEach(function (layer) {
                if (layer.type === 'line') {
                    // label != '' ? map.setPaintProperty(layer.id, 'line-color', label) : '';
                    map.setPaintProperty(layer.id, 'line-color', label != '' ? label : initial_label);
                }
                if (layer.type === 'fill') {
                    // color != '' ? map.setPaintProperty(layer.id, 'fill-color', color) : '';
                    map.setPaintProperty(layer.id, 'fill-color', color != '' ? color : initial_color);
                }
                if (layer.type === 'background') {
                    // color != '' ? map.setPaintProperty(layer.id, 'background-color', color) : '';
                    map.setPaintProperty(layer.id, 'background-color', color != '' ? color : initial_color);
                }
                if (layer.id === 'water-shadow' || layer.id === 'water') {
                    //water != '' ?  map.setPaintProperty(layer.id, 'fill-color', water) : '';
                    map.setPaintProperty(layer.id, 'fill-color', water != '' ? water : initial_water);
                }
                if (layer.id === 'waterway') {
                    //water != '' ? map.setPaintProperty(layer.id, 'line-color', water) : '';
                    map.setPaintProperty(layer.id, 'line-color', water != '' ? water : initial_water);
                }
                if (layer.id === 'building-outline') {
                    //building != '' ? map.setPaintProperty(layer.id, 'line-color',  building) : color != '' ? map.setPaintProperty(layer.id, 'line-color',  color) : '';
                    map.setPaintProperty(layer.id, 'line-color', building != "" ? building : initial_building);
                }
                if (layer.id === 'building') {
                    //building != '' ? map.setPaintProperty(layer.id, 'fill-color', building) : color != '' ? map.setPaintProperty(layer.id, 'fill-color',  color): '';
                    map.setPaintProperty(layer.id, 'fill-color', building != "" ? building : initial_building);
                    //building != '' ? map.setPaintProperty(layer.id, 'fill-outline-color', building) : color != '' ? map.setPaintProperty(layer.id, 'fill-outline-color',  color): '';
                    map.setPaintProperty(layer.id, 'fill-outline-color', building != "" ? building : initial_building);
                }
                if (layer.id === 'landuse') {
                    //building != '' ? map.setPaintProperty(layer.id, 'fill-color', building) : color != '' ? map.setPaintProperty(layer.id, 'fill-color',  color) : '';
                    map.setPaintProperty(layer.id, 'fill-color', landuse != "" ? landuse : initial_landuse);
                }
            });
        });

        layers.forEach(function (layer) {
            if (layer.type === 'symbol') {
                map.removeLayer(layer.id);
            }
        });
        jQuery('.layout-outside-design').show();
        //jQuery('.style1').trigger('click');
        map.resize();

		if (window.location.href.indexOf("style_plugin_options") > -1) {
			jQuery('.styles-essentials').trigger('click');
			jQuery('.save_style').hide();
		}
        
        //jQuery('.styles-essentials.active').trigger('click');
    });

    var geocoder = new MapboxGeocoder({
        accessToken: mapboxgl.accessToken,
        mapboxgl: mapboxgl,
		marker: false,
    });
    document.getElementById('geocoder').appendChild(geocoder.onAdd(map));
    
    geocoder.on('result', function (e) {
		if(jQuery(document).find('#celestial-map').length){
			updateStarmap(e.result.geometry.coordinates[1], e.result.geometry.coordinates[0]);
		}	
        jQuery('.tagline-customize').attr('value', e.result.geometry.coordinates[0] + ' / ' + e.result.geometry.coordinates[1]);
        jQuery('.title').find('.cus-tag').html(e.result.geometry.coordinates[0] + ' / ' + e.result.geometry.coordinates[1]);

        jQuery('.title-cus').attr('value', e.result.text);
        jQuery('.title').find('h1').html(e.result.text);

        jQuery('.subtitle-customize').attr('value', e.result.place_name);
        jQuery('.title').find('.cus-subtitle').html(e.result.place_name);
        
         
    });
    
    
     jQuery(document).on('click', '.styles-essentials', function () {
        jQuery('.styles-essentials').each(function () {
            jQuery(this).removeClass('active');
        });
        jQuery(this).addClass('active');
        map.resize();
    });

    var mapDiv = document.getElementById('map');

    jQuery(document).on('keyup', '.title-cus', function () {
        var text = jQuery(this).val();
        jQuery('.title').find('h1').text(text);
    });

    jQuery(document).on('keyup', '.subtitle-customize', function () {
        var text = jQuery(this).val();
        jQuery('.title').find('.cus-subtitle').text(text);
    });
	jQuery(document).on('keyup', '.message-customize', function () {
        var text = jQuery(this).val();
        jQuery('.title').find('.starmap-message').text(text);
    });
    jQuery(document).on('keyup', '.tagline-customize', function () {
        var text = jQuery(this).val();
        jQuery('.title').find('.cus-tag').text(text);
    });

    jQuery(document).on('click', '.label_personalize', function () {
        var value = jQuery(this).attr('data-value');
        if (value == 'on') {
            jQuery('.layout-customize').removeClass('hide-label');
        } else {
            jQuery('.layout-customize').addClass('hide-label');
        }
    });
	
	jQuery(document).on('click', '.time_label', function () {
		jQuery('.time_label').each(function () {
            jQuery(this).removeClass('active');
        });
		jQuery(this).addClass('active');
        var value = jQuery(this).attr('data-value');
        if (value == 'on') {
            jQuery('.layout-customize').find('.time-label').show();;
        } else {
            jQuery('.layout-customize').find('.time-label').hide();
        }
    });

    jQuery(document).on('click', '.citymap-layout', function () {
        var value = jQuery(this).attr('data-value');

        jQuery('.citymap-layout').each(function (i, v) {
            jQuery('.layout-outside-design').removeClass('layout-' + i);
        });

        jQuery('.layout-outside-design').addClass('layout-' + value);

        map.resize();
    });


    jQuery(document).on('click', '.orientation_finalize', function () {
        var value = jQuery(this).attr('data-value');
        jQuery('.outter').removeClass('landscape');
        jQuery('.outter').removeClass('portrait');

        jQuery('.outter').addClass(value);

        map.resize();
    });
    jQuery(document).on('click', '.font_changer', function () {
        jQuery('.font_changer').each(function () {
            jQuery(this).removeClass('active');
        });
        jQuery(this).addClass('active');
        var value = jQuery(this).attr('data-value');
        jQuery("h1.fusion-responsive-typography-calculated").removeClass('font-Euphemia-UCAS');
        jQuery("h1.fusion-responsive-typography-calculated").removeClass('font-D-DIN-Condensed');
        jQuery("h1.fusion-responsive-typography-calculated").addClass(value);
    });

    jQuery(document).on('click', '.format_finalize', function () {
        var value = jQuery(this).attr('data-value');

        jQuery('.format_finalize').each(function (i, v) {
            var val = jQuery(this).attr('data-value');
            jQuery(this).removeClass();
            jQuery(this).addClass('format_finalize');

            jQuery('.outter').removeClass('size-' + val);
            jQuery('.layout-outside-design').removeClass('format-' + val);
        });

        //jQuery('.outter').addClass('size-' + value);
        //jQuery('.layout-outside-design').addClass('format-' + value);
        jQuery('.outter').addClass('size-23x17' );
        jQuery('.layout-outside-design').addClass('format-23x17');


        var res = value.split("x");
        
         var milimeter = jQuery(this).attr('data-milimeter');
         var mili_res = milimeter.split("x");
        value
        if (jQuery('.outter').hasClass('landscape')) {
//            jQuery('.outter').find('.horizontal').find('i').text(res[1] + ' inch');
//            jQuery('.outter').find('.vertical').find('i').text(res[0] + ' inch');
            jQuery('.outter').find('.horizontal').find('i').text(mili_res[1] + ' mm');
            jQuery('.outter').find('.vertical').find('i').text(mili_res[0] + ' mm');
        } else {
//            jQuery('.outter').find('.horizontal').find('i').text(res[0] + ' inch');
//            jQuery('.outter').find('.vertical').find('i').text(res[1] + ' inch');
            jQuery('.outter').find('.horizontal').find('i').text(mili_res[0] + ' mm');
            jQuery('.outter').find('.vertical').find('i').text(mili_res[1] + ' mm');
        }
        var frame_price=0;
        if (jQuery('.outter').hasClass('sel_frame')) {
           var frame_price = 20;
        } else {
            var frame_price = 0;
        }
        var formate_price = jQuery(this).attr('data-format-price-usd');
       //alert();

    var c_symbol = jQuery('span.product_price_amount_span span.woocommerce-Price-amount.amount span.woocommerce-Price-currencySymbol').text();
     
         var new_add_to_cart = Number(formate_price)+Number(frame_price)

        jQuery('.product_price_amount').html(c_symbol+new_add_to_cart);

        map.resize();
    });


    /****************************************************************/

    jQuery(document).on('click', '.label_personalize', function () {
        jQuery('.label_personalize').each(function () {
            jQuery(this).removeClass('active');
        });
        
        jQuery('.outter').removeClass('on_label');
        jQuery('.outter').removeClass('off_label');
        if(jQuery(this).attr('data-value') === 'on'){
            jQuery('.outter').addClass('on_label');           
        } else if(jQuery(this).attr('data-value') === 'off'){
            jQuery('.outter').addClass('off_label'); 
        }

        jQuery(this).addClass('active');

        map.resize();
    });
	
	jQuery(document).on('click', '.marker_turn', function () {
        jQuery('.marker_turn').each(function () {
            jQuery(this).removeClass('active');
        });
        
        jQuery('.outter').removeClass('on_marker');
        jQuery('.outter').removeClass('off_marker');
        if(jQuery(this).attr('data-value') === 'on'){
            jQuery('.outter').addClass('on_marker');           
        } else if(jQuery(this).attr('data-value') === 'off'){
            jQuery('.outter').addClass('off_marker'); 
        }

        jQuery(this).addClass('active');

        map.resize();
    });

    jQuery(document).on('click', '.format_finalize', function () {
        jQuery('.format_finalize').each(function () {
            jQuery(this).removeClass('active');
        });
        jQuery(this).addClass('active');
        map.resize();
    });

    jQuery(document).on('click', '.map-style-layout', function () {
        jQuery('.map-style-layout').each(function () {
            jQuery(this).removeClass('active');
			jQuery(document).find('.style-options-wrap').hide();
        });
        jQuery(this).addClass('active');
    });
 

    jQuery(document).on('click', '.frame_finalize', function () {
        var sel_frame = jQuery(this).attr("data-value");
        //alert(sel_frame);
        jQuery('.frame_finalize').each(function () {
            jQuery(this).removeClass('active');
        });
        
        
        jQuery('.sel_outer_frame').removeClass('sel_frame_non');
        jQuery('.sel_outer_frame').removeClass('sel_frame_white');
        jQuery('.sel_outer_frame').removeClass('sel_frame_black');
        jQuery('.sel_outer_frame').removeClass('sel_frame_oak');
        jQuery('.sel_outer_frame').removeClass('sel_frame_silver');
        jQuery('.sel_outer_frame').addClass('sel_frame_'+sel_frame);
        
        
        
        jQuery(this).addClass('active');
        jQuery('.outter').addClass("sel_frame");
        var frame_price=0;
        if (jQuery('.outter').hasClass('sel_frame')) {
           var frame_price = 20;
        } else {
            var frame_price = 0;
        }
        var formate_price = jQuery('.format_finalize.active').attr('data-format-price-usd');
       //alert(formate_price);
    var c_symbol = jQuery('span.product_price_amount_span span.woocommerce-Price-amount.amount span.woocommerce-Price-currencySymbol').text();

       var new_add_to_cart = Number(formate_price)+Number(frame_price)

        jQuery('.product_price_amount').html(c_symbol+new_add_to_cart);

        map.resize();

    });

    jQuery(document).on('click', '.orientation_finalize', function () {
        jQuery('.orientation_finalize').each(function () {
            jQuery(this).removeClass('active');
        });
        jQuery(this).addClass('active');
        var value = jQuery('.format_finalize.active').attr('data-value');
        var res = value.split("x");
        var milimeter = jQuery('.format_finalize.active').attr('data-milimeter');
        var mili_res = milimeter.split("x");
        if (jQuery('.orientation-landscape').hasClass('active')) {
//            jQuery('.outter').find('.horizontal').find('i').text(res[1] + ' inch');
//            jQuery('.outter').find('.vertical').find('i').text(res[0] + ' inch');
            jQuery('.outter').find('.horizontal').find('i').text(mili_res[1] + ' mm');
            jQuery('.outter').find('.vertical').find('i').text(mili_res[0] + ' mm');
        } else {
//            jQuery('.outter').find('.horizontal').find('i').text(res[0] + ' inch');
//            jQuery('.outter').find('.vertical').find('i').text(res[1] + ' inch');
            jQuery('.outter').find('.horizontal').find('i').text(mili_res[0] + ' mm');
            jQuery('.outter').find('.vertical').find('i').text(mili_res[1] + ' mm');
        }

        map.resize();
    });

    jQuery(document).on('click', '.citymap-layout', function () {
        jQuery('.citymap-layout').each(function () {
            jQuery(this).removeClass('active');
        });
        jQuery(this).addClass('active');
        map.resize();
    });
    
    jQuery(document).on('click', '.frame-non', function(){
        jQuery('.outter').removeClass('sel_frame');
        jQuery('.format_finalize.active').trigger('click');
    });
 
   

    jQuery(document).on('click', '.nav-tabs', function () {
        map.resize();
    });

    jQuery(document).on('click', '.addToCart', function () {
        var product_image;
        window.scrollTo(0,0);
        html2canvas(jQuery('.outter').get(0), {
            allowTaint: true,
            useCORS: true,
            scale: 5,
        }).then(function (canvas) {
			
			console.log('zoom', zoom);
            product_image = canvas.toDataURL('image/png');

            console.log(product_image);
            // Split the base64 string in data and contentType
            var block = product_image.split(";");
            // Get the content type
            var contentType = block[0].split(":")[1];// In this case "image/gif"
            // get the real base64 content of the file
            var realData = block[1].split(",")[1];// In this case "iVBORw0KGg...."

            // Convert to blob
            var blob = b64toBlob(realData, contentType);

            console.log(blob);
			
			var fontWeight = jQuery('.title').find('h1').css('font-weight');
			var fontFamily = jQuery('.title').find('h1').css('font-family');
			var fontSize = jQuery('.title').find('h1').css('font-size');
			
			//var fontData = jQuery('.title').find('h1').attr('style');

			if(jQuery('.outter').hasClass('sel_frame')){
				var backgroundColor = jQuery('.sel_frame').css('background-color');
			} else {
				var backgroundColor = 'none';
			}
			
			var orientation = '';
			
			if(jQuery('.outter').hasClass('portrait')){
				orientation = 'portrait';
			} else {
				orientation = 'landscape';
			}
			
			var mainSize = jQuery('.format_finalize.active').text();
			
			var sizeMilimeter = jQuery('.format_finalize.active').attr('data-milimeter');
				
			
            var fd = new FormData();
            //var name = 'd' + Math.floor(Math.random()*1000001);
            //download(product_image, name+'.png', "image/png");
            var title = jQuery('.title-cus').attr('value');
            var product_data = jQuery('.layout-customize .title').html();
            var subtitle = jQuery('.subtitle-customize').attr('value');
            var tagline = jQuery('.tagline-customize').attr('value');
            //zoom = map.getZoom();
            var longlat = tagline.split('/');
            var link = jQuery('.styles-essentials.active').attr('data-styles') + '/edit/#' + zoom + '/' + jQuery.trim(longlat[1]) + '/' + jQuery.trim(longlat[0]);
            var price;
            var size;
            var c_symbol = jQuery('span.product_price_amount_span span.woocommerce-Price-amount.amount span.woocommerce-Price-currencySymbol').text();
            jQuery('.format_finalize').each(function () {
                if (jQuery(this).hasClass('active')) {
                    if (jQuery('.outter').hasClass('sel_frame')) {
                    price1 = jQuery(this).attr('data-format-price-usd');
                    var frame_price = 20;

                    var new_price =Number(price1)+Number(frame_price);
                    var price = c_symbol+new_price;
                    size = jQuery(this).attr('data-value');
                    fd.append('price', price);
                       fd.append('size', size);
                    } else{
                       price = jQuery(this).attr('data-format-price-usd');
                       size = jQuery(this).attr('data-value');
                       fd.append('price', price);
                       fd.append('size', size);
                    }
                    
                }
            });

            fd.append('title', title);
            //fd.append('title', 'wocommerce_add_to_card');
            fd.append('subtitle', subtitle);
            fd.append('tagline', tagline);
            fd.append('product_image', blob);
            fd.append('link', link);
			fd.append('fontWeight', fontWeight);
			fd.append('fontData', fontData);
			fd.append('fontFamily', fontFamily);
			fd.append('fontSize', fontSize);
			fd.append('backgroundColor', backgroundColor);
			fd.append('mainSize', mainSize);
			fd.append('sizeMilimeter', sizeMilimeter);
			fd.append('orientation', orientation);
            fd.append('action', 'wocommerce_add_to_card');

            jQuery.ajax({
                url: flatsomeVars.ajaxurl,
                type: "post",
                dataType: 'json',
                contentType: false,
                processData: false,
                cache: false,
                data: fd,
                beforeSend: function () {
                    // setting a timeout
                    jQuery('.addToCart').addClass('loading');
                    jQuery('.addToCart').attr('disabled', 'disabled');
                    
                    //jQuery('td.product-name').append(product_data);
                },
                success: function (response) {
                    jQuery('.addToCart').addClass('loading');
                    if (response.status) {
                        //alert(response.Message);
                        window.location.href = response.data;
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    console.log(errorThrown);
                }
            });
        });
    });

    function b64toBlob(b64Data, contentType, sliceSize) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, {type: contentType});
        return blob;
    }

    jQuery(document).on('click', '.save_style', function () {
        jQuery('.styles-essentials').click();
        var c = jQuery('.style-meta').find('.mapboxgl-canvas').get(0);
        var url = c.toDataURL("image/jpeg", 1.0)
        var t = c.getContext('2d');
        //console.log(url);
        jQuery('.style-image-value').val(url);
        var formData = jQuery('.style-save-data').serializeArray();
        
        if(longitude == '' || longitude == 'undefined' || latitude == '' || latitude == 'undefined'){
            var longlat = jQuery('.cus-tag').text();
            longlat = jQuery.trim(longlat);
            longlat = longlat.split('/');
            longitude = longlat[1];
            latitude = latitude[0];
        }     
		
		console.log(initial_color + '  ' + initial_label + '  ' + initial_water + '  ' + initial_building + '  ' + initial_landuse);
       
        //console.log(zoom + ' '+ longitude + ' '+latitude);
        var data = {
            action: 'save_style_design',
            formData: formData,
            longitude: longitude,
            latitude: latitude,
            zoom: zoom,
            initialColor : initial_color,
            initialLabel : initial_label,
            initialWater : initial_water,
            initialBuilding : initial_building,
            initialLanduse : initial_landuse, 
        };
        //return false;

        jQuery.ajax({
            type: "post",
            url: ajaxurl,
            data: data,
            dataType: 'json',
            beforeSend: function(){
              jQuery('#wpwrap').addClass('main-loader');  
            },
            success: function (response) {
                console.log(response);
                if (response.status) {
                    alert(response.message);
                    window.location.href = getUrl.origin + window.location.pathname + '?page=style-lists';
                }
            }
        });
    });

    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    };


    jQuery(".mapboxgl-ctrl-geocoder--input").attr("placeholder", "Zoeken");
    jQuery('.mapboxgl-canvas').addClass('mapboxgl-canvas-custom-style');
	
	
// Some prettifying styles

});
var starmapConfig = {},
		starmapUpdateDelay = 0,
		timezone_offset = -120,
		font = 'Montserrat',
		layout = 1,
		floatVals = ['circular','grid','lat','lng','milkyway','names','floatVals'],
		starmapUpdateTime;
var k_diff = 4.5,
reduce_for_circular = 1.5;
jQuery(document).ready(function(){
	jQuery('[name="year"]').val((new Date()).getFullYear());
	jQuery('[name="month"] option').eq((new Date()).getMonth()).attr("selected","selected");
	jQuery('[name="day"]').val((new Date()).getDate());
	updateDate();
	var latLong = jQuery(document).find('p.cus-tag').text();
	var latLong = latLong.split(' / ');
	
	
	floatVals.lng = latLong[0];
	floatVals.lat = latLong[1];
	var k_diff_map = 2;
	var config = {
	  projection: "aitoff",
	  orientationfixed: true,
	  adaptable: true,
	  interactive: false,
	  form: false,
	  location: false,
	  controls: true,
	  lang: '',
	  center: [parseFloat(floatVals.lng), parseFloat(floatVals.lat), 1],
	  background: {
		fill: "#0f1d42",
		stroke: "#000000",
		opacity: 1
	  },
	  datapath: pluginUrl+"data/",
	  stars: {
				show: true,
				limit: 5,
				colors: false,
				style: {
					fill: "#ffffff",
					opacity: 1
				},
				// names
				names: false,
				proper: false,
				desig: false,
				namelimit: 4,
				namestyle: {
					fill: "#ffffff",
					font: "22px ",
					align: "left",
					baseline: "top"
				},
				propernamestyle : {
					fill: "#ffffff",
					font: "20px",
					align: "right",
					baseline: "bottom"
				},
				propernamelimit: 1.5,
				size: 40 / k_diff / reduce_for_circular / k_diff_map,
				exponent: -0.33,
				data: 'stars.6.json'
			},
			dsos: { show: false },
			mw: {
				// milkyway
				show: false,
				style: {
					fill: "#ffffff",
					opacity: "0.15"
				}
			},
		constellations: { names: false, lines: false },
		lines: { 
			graticule: { show: false, stroke:"#9999cc", width: 1.0, opacity:.3 },
			equatorial: { show: false, stroke:"#aaaaaa", width: 1.5, opacity:.4 },  
			ecliptic: { show: false, stroke:"#66cc66", width: 1.5, opacity:.4 }  
		}
	};
	jQuery(document).on('click','.layout-star',function(){
		jQuery.ajax({
			type: 'POST',
			dataType: 'json',
			url: flatsomeVars.ajaxurl,
			data: {
				'action': 'star_map'
			},
			success: function(response) {
				jQuery(document).find('.DesktopView .map-design').hide();
				jQuery(document).find('.style-options-wrap').show();
				jQuery(document).find('.DesktopView .map-design').after('<div id="celestial-map"></div>');
				Celestial.display(config);
			}
		});
	});
	jQuery(document).on('input','[data-starmap-input-date]',function(){
		var latLong = jQuery(document).find('p.cus-tag').text();
		var latLong = latLong.split(' / ');
		updateDate();
		if(jQuery("#celestial-map").length){
			updateStarmap(parseFloat(latLong[0]), parseFloat(latLong[1]));
		}
	});
	
	jQuery('.constellations-swich').on('click', function(){
		jQuery(this).toggleClass('is-checked'); 
		if(jQuery(this).hasClass('is-checked')){
			starmapConfig.lines = 1;
			updateStarMapSecond();
		}else{
			starmapConfig.lines = 0;
			updateStarMapSecond();
		}
	});
	jQuery('.grid-swich').on('click', function(){
		jQuery(this).toggleClass('is-checked'); 
		if(jQuery(this).hasClass('is-checked')){
			starmapConfig.grid = 1;
			updateStarMapSecond();
		}else{
			starmapConfig.grid = 0;
			updateStarMapSecond();
		}
	});
	jQuery(document).on('click','[data-starmap]',function(){
		Cookies.set('starmap',starmapConfig);
		var param = jQuery(this).attr('data-starmap');
		var value = jQuery(this).attr('data-value');
		if(param == 'layout'){
			starmapConfig.layout = jQuery(this).attr('data-value');
			jQuery('[data-starmap="layout"]').removeClass('active').parent().find('[data-value="'+starmapConfig.layout+'"]').addClass('active');
			updateStarmapStyle(param,value);
/* 			if(value == 3 || value == 4){
				updateStarmapStyle([param, 'rectangle'], [value, 0]);
			}
			else{
				updateStarmapStyle([param, 'circular'], [value, 1]);
			} */
		}
		if(param == 'color'){
			starmapConfig.color = value;
			jQuery('[data-starmap="color"]').removeClass('active').parent().find('[data-value="'+starmapConfig.color+'"]').addClass('active');
			updateStarmapStyle(param,value);
		}
		
	});
	jQuery(window).resize(function() {
		if (jQuery(window).width() < 767) {
			var width = jQuery(window).width();
			Celestial.resize({width:width-120});
		}else if (jQuery(window).width() > 767 && jQuery(window).width() < 1026){
			Celestial.resize({width:375});
		}
	});
	if (jQuery(window).width() < 767) {
		var width = jQuery(window).width();
		Celestial.resize({width:width-120});
	}else if (jQuery(window).width() > 767 && jQuery(window).width() < 1026){
		Celestial.resize({width:375});
	}
	jQuery('#timepicker').timepicker({
		timeFormat: 'h:mm p',
		dynamic: false,
		dropdown: true,
		scrollbar: true,
		change: updateTime
	});
});
function updateTime(){
	var time = jQuery('#timepicker').val();
		jQuery('.layout-customize').find('.time-label').text(time);
}
function updateStarmapStyle(param,value) {
	var color = jQuery('.level-1.active').attr('data-value');
	if(param == 'layout'){
		var layout = value;
		jQuery('.poster > div').removeClass(function (index, className){
			return (className.match (/(^|\s)layout-\S+/g) || []).join(' ');
		}).addClass('layout-'+layout);
		if (layout == 3 || layout == 4) {
			jQuery('.poster > div').removeClass('starmap-circular circular');
			jQuery('.poster > div').addClass('rectangle');
			Celestial.resize({width:800});
		} else {
			jQuery('.poster > div').removeClass('rectangle');
			jQuery('.poster > div').addClass('starmap-circular circular');
			Celestial.resize({width:375});
		}
		if (layout == 0) {
			jQuery(document).find('.layout-0 canvas').css('background-color','#'+color);
		}else{
			jQuery(document).find('canvas').css('background-color','transparent');
		}
	}
	if(param == 'color'){
		var lay = jQuery('.layout-options').find('.active').attr('data-value');
		if(lay == 0){
			jQuery(document).find('.layout-0 canvas').css('background-color','#'+color);
		}else{
			jQuery(document).find('canvas').css('background-color','transparent');
		}
	}
	jQuery('.poster > div, .starmap-poster-label, #celestial-map-in > i').css('background-color','#'+color);
	var elementColor = 'ffffff',
    k_diff_map = 1;
	Celestial.apply({
		mw: {
			show: starmapConfig.milkyway,
			style: {
				fill: '#' + elementColor,
				opacity: '0.15'
			}
		},
		constellations: {
			lines: parseInt(starmapConfig.lines),
			linestyle: {
				stroke: '#' + elementColor,
				width: 1 / k_diff * 3 / k_diff_map,
				opacity: 0.5
			}
		},
		lines: {
			graticule: {
				show: starmapConfig.grid == 1 ? true : false,
				stroke: '#' + elementColor,
				width: 1,
				opacity: 0.5
			}
		},
	});
	
}
function updateStarMapSecond() {
	var elementColor = 'ffffff',
    k_diff_map = 1;
	Celestial.apply({
		mw: {
			show: starmapConfig.milkyway,
			style: {
				fill: '#' + elementColor,
				opacity: '0.15'
			}
		},
		constellations: {
			lines: parseInt(starmapConfig.lines),
			linestyle: {
				stroke: '#' + elementColor,
				width: 1 / k_diff * 3 / k_diff_map,
				opacity: 0.3
			}
		},
		lines: {
			graticule: {
				show: starmapConfig.grid == 1 ? true : false,
				stroke: '#' + elementColor,
				width: 1,
				opacity: 0.3
			}
		},
	});
}
function updateStarmap(lat, lng){
	var zone = -120;
	var date = getStarmapDate();
	var date = new Date(moment(date+' 00:00:00')._d);
	var tz = date.getTimezoneOffset();
    var dtc = new Date(date.valueOf() + (zone - tz) * 60000);
	var tz = date.getTimezoneOffset();
    var dtc = new Date(date.valueOf() + (zone - tz) * 60000);
	geopos = [parseFloat(lat), parseFloat(lng)];
	zenith = Celestial.getPoint(horizontal.inverse(dtc, [90, 0], geopos), 'equatorial');
	zenith[2] = 0;
	Celestial.rotate({
      		center:JSON.parse(JSON.stringify(zenith)),
      		horizon:false
  		});
}
function getStarmapDate() {
	return jQuery('[name="year"]').val()+'-'+pad(jQuery('[name="month"]').val(),2)+'-'+pad(jQuery('[name="day"]').val(),2);
}
function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}
function updateDate(){
	var monthName = jQuery('[name="month"] option:selected').text();
	var day = jQuery('[name="day"]').val();
	var year = jQuery('[name="year"]').val();
	var suffix = 'th';
	if (day == 1 || day == 21 || day == 31)
		suffix = 'st';
	else if (day == 2 || day == 22)
		suffix = 'nd';
	else if (day == 3 || day == 23)
		suffix = 'rd';
	var subtitle = day+suffix+' '+monthName+' '+year;
	jQuery(document).find('.date-subtitle').text(subtitle);
}
function createCookie(name, value, days) {
    var expires;
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        expires = "; expires="+date.toGMTString();
    }
    else {
        expires = "";
    }
    document.cookie = name+"="+value+expires+"; path=/";
}
/*map.setPaintProperty('water', 'fill-color', water);
 
 map.setPaintProperty('admin-state-province', 'line-color', label);
 map.setPaintProperty('tunnel', 'line-color', label);
 map.setPaintProperty('bridge-case', 'line-color', label);
 map.setPaintProperty('waterway', 'line-color', label);
 map.setPaintProperty('aeroway-polygon', 'fill-color', label);
 map.setPaintProperty('aeroway-line', 'line-color', label);
 map.setPaintProperty('pedestrian-path', 'line-color', label);
 map.setPaintProperty('bridge', 'line-color', label);           
 map.setPaintProperty('road', 'line-color', label);
 
 
 map.setPaintProperty('building', 'fill-color', building);  layout-dark
 map.setPaintProperty("landuse", 'fill-color', building);   
 
 map.setPaintProperty("background", 'background-color', color); 
 map.setPaintProperty("national_park", 'background-color', color);      */