<div class="container outer">
	<div class="row customize-tab">
		<div id="map" style="display: none;"></div>
		<div class="col-md-5 col-lg-5 map-left starmap-sidebar">
			<div id="sidebar-info">
				<span><strong>Customize your design</strong>
					Change location, labels and appearance
				</span>
			</div>
			<div id="sidebar" class="sidebar">
				<div class="sidebar-group active">
					<div class="sidebar-group-header"><h2 class="title">Location and date</h2></div>
					<div class="sidebar-group-content">
						<div id="geocoder" class="geocoder"></div>
						<div class="field-date" id="date_form">
							<div class="date-inputs">
								<input name="day" data-starmap-input-date class="date-input-1 datte" placeholder="Day" type="number" value="17" min="1" max="31">
								<select name="month" data-starmap-input-date class="date-input-2 monnth">
									<option value="0">January</option>
									<option value="1">February</option>
									<option value="2">March</option>
									<option value="3">April</option>
									<option value="4">May</option>
									<option value="5">June</option>
									<option value="6">July</option>
									<option value="7">August</option>
									<option value="8">September</option> 
									<option value="9">October</option>
									<option value="10">November</option>
									<option value="11">December</option>
								</select>
								<input name="year" data-starmap-input-date class="date-input-3 yearr" placeholder="Year" type="number" min="1000" max="9999">
							</div>
						</div>
						<div class="time-row">
							<div class="field-time">
								<h5>Time</h5>
								<input type="text" id="timepicker" placeholder="12:00 AM" />
							</div>
							<div class="field-checkbox">
								<h5>Print Time</h5>
								<div class="editor-btns small">
									<div>
										<div data-timemap="time" data-value="on" class="time_label active">
											ON
										</div>
									</div>

									<div> 
										<div data-timemap="time" data-value="off" class="time_label">
											OFF
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="sidebar-group">
					<div class="sidebar-group-header"><h2 class="title">Customize the style</h2></div>
					<div class="sidebar-group-content">
						<div class="style-options options starmap-options" data-single="">
							<h5>Style</h5>
							<div>
								<div class="level-1 active" data-starmap="color" data-value="0f1d42">
									<div style="background-color:#0f1d42;">
									</div>
								</div>
							</div>
							<div>
								<div class="level-1" data-starmap="color" data-value="000000">
									<div style="background-color:#000000;">
									</div>
								</div>
							</div>
							<div>
								<div class="level-1" data-starmap="color" data-value="025D8C">
									<div style="background-color:#025D8C;">
									</div>
								</div>
							</div>
							<div>
								<div class="level-1" data-starmap="color" data-value="333744">
									<div style="background-color:#333744;">
									</div>
								</div>
							</div>
							<div>
								<div class="level-1" data-starmap="color" data-value="6c6e78">
									<div style="background-color:#6c6e78;">
									</div>
								</div>
							</div>
							<div style="z-index: 9;">
								<div class="level-1" data-starmap="color" data-value="e7304d">
									<div style="background-color:#e7304d;">
									</div>
								</div>
							</div>
						</div>
						<div class="row col-md-12 col-lg-12 finalize">
							<h5>Layout</h5>
							<div class="layout-options" data-single="">
								<div class="layout-1">
									<div data-starmap="layout" data-value="1" class="active">
										<svg width="41" height="59" viewBox="0 0 41 59" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect class="fill stroke" x="0.5" y="0.5" width="39.904" height="57.2573" rx="2.5" fill="#4E4E4E" stroke="#4E4E4E"></rect>
										<path class="stroke" d="M0.5 48.5H40.5V55C40.5 56.3807 39.3807 57.5 38 57.5H3C1.61929 57.5 0.5 56.3807 0.5 55V48.5Z" fill="white" stroke="#4E4E4E"></path>
										<rect class="fill" x="4" y="51" width="12" height="4" rx="2" fill="#4E4E4E"></rect>
										<rect class="fill" x="25" y="51" width="12" height="4" rx="2" fill="#4E4E4E"></rect>
										<circle cx="20.0149" cy="24.1707" r="12.5149" stroke="#F0F0F0"></circle>
										</svg>
									</div>
								</div>
								<div class="layout-0">
									<div data-starmap="layout" data-value="0" class="">
										<svg width="41" height="59" viewBox="0 0 41 59" fill="none" xmlns="http://www.w3.org/2000/svg">
										<circle class="fill stroke" cx="20.0149" cy="24.1707" r="12.5149" fill="#4E4E4E" stroke="#4E4E4E"></circle>
										<rect class="stroke" x="0.5" y="0.5" width="39.904" height="57.2573" rx="2.5" stroke="#4E4E4E"></rect>
										<rect class="fill" x="12.3945" y="49.5806" width="16.1137" height="3.71855" rx="1.85927" fill="#4E4E4E"></rect>
										</svg>
									</div>
								</div>
								<div class="layout-2">
									<div data-starmap="layout" data-value="2" class="">
										<svg width="41" height="59" viewBox="0 0 41 59" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect class="fill stroke" x="0.5" y="0.5" width="39.904" height="57.2573" rx="2.5" fill="#4E4E4E" stroke="#4E4E4E"></rect>
										<circle cx="20.4524" cy="24.1707" r="12.5149" stroke="#f2f2ef"></circle>
										<rect x="12.3945" y="49.5806" width="16.1137" height="3.71855" rx="1.85927" fill="#f2f2ef"></rect>
										</svg>
									</div>
								</div>
								<div class="layout-3">
									<div data-starmap="layout" data-value="3" class="">
										<svg width="41" height="59" viewBox="0 0 41 59" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect class="fill stroke" x="0.5" y="0.5" width="39.904" height="57.2573" rx="2.5" fill="#4E4E4E" stroke="#4E4E4E"></rect>
										<path class="stroke" d="M0.5 48.5H40.5V55C40.5 56.3807 39.3807 57.5 38 57.5H3C1.61929 57.5 0.5 56.3807 0.5 55V48.5Z" fill="#f2f2ef" stroke="#4E4E4E"></path>
										<rect class="fill" x="25" y="51" width="12" height="4" rx="2" fill="#4E4E4E"></rect>
										<rect class="fill" x="4" y="51" width="12" height="4" rx="2" fill="#4E4E4E"></rect>
										</svg>
									</div>
								</div>
								<div class="layout-4">
									<div data-starmap="layout" data-value="4" class="">
										<svg width="41" height="59" viewBox="0 0 41 59" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect class="fill stroke" x="0.5" y="0.5" width="39.904" height="57.2573" rx="2.5" fill="#4E4E4E" stroke="#4E4E4E"></rect>
										<rect x="12.3945" y="49.5806" width="16.1137" height="3.71855" rx="1.85927" fill="#f2f2ef"></rect>
										</svg>
									</div>
								</div>
							</div>
						</div>
						<div class="row col-md-12 col-lg-12 style-options">
							<div class="style-item constellations-input">
								<label class="item_label">Constellations</label>
								<div class="item_content">
									<div role="switch" class="el-switch item-switch constellations-swich">
										<input type="checkbox" name="" true-value="true" class="switch_input">
										<span class="switch_core" style="width: 40px;"></span>
									</div>
								</div>
							</div>
							<div class="style-item">
								<label class="item_label">Enable grid</label>
								<div class="item_content">
									<div role="switch" class="item-switch el-switch grid-swich">
										<input type="checkbox" name="" true-value="true" class="switch_input">
										<span class="switch_core" style="width: 40px;"></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="sidebar-group">
					<div class="sidebar-group-header">
						<h2 class="title">Customize the text</h2>
					</div>
					<div class="sidebar-group-content">
						<h5>Title</h5>
						<input type="text" class="title-customize title-cus" placeholder="Titel" value="The Windy City" maxlength="100">
						<h5>Subtitle</h5>
						<input type="text" class="title-customize subtitle-customize" placeholder="Subtitel" value="Chicago, Illinois" maxlength="100">
						<input type="text" class="title-customize tagline-customize" hidden placeholder="
						" value="-87.74838796981078 / 41.909905163235294" maxlength="150">
						<h5>Message</h5>
						<input class="message-customize" maxlength="180" name="text" placeholder="Message">
					</div>
				</div>
				<div class="sidebar-group">
					<div class="sidebar-group-header">
						<h2 class="title">Select Print Size</h2>
					</div>
					<div class="sidebar-group-content">
						<div class="row col-md-12 col-lg-12">
							<div class="row col-md-12 col-lg-12" style="display: none">
								<h5>Oriëntatie </h5>							
								<div class="editor-btns small">
									<div>
										<div data-citymap="orientation" data-value="portrait" class="active orientation_finalize orientation-portrait">
											Staand
										</div>
									</div>
									<div>
										<div data-citymap="orientation" data-value="landscape" class="orientation_finalize orientation-landscape">
											Liggend
										</div>
									</div>
								</div>
							</div>
							<div class="row col-md-12 col-lg-12">
								<h5>Format</h5>
								<div class="editor-btns small">
                                <div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="40x50" data-milimeter="40x50" class="active format_finalize 40x50">40X50cm</div>
									</div>
                                    <div>
										<div data-citymap="format" data-format-price-usd="35.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="50x70" data-milimeter="50x70" class="active format_finalize 50x70">50X70cm</div>
									</div>
									<!--<div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="12x8" data-milimeter="210x297" class="active format_finalize A4_format">A4</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="17x12" data-milimeter="297x420" class="format_finalize A3_format">A3</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-milimeter="420x594" data-value="23x17" class="format_finalize A2_format">
                                        A2</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="33x23" data-milimeter="594x841" class=" format_finalize A1_format">
										A1</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="20.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="47x33" data-milimeter="1189x841" class=" format_finalize A0_format">
										A0</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="40.00" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="28x20" data-milimeter="500x707" class="format_finalize B2_format">
										B2</div>
									</div>
									<div>
										<div data-citymap="format" data-format-price-usd="34.99" data-format-price-eur="49" data-format-price-gbp="50" data-format-price-cad="65" data-format-price-aud="65" data-value="39x28" data-milimeter="707x1000" class="format_finalize B1_format">
										B1</div>
									</div>-->
								</div>
							</div>
						</div>
					</div>
				</div>
                <div class="sidebar-group">
					<div class="sidebar-group-header">
						<h2 class="title">Add on a Frame</h2>
					</div>
					<div class="sidebar-group-content">
						<div class="row col-md-12 col-lg-12">
							<div class="row col-md-12 col-lg-12" style="display: none">
								<h5>Oriëntatie </h5>							
								<div class="editor-btns small">
									<div>
										<div data-citymap="orientation" data-value="portrait" class="active orientation_finalize orientation-portrait">
											Staand
										</div>
									</div>
									<div>
										<div data-citymap="orientation" data-value="landscape" class="orientation_finalize orientation-landscape">
											Liggend
										</div>
									</div>
								</div>
							</div>
							<div class="row col-md-12 col-lg-12">
								<h5>List</h5>
								<div class="editor-btns small">
                                    <div>
										<div data-citymap="frame" data-value="black" class="frame_finalize frame-black">
										40X50cm 
										</div>
									</div>
                                    <div>
										<div data-citymap="frame" data-value="white" class="frame_finalize frame-white">
										50X70cm
										</div>
									</div>
									<!--<div>
										<div data-citymap="frame" data-value="non" class="frame_finalize frame-non active padding25px">
											Geen<br>
										</div>
									</div>
									<div>
										<div data-citymap="frame" data-value="black" class="frame_finalize frame-black">
										Aluminium zwart (10 mm)
										</div>
									</div>
									<div>
										<div data-citymap="frame" data-value="white" class="frame_finalize frame-white">
										Aluminium goud (10 mm)
										</div>
									</div>
									<div>
										<div data-citymap="frame" data-value="oak" class="frame_finalize frame-oak">
										Hout zwart (15 mm)
										</div>
									</div>
									<div>
										<div data-citymap="frame" data-value="silver" class="frame_finalize frame-silver">
										Hout blank (15 mm)
										</div>
									</div>-->
								</div>
							</div>
						
						</div>
					</div>
				</div>
			</div>
			<div class="Cart">
				<span class="product_price_amount_span" style="display:none">20</span>
				<button class="addToCart btn btn-primary btn-lg">Add to cart(<span class="product_price_amount"><?php echo wc_price(20); ?></span>)</button>
			</div>
		</div>
		<div class="col-md-7 col-lg-7">
			<div class="outter portrait size-23x17 sel_outer_frame sel_frame_non on_label">
				<div class="layout-outside-design-outer-borer poster">
					<div class="starmap-layout starmap-poster-format- layout-  starmap-circular circular starmap-poster-format-12x18 layout-1" style="padding-bottom: 135.3%; background-color: rgb(15, 29, 66);">
						<div class="map">
							<div id="celestial-map-wrap">

								<div id="celestial-map"></div>
							</div>
						</div>
						<div class="layout-customize smallFont starmap-poster-label">
							<div class="title starmap-poster-left">
								<h1 class="fusion-responsive-typography-calculated title font-D-DIN-Condensed">The Windy City</h1>
								<p class="cus-subtitle font-Euphemia-UCAS">Chicago, Illinois</p>
								<p class="date-subtitle">21st May 2021</p>
								<p class="cus-tag">-87.74838796981078 / 41.909905163235294</p>
								<p class="starmap-message"></p>
								<p class="time-label">12:00 AM</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	var config = {
	  projection: "airy",
	  width: 300,
	  orientationfixed: true,
	  adaptable: true,
	  interactive: false,
	  form: false,
	  location: false,
	  controls: false,
	  lang: '',
	  center: [-87.74838796981078,41.909905163235294],
	  background: {
		fill: "transparent",
		stroke: "transparent",
		opacity: 1
	  },
	  datapath: pluginUrl+"data/",
	  stars: {
				show: true,
				limit: 7,
				colors: false,
				style: {
					fill: "#ffffff",
					opacity: 1
				},
				// names
				names: false,
				proper: false,
				desig: false,
				namelimit: 4,
				namestyle: {
					fill: "#ffffff",
					font: "10px ",
					align: "left",
					baseline: "top"
				},
				propernamestyle : {
					fill: "#ffffff",
					font: "10px",
					align: "right",
					baseline: "bottom"
				},
				propernamelimit: 1.5,
				size: 3,
				exponent: -0.33,
				data: 'stars.6.json'
			},
			dsos: { show: false },
			mw: {
				// milkyway
				show: false,
				style: {
					fill: "#ffffff",
					opacity: "0.15"
				}
			},
		constellations: { names: false, lines: false },
		lines: { 
			graticule: { show: false, stroke:"#9999cc", width: 1.0, opacity:.3 },
			equatorial: { show: false, stroke:"#aaaaaa", width: 1.5, opacity:.4 },  
			ecliptic: { show: false, stroke:"#66cc66", width: 1.5, opacity:.4 }  
		}
	};
	Celestial.display(config);
</script>