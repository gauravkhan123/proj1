(function() {
console.log('content.js loaded');
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
var todayTyped = "typedWords_"+ dd + '/' + mm + '/' + yyyy;
var todayRead = "readWords_"+ dd + '/' + mm + '/' + yyyy;
var todayTimer = "timer_"+ dd + '/' + mm + '/' + yyyy;
var timerObj = {};
var dailyRoutineObj = {};
var routineTargetObj = {};
var blockWebsiteObj = {};
var funTimer = 10;
var selectedLine = 0;
var selectedString = '';
var selectedCount = '';
var getTypedCount = 0;
var getReadCount = 0;
var isMode ='';
var totalActivity = 0;
var user_id = 0;
var baseUrl = "https://development.brstdev.com/productivitystimulus";
var isTimerType = '';
var boostSetIn = '';
var is_running_time = 0;
var is_typed_word = 0;
var is_typed_word_count = 0;
var minsCantake = 1;
var runningClearIn = '';
timerObj[todayTimer] = {
	"startTime":"",
	"totalActivity":0,
	"isTimerStart":"",
	"funTab":'',
	"isFunTabPopUp":0,
	"currentTab":0,
	"isFunTabBrowsers":0,
	"targetTime":0,
	"isTimePause":0,
	"isMode":'',
	"typedWordsCount":0,
	"readWordsCount":0,
	"hpEarnPopUp":0,
	"funPopUpStartTime":0,
	'giveUp':0,
	'is_StartWriteRead':0,
	'today_strikes':0,
	'user_selected_words' :0,
	'user_typed_words':0,
	'chosen_selected_word':20,
	'chosen_typed_word':20,
	'is_pause_boost':0,
	'boost_countdown':0,
	'is_flame_start':0,
	'total_boost_time':0,
	'is_write_read_mode':'',
	'is_writing_reading_paused':0,
	'user_id':'',
	'fub_tab_url':'',
	'is_mobile_view':'',
	'is_open_fun_url':0,
	'is_break_time':'',
	'task_id':0,
	'task_target_time':0,
	'is_task_start':0,
	'task_title':'',
	'task_time_format':'',
	'task_start_time':'',
	'user_current_level':0
}
routineTargetObj[todayTimer] = {};
var typeText = '';
var wordCount = 0;
function listener()
{
    console.debug("listener fired.");
}
var hidden, visibilityChange; 
if (typeof document.hidden !== "undefined") { // Opera 12.10 and Firefox 18 and later support 
  hidden = "hidden";
  visibilityChange = "visibilitychange";
} else if (typeof document.msHidden !== "undefined") {
  hidden = "msHidden";
  visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
  hidden = "webkitHidden";
  visibilityChange = "webkitvisibilitychange";
}
 function handleVisibilityChange(callback) {
  var isBrowserTab = ""; 
  if(document[hidden])
  {
	 isBrowserTab = "hidden";
  } 
  else 
  {
	isBrowserTab = "visible";
  }
  callback(isBrowserTab);
  
}
var timeout = null;
document.addEventListener("DOMSubtreeModified", function() {
    if(timeout) {
        clearTimeout(timeout);
    }
    timeout = setTimeout(listener, 500);
}, false);
function writingMode(e) {
			var isBoostType = timerObj[todayTimer]['is_write_read_mode'];
			if(isBoostType !="Writing")
			{
				return true;
			}
			var nodeName = e.target.nodeName;
			if("BODY" != nodeName && e.type !="keydown") 
			{
				if(e.srcElement.textContent != undefined && e.srcElement.textContent !="")
				{
					typeText = e.srcElement.textContent;
					countWords(typeText);
					
				}
				else if(e.srcElement.value != undefined && e.srcElement.value !="")
				{
					typeText = e.srcElement.value;
					countWords(typeText);
				}
			}
			else if(e.key == "Backspace")
			{
				if(e.srcElement.textContent !="")
				{
					typeText = e.srcElement.textContent;
					countWords(typeText);
				}
				else if(e.srcElement.value !="")
				{
					typeText = e.srcElement.value;
					countWords(typeText);
				}
				
			}
			if(e.code == "Space")
			{
				var lastword = typeText.split(" ").pop();
				if(is_typed_word == "")
				{
					is_typed_word = lastword;
				}
				else
				{
					is_typed_word = is_typed_word+" "+lastword;
				}
				is_typed_word = is_typed_word;
				is_typed_word = is_typed_word.replace(/(^\s*)|(\s*$)/gi,"");
				is_typed_word = is_typed_word.replace(/[ ]{2,}/gi," ");
				is_typed_word = is_typed_word.replace(/\n /,"\n");
				is_typed_word_count = parseInt(is_typed_word.split(' ').length);
			}
}
function countWords(typeText)
{
		if(typeText != "")
		{
			s = typeText;
			s = s.replace(/(^\s*)|(\s*$)/gi,"");
			s = s.replace(/[ ]{2,}/gi," ");
			s = s.replace(/\n /,"\n");
			wordCount = parseInt(s.split(' ').length);
			//console.log(wordCount);
			var totalWord = parseInt(wordCount + getTypedCount);
			timerObj[todayTimer]['typedWordsCount'] = totalWord;
			userBoostNotification(1);
		}
}
var lastPosi = 0;
var totalWordSel = 0;
function readingMode(e)
{	
	var isBoostType = timerObj[todayTimer]['is_write_read_mode'];
	console.log(isBoostType);
	if(isBoostType != "Reading")
	{
		return true;
	}
	var nodeEl = window.getSelection().anchorNode.parentNode.parentNode;
	//nodeEl = $(nodeEl).parents();
	//console.log(document.selection.createRange().text.length);
	if(window.getSelection && !document.getSelection().isCollapsed) 
	{
				if(e.code == "Enter")
				{
					var pos = getSelectionCharOffsetsWithin(nodeEl);
					lastPosi = pos.end;
					setSelectionRange(nodeEl, pos.end, (lastPosi+totalWordSel));
				}
				var selection = getSelectedText();
				//console.log(selection);
				var selection_text = selection.toString();
				selectedString += selection_text;
				if(totalWordSel < 1)
				{
					var pos = getSelectionCharOffsetsWithin(nodeEl);
					lastPosi = pos.end;
					totalWordSel = pos.end;
					setSelectionRange(nodeEl, pos.start, pos.end);
				}
				splitStr = selectedString.split(" ");
				var selectTotalWord = selection_text.split(" ");
				//console.log(getReadCount);
				var totalCount = parseInt(splitStr.length + getReadCount);
				timerObj[todayTimer]['readWordsCount'] = totalCount;
				timerObj[todayTimer]['user_selected_words'] = selectTotalWord.length;
				timerObj[todayTimer]['is_StartWriteRead'] = 1;
				
				userBoostNotification(2);
	}
}
function getSelectionCharOffsetsWithin(element) {
    var start = 0, end = 0;
    var sel, range, priorRange;
    if (typeof window.getSelection != "undefined") {
        range = window.getSelection().getRangeAt(0);
        priorRange = range.cloneRange();
        priorRange.selectNodeContents(element);
        priorRange.setEnd(range.startContainer, range.startOffset);
        start = priorRange.toString().length;
        end = start + range.toString().length;
    } else if (typeof document.selection != "undefined" &&
            (sel = document.selection).type != "Control") {
        range = sel.createRange();
        priorRange = document.body.createTextRange();
        priorRange.moveToElementText(element);
        priorRange.setEndPoint("EndToStart", range);
        start = priorRange.text.length;
        end = start + range.text.length;
    }
    return {
        start: start,
        end: end
    };
}
function getTextNodesIn(node) {
    var textNodes = [];
    if (node.nodeType == 3) {
        textNodes.push(node);
    } else {
        var children = node.childNodes;
        for (var i = 0, len = children.length; i < len; ++i) {
            textNodes.push.apply(textNodes, getTextNodesIn(children[i]));
        }
    }
    return textNodes;
}
function setSelectionRange(el, start, end) {
    if (document.createRange && window.getSelection) {
        var range = document.createRange();
        range.selectNodeContents(el);
        var textNodes = getTextNodesIn(el);
        var foundStart = false;
        var charCount = 0, endCharCount;

        for (var i = 0, textNode; textNode = textNodes[i++]; ) {
            endCharCount = charCount + textNode.length;
            if (!foundStart && start >= charCount
                    && (start < endCharCount ||
                    (start == endCharCount && i <= textNodes.length))) {
                range.setStart(textNode, start - charCount);
                foundStart = true;
            }
            if (foundStart && end <= endCharCount) {
                range.setEnd(textNode, end - charCount);
				range.app
                break;
            }
            charCount = endCharCount;
        }

        var sel = window.getSelection();
		var percentage = document.createElement('percentage');
		percentage.setAttribute("class", "percentage_"+selectedLine);
		range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
		range.insertNode(percentage);
		//range.detach();
		selectTextRange(el, start, end);
    } else if (document.selection && document.body.createTextRange) {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(true);
        textRange.moveEnd("character", end);
        textRange.moveStart("character", start);
        textRange.select();
    }
}
function selectTextRange(el, start, end)
{
		if (document.createRange && window.getSelection) {
				var range = document.createRange();
				range.selectNodeContents(el);
				var textNodes = getTextNodesIn(el);
				var foundStart = false;
				var charCount = 0, endCharCount;
				for (var i = 0, textNode; textNode = textNodes[i++]; ) {
					endCharCount = charCount + textNode.length;
					if (!foundStart && start >= charCount
							&& (start < endCharCount ||
							(start == endCharCount && i <= textNodes.length))) {
						range.setStart(textNode, start - charCount);
						foundStart = true;
					}
					if (foundStart && end <= endCharCount) {
						range.setEnd(textNode, end - charCount);
						range.app
						break;
					}
					charCount = endCharCount;
				}
		}
		var sel = window.getSelection();
		sel.removeAllRanges();
		sel.addRange(range);
}

function getSelectedText() {
  t = (document.all) ? document.selection.createRange().text : document.getSelection();

  return t;
}
function funPopUp(callback){
	var funCss = "";
	var funHTml = "<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;border-radius: 5px;'></div>\n\
			<div id='gs_funPopUpTimer' class='gs_funPopUp' style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_skipbtn' style='width: 30%;float:right;padding:3% 5%;text-align: center'>\n\
					<span id='gs_skipPausedTimer' style='padding:2% 12%;background-color:#616161;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Skip Pause!</span>\n\
		   </div>\n\
	   <div class='gs_funPauseSection' style='display:table;height:80%;width:100%;'>\n\
	   <div class='gs_funPauseChid' style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size:25px;'>Fun Pause Unlocked</span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
	   <span id='gs_timer_msg' style='width:75%;display: inline-block;font-size: 20px; font-family: auto;letter-spacing: 3px;'>Congratulations! You have been successfully working for <span id='gs_unlockedTimer'>00:25 Minutes </span>. you have unlocked a 00:05 Minutes fun pause! </span>\n\
	   <div style='padding:5%;width:100%'></div>\n\
	   </div>\n\
	   </div>\n\
	   </div>";
	callback(funHTml);
}
function earnHealthPoints(callback){
	var funHTml = "<div id='gs_hpPopUp'>\n\
			<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;border-radius: 5px;'></div>\n\
			<div style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
					<span id='gs_closePopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
		   </div>\n\
	   <div  style='display:table;height:80%;width:100%;'>\n\
	   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size: 38px;padding: 7px;background-color: #808080;border: 2px solid #FF0000;color: #fff;border-radius: 5px;'>+HP Earned!</span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
	   </div>\n\
	   </div>\n\
	   </div>\n\
	</div>";
	callback(funHTml);
}
function isPauseReadWriteModePopUp(){
	var div = document.createElement("div");
		div.setAttribute("id", "gs_wr-re-mode");
			if(timerObj[todayTimer]['isTimerStart'] = "failed")
			{
			$("#gs_wr-re-mode").html();
			$("#gs_wr-re-mode").remove();
			document.documentElement.style.overflow = 'auto';
		}
		
			wrModeHTml ="<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;border-radius: 5px;'></div>\n\
			<div style='border-radius: 5px;position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
					<span id='gs_closePopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
		   </div>\n\
	   <div  style='display:table;height:80%;width:100%;'>\n\
	   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size: 18px;display: inline-block;vertical-align: middle;padding-right: 4%;width:100%;'>Paused writing and reading so please re-select one and continue</span>\n\
	   <div style='padding:2%;width:100%'></div>\n\
	   <span style='font-size: 38px;padding: 7px;color: #000;border-radius: 5px;'>\n\
				<input type='radio' value='Reading' name='wrmode' class='gs_wr_mode' style='width: 30px;height: 16px;'><span style='font-size: 18px;display: inline-block;vertical-align: middle;'>Reading Mode</span>\n\
				<input type='radio' value='Writing' name='wrmode' class='gs_wr_mode' style='width: 30px;height: 16px;'><span style='font-size: 18px;display: inline-block;vertical-align: middle;'>Writing Mode</span>\n\
				<span id='gs_empty_select' style='color:red;display:none;width: 100%;font-size: 17px;'>Please select option </span>\n\
	   </span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
			<span id='gs_wr_continue' style='font-size: 18px;display: inline-block;vertical-align: middle;background: #6c757d;padding: 10px 30px;border-radius: 4px;color: #fff;cursor:pointer;'>Continue</span>\n\
	   </div>\n\
	   </div>\n\
	   </div>";
	  
		// if(timerObj[todayTimer]['isTimerStart']=="failed")
		// {
		// //$("#gs_wr-re-mode").html();
		// $("#gs_wr-re-mode").remove();
		// document.documentElement.style.overflow = 'auto';

		// }
	   div.innerHTML = wrModeHTml;     
	   document.body.appendChild(div);
	   document.documentElement.style.overflow = 'hidden';
	    $("#gs_wr_continue").on("click",function(){
				if($(".gs_wr_mode").is(":checked"))
				{
					clearInterval(runningClearIn);
					timerObj[todayTimer]['is_write_read_mode'] = $(".gs_wr_mode:checked").val();
					timerObj[todayTimer]['isTimerStart'] = 'yes';
					timerObj[todayTimer]['is_writing_reading_paused'] = 0;
					$("#gs_empty_select").css('display','none');
					setChromeStorage(timerObj,function(){});
					currentaActiveWindow();
					$("#gs_wr-re-mode").remove();
					document.documentElement.style.overflow = 'auto';
				}
 

				else
				{
					$("#gs_empty_select").css('display','inline-block');
				}
					
				
		});
		$("#gs_closePopUp").on("click",function(){
			
				$("#gs_wr-re-mode").remove();
				document.documentElement.style.overflow = 'auto';
		});
		
}
function startWithRoutinePopUp(callback){
	var div = document.createElement("div");
		div.setAttribute("id", "gs_start-with");
			wrModeHTml ="<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;border-radius: 5px;'></div>\n\
			<div style='border-radius: 5px;position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
					<span id='gs_closePopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
		   </div>\n\
	   <div  style='display:table;height:80%;width:100%;'>\n\
	   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size: 18px;display: inline-block;vertical-align: middle;padding-right: 4%;width:100%;'>Please choose start with</span>\n\
	   <div style='padding:2%;width:100%'></div>\n\
	   <span style='font-size: 38px;padding: 7px;color: #000;border-radius: 5px;'>\n\
				<input type='radio' value='Reading' name='wrmode' class='gs_wr_mode' style='width: 30px;height: 16px;'><span style='font-size: 18px;display: inline-block;vertical-align: middle;'>Reading Mode</span>\n\
				<input type='radio' value='Writing' name='wrmode' class='gs_wr_mode' style='width: 30px;height: 16px;'><span style='font-size: 18px;display: inline-block;vertical-align: middle;'>Writing Mode</span>\n\
				<span id='gs_empty_select' style='color:red;display:none;width: 100%;font-size: 17px;'>Please select option </span>\n\
	   </span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
			<span id='gs_wr_continue' style='font-size: 18px;display: inline-block;vertical-align: middle;background: #6c757d;padding: 10px 30px;border-radius: 4px;color: #fff;cursor:pointer;'>Continue</span>\n\
	   </div>\n\
	   </div>\n\
	   </div>";
	   div.innerHTML = wrModeHTml;     
	   callback(div);
}
function isNotifiOpenPopUp(){
	if(timerObj[todayTimer]['is_open_fun_url'] == 0)
	{
		   getFunTabUrl(function(res){
				if(res['fun_website'] && res['fun_website'] !="")
				{
						var funUrl = res['fun_website'];
						var is_mobile_view = res['is_mobile_view'];
						if(funUrl.indexOf('http') > -1)
						{
							funUrl = res['fun_website'];
						}
						else
						{
							funUrl = "https://"+funUrl;
						}
						if(is_mobile_view == 1)
						{
							window.open(funUrl, null, "height=562,width=400,status=yes,toolbar=no,menubar=no,location=no"); 
						}
						else
						{
							 window.open(funUrl, '_blank');
						}
						var options = {
								notify:"notify"
						  }
						chromeRuntimeSendMsg(options);
						timerObj[todayTimer]['funPopUpStartTime'] =  new Date().getTime();
						timerObj[todayTimer]['isTimerStart'] = "stop";
						timerObj[todayTimer]['isFunTabPopUp'] = 1;
						timerObj[todayTimer]['is_open_fun_url'] = 1;
						timerObj[todayTimer]['startTime'] = "";
						timerObj[todayTimer]['fub_tab_url'] = funUrl;
						timerObj[todayTimer]['is_break_time'] = 'yes';
						setChromeStorage(timerObj,function(){});
				}
		});
	}
	
	
}
function appendHtml(totalTime)
{
		funPopUp(function(resHtml){
			 var div = document.createElement("div");
				div.setAttribute("id", "gs_funTimePopUp");
				div.innerHTML = resHtml;
				document.body.appendChild(div);
				var checkHtml = $("#gs_funTimePopUp").html();
				$("#gs_skipPausedTimer").on("click",function(){
					var options = {
								 closeTab:"closeTab"
							 }
					  chromeRuntimeSendMsg(options);
					 var isMode = timerObj[todayTimer]['isMode']; 
					 if(isMode !="boost")
					 {
						 timerObj[todayTimer]['startTime'] = new Date().getTime();
					 }
					 else
					 {
						 timerObj[todayTimer]['startTime'] = "";
					 }
					timerObj[todayTimer]['isFunTabBrowsers'] = 0;
					timerObj[todayTimer]['isFunTabPopUp'] = 2;
					timerObj[todayTimer]['isTimerStart'] = "yes";
					timerObj[todayTimer]['is_break_time'] = "off";
					timerObj[todayTimer]['isMode'] = isMode;
					setChromeStorage(timerObj,function(){});
					$("#gs_funTimePopUp").remove();
			});
			$("#gs_unlockedTimer").html(totalTime);
	});	
}
function getTimeDiff(timerStart)
{
	var date1 = timerStart;
	var date2 = new Date();
	var delta = Math.abs(date2 - date1) / 1000;
	return delta;
}
function ajaxCall(url,params,callback,errorcallback)
{
			
			jQuery.ajax({
				url: url,
				type: 'POST',
				data:params,
				dataType: 'json',
				success: function (data) {
					callback(data);
				},
				error: function (e) {
					errorcallback(e);
				}
			});
}
function errorcallback(error)
{
    if(window.console){ console.log(error); }
}
var params = {};
function checkUserLogin()
{
	chrome.storage.sync.get(["loginUser"], function(items)
	{
			if(items && items['loginUser'] && items['loginUser']['email'])
			{
				var params = items['loginUser'];
					params['extId'] = chrome.runtime.id;
				userSignUp(params,function(res){
				var dataParms = {};
				if(res['data'] && res['data']['user_id'])
				{
					user_id = res['data']['user_id'];
					var dataParms = {"user_id":user_id}
					currentaActiveWindow();
					getUserRoutine(dataParms,function(res){
						dailyRoutineObj = res['data'];
						chrome.storage.sync.set({"dailyRoutine": dailyRoutineObj},function(){ });
						//checkRoutineTime();
					});
					retripeLocalStorage();
					getNotification(user_id);
				}
			});
		 }
	});
}
function funTabOpenFunc(timeType,hours,minute)
{
		var totalTime = 0;
		if(timeType == "Hours")
		{
			totalTime = hours+":"+minute+" Hours";
			timerObj[todayTimer]['totalActivity'] = hours*60;
		}
		else if(timeType == "Minutes")
		{
			timerObj[todayTimer]['totalActivity'] = minute;
			totalTime = "00:"+minute+" Minutes";
		}
		appendHtml(totalTime);
		setTimeout(function(){	
			isNotifiOpenPopUp();
		},3000);
		
}
function closefunPopUpActivity()
{
	var items = timerObj[todayTimer];
	if(items)
	{
		
		var modeType = items['isMode'];
		if(modeType == "timer")
		{
				var startT = items['funPopUpStartTime'];
				var isTimerOn = items['isTimerStart'];
				var getTime = getTimeDiff(startT);
				var time = getTime;
				var second = time % 60;
				var minute = Math.floor(time / 60) % 60;
				var hour = Math.floor(time / 3600) % 60;
				second = Math.round(second);
				console.log(minute,second);
				if(minute == 1 && second == 2 && isTimerOn =="stop")
				{
					var appWeb = window.location.href;
					var funTabUrl = timerObj[todayTimer]['fub_tab_url'];
					funTabUrl = funTabUrl.replace("https://","")
					console.log(funTabUrl);
					console.log(appWeb.indexOf(funTabUrl));
					if(appWeb.indexOf(funTabUrl) > -1)
					{
						var options = {
							closeTab:"closeTab"
						  }
						chromeRuntimeSendMsg(options);
						setTimeout(function(){
							close();
						},500);		
					}
				}
				else if(minute == 1 && second == 5 && isTimerOn =="stop")
				{
				   $("#gs_timer_msg").html("You have done your fun time!");
				}
				else if(minute == 1 && second == 8 && isTimerOn =="stop")
				{
					timerObj[todayTimer]['isFunTabBrowsers'] = 0;
					timerObj[todayTimer]['isFunTabPopUp'] = 2;
					$("#gs_funTimePopUp").remove();
					timerObj[todayTimer]['isTimerStart'] = "yes";
					timerObj[todayTimer]['is_break_time'] = "off";
					timerObj[todayTimer]['isMode'] = isMode;
					if(isMode !="boost")
					{
						timerObj[todayTimer]['startTime'] = new Date().getTime();
					}
					else
					{
						timerObj[todayTimer]['startTime'] = "";
					}
					setChromeStorage(timerObj,function(){});
					
				}
		}
	}
}
function openFunPopUp()
{
	if(timerObj[todayTimer])
	{
		
		var modeType = timerObj[todayTimer]['isMode'];
		if(modeType == "timer")
		{
			var timerStart = Math.floor(timerObj[todayTimer]['startTime']);
			var funTabTime = timerObj[todayTimer]['funTab'];
			var splitFunTime = funTabTime.split(" ");
			var splitFunTime = funTabTime.split(" ");
			var funTime = splitFunTime[0];
			//var funTime = 1;
			var funTimehourMin = splitFunTime[1];
			var remainTime = parseInt(getTimeDiff(timerStart));
			var second = remainTime % 60;
			var minute = Math.floor(remainTime / 60) % 60;
			var hours = Math.floor(remainTime / 3600) % 60;
			var splitHoursMins = splitFunTime[0].split(":");
			var funHours = splitHoursMins[0];
			var funMins = splitHoursMins[1];
			if(funTimehourMin == "Hours" && funHours == hours && funMins == minute && second == 1)
			{
				funTabOpenFunc(funTimehourMin,hours,minute);
			}
			else if(funTimehourMin == "Minutes" && funTime == minute && second == 1)
			{
				funTabOpenFunc(funTimehourMin,hours,minute);
			}
		}
	}
}
function routineStarted(params,callback)
{
		var url = baseUrl+"/goals/routine-started";
		 //var params = {};
		 ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);  
}
function getUserRoutine(params,callback)
{
	 var url = baseUrl+"/goals/get-user-routine";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function routineCompleted(params,callback)
{
	 var url = baseUrl+"/goals/user-completed-routine";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function userSignUp(params,callback)
{
	 var url = baseUrl+"/site/user-sign-up";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function pushNotificationApi(params,callback)
{
	 var url = baseUrl+"/site/push-notification-api";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function getNotification(user_id)
{
	if(user_id !='')
	{
		var params = {};
		params['user_id'] = user_id;
		pushNotificationApi(params,function(data){
			if(data && data.notification)
			{
				displayPushNotification(data.notification);
			}
		});
	}
}
getLatestNotification()
function getLatestNotification()
{
	setInterval(function(){
		if(user_id !="")
		{
			timerObj[todayTimer]['user_id'] = user_id;
		}
		if(timerObj[todayTimer]['user_id'] !="")
		{
			var userId = timerObj[todayTimer]['user_id'];
			getNotification(userId);
		}
	},2000);
}
function displayPushNotification(data)
{
	var isStart = 1;
	setTimeout(function(){
		if(data.length > 0)
		{
			for(var i=0;i < data.length;i++)
			{
				showNotification(data[i]['message']);
			}
		}
	},1500);
}
function showNotification(bodyMsg) 
{
	var options = {
				pushNotification:"pushNotification",
				pushMsg:bodyMsg
			  }
			chromeRuntimeSendMsg(options);
	
}
function getTargetTime(params,callback)
{
	 var url = baseUrl+"/site/setting";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function getBlockWebsite(uid,callback)
{
	var params = {};
	params['user_id'] = uid;
	 var url = baseUrl+"/block/get-block-site";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function blockWebsitefunc(user_id)
{
getBlockWebsite(user_id,function(res){
	var isAllowWebsite = false;
	if(res['is_type_mode'] == 1)
	{
		isAllowWebsite = isEnableAllowWebsite(res,isAllowWebsite);
	}
	else
	{
		var isAllowWebsite = true;
		isAllowWebsite = isEnableBlockWebsite(res,isAllowWebsite);
	}
	if(isAllowWebsite == false)
	{
			if(!$("#giveUpPopUp").html())
			{
				giveUpPopUp();
				return;
			}
	}
});
}
function isEnableAllowWebsite(res,isAllowWebsite)
{
	if(res && res['data'] && res['data'].length > 0)
	{
			var allowWebsite = ['google.com','wikipedia.org'];
			var objLength = Object.keys(res['data']).length;
			if(objLength > 0 || allowWebsite.length > 0)
			{
				
				for(var i =0; i < objLength; i++)
				{
						var blockSites = res['data'][i][0];
						var restricted = blockSites.split('.').slice(-2).join('.');
						var currentWeb = window.location.href;
						if(currentWeb.indexOf(restricted) > -1)
						{
							isAllowWebsite = true;
						}
				}
				var appWeb = window.location.href;
				if(appWeb.indexOf(baseUrl) > -1)
				{
						isAllowWebsite = true;
				}
				for(var j=0;j< allowWebsite.length;j++)
				{
						var web = allowWebsite[j];
						if(appWeb.indexOf(web) > -1)
						{
							isAllowWebsite = true;
						}
				}
			}
	}
	return isAllowWebsite;
}
function isEnableBlockWebsite(res,isAllowWebsite)
{
	if(res && res['data'] && res['data'].length > 0)
	{
			var objLength = Object.keys(res['data']).length;
			if(objLength > 0)
			{
				
				for(var i =0; i < objLength; i++)
				{
						var blockSites = res['data'][i][0];
						var restricted = blockSites.split('.').slice(-2).join('.');
						var currentWeb = window.location.href;
						if(currentWeb.indexOf(restricted) > -1)
						{
							isAllowWebsite = false;
						}
				}
			}
	}
	return isAllowWebsite;
}
function giveUpPopUp()
{
		var div = document.createElement("div");
		div.setAttribute("id", "giveUpPopUp");
		var giveUpHTml = "<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;border-radius: 5px;'></div>\n\
				<div style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
				<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
						<span id='gs_closeGiveUpPopUp' class='gs_closeGiveUpPopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
			   </div>\n\
		   <div  style='display:table;height:80%;width:100%;'>\n\
		   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
					<span style='display:inline-block;width:100%;text-align:center;font-size:50px;' id='giveupLeftTime'>\n\</span>\n\
					<span style='display:inline-block;width:100%;text-align:center;margin: 5% 0px;'>\n\
						<span style='padding: 10px 10px;font-size: 26px;vertical-align: middle;background-color:#808080;color:#fff;border: 1px solid #000;border-radius: 4px;cursor:pointer;' id='gs_giveUp'>Give Up</span>\n\
					</span>\n\
					<span style='color: #fff;font-size:18px;padding: 7px;background-color: #808080;border-radius: 5px; display: inline-block;'>Caution! if you give up now you will lose 3 level and go back to level 1. \n\</span>\n\
		   <div style='padding:4%;width:100%'></div>\n\
		   </div>\n\
		   </div>\n\
		   </div>";
		   div.innerHTML = giveUpHTml;     
		   document.body.appendChild(div);
		   document.documentElement.style.overflow = 'hidden';
		   $("#gs_giveUp").on("click",function(){
					timerObj[todayTimer]['giveUp'] = 1;
					
					if(confirm('Do you want give up!')) 
					{
						 giveUp();
						 document.documentElement.style.overflow = 'auto';
					}
					else
					{
						timerObj[todayTimer]['giveUp'] = 0;
						
					}
					
					
			});
			$(".gs_closeGiveUpPopUp").on("click",function(){
						var options = {
										unwantedSite:"unwantedSite"
									  }
					chromeRuntimeSendMsg(options);
			});
			var options = {
							prohibitedSite:"prohibitedSite",
							website:window.location.hostname
						  }
			chromeRuntimeSendMsg(options);
			
}
function setChromeStorage(timerObj,callback)
{
	chrome.storage.sync.remove('todayTimer',function(res){
		chrome.storage.sync.set({"todayTimer": timerObj},function(){ 
				setGetLocalStorage(timerObj);
		});
		callback('success')
	});
}
function setGetLocalStorage(timerObj)
{
	localStorage.setItem("todayTimer", JSON.stringify(timerObj));
}
function chromeRuntimeSendMsg(options)
{
	if(chrome.runtime && chrome.runtime.sendMessage){
		chrome.runtime.sendMessage(options, function(response) {	
		});
	}
}
function giveUp()
{
		downLevel(3,function(res)
		{
			if(res['success'] == "true")
			{
				 timerObj[todayTimer]['giveUp'] = 1;
				 setChromeStorage(timerObj);
				 $("#giveUpPopUp").remove();
			}
		});
}
function downLevel(level,callback)
{
		var user_id = timerObj[todayTimer]['user_id'];
		var params = {"extId":chrome.runtime.id,'user_id':user_id,'level_down':level}
		var url = baseUrl+"/site/down-level";
		 //var params = {};
		 ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);  
}
function getFunTabUrl(callback)
{
		user_id = timerObj[todayTimer]['user_id'];
		var params = {'user_id':user_id}
		var url = baseUrl+"/site/fun-tab-url";
		 //var params = {};
		 ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);  
}
function calculateLeftTime()
{
		var items = timerObj[todayTimer];
		if(items != undefined && items != "")
		{
				isMode = items['isMode'];
				var isGiveUp = items['giveUp'];
				var isTimerOn = items['isTimerStart'];
				var is_break_time = items['is_break_time'];
				var isFunTabPopUp = items['isFunTabPopUp'];
				if(isMode == "boost" && isTimerOn == "yes")
				{
					boostMode();
				}
				if(isFunTabPopUp == 0 && isMode != "boost")
				{
					  openFunPopUp();
				}
				else if(is_break_time == 'yes' && isMode != "boost")
				{
					closefunPopUpActivity();
				}
				if(isTimerOn == "yes" && isMode != "boost")
				{
					var consumedTime = getConsumedTime(items);
					generateLeftTime(consumedTime,isMode);
					
				}
				else if(isTimerOn == "stop")
				{
					if($("#giveUpPopUp").html())
					{
						$("#giveUpPopUp").remove();
						document.documentElement.style.overflow = 'auto';
					}
				}
		}
}
function todayTimerObjResponse()
{
		if(timerObj[todayTimer])
		{
			
			var items = timerObj[todayTimer];
			var isGiveUp = timerObj[todayTimer]['giveUp'];
			isMode = items['isMode'];
			var isTimerOn = items['isTimerStart'];
			totalActivity = items['totalActivity'];
			getReadCount = items['readWordsCount'];
			getTypedCount = items['typedWordsCount'];
			var isFunTabPopUp = items['isFunTabPopUp'];
			var is_break_time = items['is_break_time'];
			var is_write_read_mode = items['is_write_read_mode'];
			var is_writing_reading_paused = items['is_writing_reading_paused'];
			isTimerType = isTimerOn;
			if(isMode == "boost")
			{
				boostMode();
				if(isMode !="" && isMode == "boost" && isTimerOn == "yes")
				{ 
					if(is_write_read_mode == "Writing")
					{
						onkeypress = onkeydown = writingMode;
					}
					else if(is_write_read_mode == "Reading")
					{
						onmouseup = onkeydown = readingMode;
						styleTag();
					}
					
					
				}
			}
			if((isTimerOn == "yes" || is_break_time == 'yes') && is_writing_reading_paused == 0)
			{
					runningTimeInterval();
			}
			if(isTimerOn == "yes")
			{
				if(isGiveUp !=1 && user_id > 0)
				{
					if(!$("#giveUpPopUp").html())
					{
						blockWebsitefunc(user_id);
					}
				}
				else
				{
					if($("#giveUpPopUp").html())
					{
						$("#giveUpPopUp").remove();
						 document.documentElement.style.overflow = 'auto';
					}
				}
			}
			
		}
}
function boostMode()
{
		var items = timerObj[todayTimer];
		console.log(items);
		if(items)
		{
			isMode = items['isMode'];
			var consumedTime = getConsumedTime(items);
			generateLeftTime(consumedTime,isMode);
			funPopUpBoostMode(consumedTime);
		}
}
function funPopUpBoostMode(remainTime)
{
		var funTabTime = timerObj[todayTimer]['funTab'];
		var splitFunTime = funTabTime.split(" ");
		var splitFunTime = funTabTime.split(" ");
		var funTime = splitFunTime[0];
		var funTimehourMin = splitFunTime[1];
		var splitHoursMins = splitFunTime[0].split(":");
		var funHours = splitHoursMins[0];
		var funMins = splitHoursMins[1];
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		var totalBoostTime = timerObj[todayTimer]['total_boost_time'];
		var boostHours = Math.floor(totalBoostTime / 60);  
		var boostMinutes = totalBoostTime % 60;
		//console.log(boostHours,boostMinutes,funHours,funHours);
		if(funTimehourMin == "Hours" && funHours == boostHours && funMins == boostMinutes && second == 1)
		{
			funTabOpenFunc(funTimehourMin,boostHours,boostMinutes);
		}
		else if(funTimehourMin == "Minutes" && funTime == boostMinutes && second == 1)
		{
			funTabOpenFunc(funTimehourMin,boostHours,boostMinutes);
		}
		
}
function runningTimeInterval()
{
		clearInterval(runningClearIn);
		runningClearIn = setInterval(function(){
			calculateLeftTime();
			isTimerType = timerObj[todayTimer]['isTimerStart'];
			var is_break = timerObj[todayTimer]['is_break_time'];
			if((isTimerType == "completed" || isTimerType =="stop" || isTimerType =="" || isTimerType == "failed") && is_break !="yes")
			{
				if($("#giveUpPopUp").html())
				{
					$("#giveUpPopUp").remove();
					 document.documentElement.style.overflow = 'auto';
				}
				else if($("#gs_wr-re-mode").html())
				{
					$("#gs_wr-re-mode").remove();
					 document.documentElement.style.overflow = 'auto';
				}
				clearInterval(runningClearIn);
			}
		},1000);
}
function getConsumedTime(items)
{
			var timerStart = Math.floor(items['startTime']);
			var isTimerOn = items['isTimerStart'];
			totalActivity = items['totalActivity'];
			var targetTime = items['targetTime'];
			isMode = items['isMode'];
			var completedTime = 0;
			var totalReadTypedT = 0;
			var consumedTime = totalActivity*60;
			if(timerStart !="")
			{
				consumedTime = parseInt(getTimeDiff(timerStart)+ consumedTime);
			}
			consumedTime = targetTime - consumedTime;
			if(consumedTime <= targetTime)
			{
				return consumedTime;
			}
			else
			{
				timerObj[todayTimer]['isTimerStart'] = "completed";
				timerObj[todayTimer]['hpEarnPopUp'] = 1;
				setChromeStorage(timerObj,function(){});
			}
}
function generateLeftTime(remainTime,isMode)
{
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		var leftTime = "";
		if(hour > 0)
		{
			leftTime = "Hours Left.";
		}
		else if(hour == 0 && minute > 0)
		{
			leftTime = "Minutes Left.";
		}
		else if(minute == 0 && second > 0)
		{
			leftTime = "Seconds Left.";
		}
		if(remainTime > 0)
		{
			var totalTime = hour+":"+minute
		}
		if($("#giveUpPopUp").html())
		{
			if(remainTime == 0)
			{
				$("#giveupLeftTime").html("Completed");
			}
			else
			{
				$("#giveupLeftTime").html(totalTime+" <span style='font-size:20px;'>"+leftTime+"</span>");
			}
		}
		if(remainTime == 0)
		{
				earnHealthPoints(function(reshtml){
						$("body").append(reshtml);
						timerObj[todayTimer]['isTimerStart'] = "completed";
						timerObj[todayTimer]['hpEarnPopUp'] = 1;
						setChromeStorage(timerObj,function(){});
						$("#gs_closePopUp").on("click",function(){
								$("#gs_hpPopUp").remove();
								timerObj[todayTimer]['hpEarnPopUp'] = "close";
								setChromeStorage(timerObj,function(){});
						});
				});
		}
		var is_task_start = timerObj[todayTimer]['is_task_start'];
		if(is_task_start == 1 && isMode == 'timer')
		{
			timeCalculationTasks();
		}
		else if(is_task_start == 1 && isMode == 'boost')
		{
			writingReadingLeftTime();
		}
		if(remainTime < 0)
		{
			clearInterval(runningClearIn);
		}
}
function userBoostNotification(typeMode)
{
	
		if(typeMode == 1) //deduct user typing word count
		{
			var readWordsCount = timerObj[todayTimer]['readWordsCount'];
			var userReadW = timerObj[todayTimer]['user_selected_words'];
			var chooseTypeWord = timerObj[todayTimer]['chosen_typed_word'];
			if(is_running_time == 0 && (is_typed_word_count <= chooseTypeWord))
			{
				var convertMins = 1*60;
				notificationInterVal(convertMins,boostMode);
				is_running_time = 1;
				if(minsCantake < 1)
				{
					minsCantake = 1;
				}
			}
			else if(is_running_time == 1 && (is_typed_word_count >= chooseTypeWord))
			{
				is_typed_word = '';
				clearInterval(boostSetIn);
				is_running_time = 0;
			}
		}
		else if(typeMode == 2)// deduct user selected word count
		{
			clearInterval(boostSetIn);
			var userSeletedW = timerObj[todayTimer]['user_selected_words'];
			var chooseSelWord = timerObj[todayTimer]['chosen_selected_word'];
			minsCantake = Math.ceil(userSeletedW/chooseSelWord);
			var convertMins = minsCantake*60;
			notificationInterVal(convertMins,boostMode);
		}
}
function notificationInterVal(convertMins,boostMode,takeMins)
{
		clearInterval(boostSetIn);
		var todaySpike = timerObj[todayTimer]['today_strikes'];
		
		var convertMins = convertMins;
		boostSetIn = setInterval(function(){
		var second = convertMins % 60;
		var minute = Math.floor(convertMins / 60) % 60;
		var hour = Math.floor(convertMins / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		console.log(minute+":"+second);
		if(minsCantake == minute && second == 0)
		{
				timerObj[todayTimer]['boost_countdown'] = new Date().getTime();
				timerObj[todayTimer]['is_StartWriteRead'] = 1;
				timerObj[todayTimer]['totalActivity'] = parseInt(timerObj[todayTimer]['totalActivity']+1);
				setChromeStorage(timerObj,function(){});
				minsCantake--;
		}
		console.log(timerObj[todayTimer]['total_boost_time']);
		if(minute == 0 && second == 20)
		{
			var options = {
				boostNotification:"boostNotification"
			  }
			chromeRuntimeSendMsg(options);
		}
		if(minute == 0 && second == 0)
		{
			var options = {
				spikes:"spikes"
			  }
			chromeRuntimeSendMsg(options);
			is_running_time = 0;
			timerObj[todayTimer]['totalActivity'] = timerObj[todayTimer]['totalActivity'] - 1;
			timerObj[todayTimer]['user_selected_words'] = 0;
			timerObj[todayTimer]['is_StartWriteRead'] = 0;
			timerObj[todayTimer]['boost_countdown'] = 0;
			timerObj[todayTimer]['today_strikes'] = parseInt(todaySpike+1);
			timerObj[todayTimer]['total_boost_time'] = 0;
			setChromeStorage(timerObj,function(){
				if(timerObj[todayTimer]['today_strikes'] == 10)
				{
					downLevel(1,function(res){
							timerObj[todayTimer]['user_current_level'] = res['level'];
							setChromeStorage(timerObj,function(){});
					});
				}
				
			});
			clearInterval(boostSetIn);
		}
		convertMins--;
	},1000);
}
function currentaActiveWindow()
{
	todayTimerObjResponse();
}
function styleTag()
{
	var css = '::selection {color: red;background: orange;}';
    var head = document.getElementsByTagName('head')[0];
    var style = document.createElement('style');
	head.appendChild(style);
	style.type = 'text/css';
	style.appendChild(document.createTextNode(css));
}
function clearSelection()
{
	 if(window.getSelection)
	 {
		 window.getSelection().removeAllRanges();
	 }
	 else if (document.selection) 
	 {
		 document.selection.empty();
	 }
}
function clearAllInterval()
{
	updateStorageObj();
	clearInterval(runningClearIn);
	clearInterval(boostSetIn);
	clearSelection();
	//console.log('clearEvent');
}
function visibilityTabState(visibilityState)
{
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		if(items["todayTimer"] && items["todayTimer"][todayTimer])
		{
			timerObj[todayTimer] = items["todayTimer"][todayTimer];
			var is_writing_reading_paused = items["todayTimer"][todayTimer]['is_writing_reading_paused'];
			var isTimerStart = items["todayTimer"][todayTimer]['isTimerStart'];
			if(visibilityState == "visible")
			{
				if(is_writing_reading_paused == 1)
				{
					if(!$('#gs_wr-re-mode').html())
					{
						var currentWeb = window.location.href;
						var isAllowWebsite = true;
						if(currentWeb.indexOf(baseUrl) > -1)
						{
							isAllowWebsite = false;
						}
						if(isAllowWebsite == true && timerObj[todayTimer]['isTimerStart']=="yes")
						{
							isPauseReadWriteModePopUp();
						}
						// if(timerObj[todayTimer]['isTimerStart']=="failed")
						// {
						// 	$('#gs_wr-re-mode').remove();
						// }
					}
				}
				else
				{
					if($('#gs_wr-re-mode').html())
					{
						$('#gs_wr-re-mode').remove();
					}
					currentaActiveWindow();
				}
			}
			else if(visibilityState == "hidden")
			{
				clearAllInterval();
			}
		}
	});
}
function updateStorageObj()
{
	var isTimer = timerObj[todayTimer]['isTimerStart'];
	var isWriteReadMode = timerObj[todayTimer]['is_write_read_mode'];
	if(isWriteReadMode == "Writing" || isWriteReadMode == "Reading")
	{  
		  timerObj[todayTimer]['is_writing_reading_paused'] = 1; 
		  timerObj[todayTimer]['is_write_read_mode'] = '';
	}
	setChromeStorage(timerObj,function(){});
}
function setAllPageEvent()
{
	console.log('is active tab window');
}
var hidden = "hidden";
// Standards:
if (hidden in document)
document.addEventListener("visibilitychange", onchange);
else if ((hidden = "mozHidden") in document)
document.addEventListener("mozvisibilitychange", onchange);
else if ((hidden = "webkitHidden") in document)
document.addEventListener("webkitvisibilitychange", onchange);
else if ((hidden = "msHidden") in document)
document.addEventListener("msvisibilitychange", onchange);
// IE 9 and lower:
else if ("onfocusin" in document)
document.onfocusin = document.onfocusout = onchange;
// All others:
else
window.onpageshow = window.onpagehide
= window.onfocus = window.onblur = onchange;
// set the initial state (but only if browser supports the Page Visibility API)
if( document[hidden] !== undefined )
onchange({type: document[hidden] ? "blur" : "focus"});
function onchange (evt) {
	var visibilityState = '';
	var v = "visible", h = "hidden",
		evtMap = {
		  focus:v, focusin:v, pageshow:v, blur:h, focusout:h, pagehide:h
		};

	evt = evt || window.event;
	if (evt.type in evtMap)
	  visibilityState = evtMap[evt.type];
	else
	  visibilityState = this[hidden] ? "hidden" : "visible";
	  visibilityTabState(visibilityState);
}
document.addEventListener("visibilitychange", onchange);
checkUserLogin();
//inspectElementBlock();
function inspectElementBlock()
{
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});
	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
		console.log('You cannot inspect Element');
		 return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	} 
}
$(window).focus(function(){
	clearInterval(runningClearIn);
	clearInterval(boostSetIn);
	visibilityTabState('visible');
});
function uninstallApp(callback)
{
	if(localStorage.getItem("todayTimer"))
	{
		var obj = localStorage.getItem("todayTimer");
		console.log(obj);
		var retrievedObject = JSON.parse(obj);
		var user_id = retrievedObject[todayTimer]['user_id'];
		var url = baseUrl+"/site/retripe-uninstall-data";
		var params = {};
		params['local_storage'] = obj;
		params['user_id'] = user_id;
		ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);
	}	
}
function retripeLocalStorage()
{
	var appWeb = window.location.href;
	if(appWeb.indexOf('/site/un-install-app') > -1)
	{
		uninstallApp(function(){});
	}
}
$('.btn-start').on('click',function(){
	var _this = $(this);
	var isActivityType = _this.attr('is-mode-type');
	if(isActivityType =="boost")
	{
		chooseReadingWritingMode(_this,isActivityType);
	}
	else
	{
		setActivityObj(_this,isActivityType);
	}
	console.log(isActivityType);
	
			
});
function setActivityObj(_this,isActivityType)
{
	getTargetTime('',function(targetRes){
			var setTargetHours = targetRes.target;
			var user_id = targetRes.userId;
				var splitH =  setTargetHours.split(" ");
				var setTime = splitH[0];
				if(setTime == 30)
				{
					setHoursCount = setTime*60;
				}
				else
				{
					setHoursCount = setTime*60*60;
				}
				var task_id = _this.parents('.routine-tasks').attr('tasks-id');
				var task_target_time = _this.parents('.routine-tasks').attr('task-hours');
				var task_title = _this.parents('.routine-tasks').attr('task-title');
				var user_id = _this.parents('.routine-tasks').attr('user-id');
				var isTimeFormat =  task_target_time.split(" ");
				timerObj[todayTimer]['task_id'] = task_id;
				timerObj[todayTimer]['task_target_time'] = isTimeFormat[0];
				timerObj[todayTimer]['task_time_format'] = isTimeFormat[1];
				timerObj[todayTimer]['task_title'] = task_title;
				timerObj[todayTimer]['is_task_start'] = 1;
				timerObj[todayTimer]['isMode'] = isActivityType;
				timerObj[todayTimer]['is_writing_reading_paused'] = 0;
				timerObj[todayTimer]['user_id'] = user_id;
				timerObj[todayTimer]['funTab'] = targetRes.fun_tab;
				timerObj[todayTimer]['isTimerStart'] = 'yes';
				if($('.btn-start'))
				{
					$("#start-task-"+task_id).remove();
				}
				if(timerObj[todayTimer]['targetTime'] < 1)
				{
					timerObj[todayTimer]['targetTime'] = setHoursCount;
				}
				if(isActivityType !="boost")
				{
					timerObj[todayTimer]['task_start_time'] = new Date().getTime();
					timerObj[todayTimer]['startTime'] = new Date().getTime();
				}
				setChromeStorage(timerObj,function(){
						visibilityTabState('visible');
						var options = {
									started:"started",
									title:task_title
								 }
							chromeRuntimeSendMsg(options);
					});
		});
}
function timeCalculationTasks()
{
	var is_tasks_completed = false;
	var timerStart = timerObj[todayTimer]['task_start_time'];
	var task_time_format = timerObj[todayTimer]['task_time_format'];
	var task_target_time = parseInt(timerObj[todayTimer]['task_target_time']);
	var task_id = timerObj[todayTimer]['task_id'];
	var task_title = timerObj[todayTimer]['task_title'];
	var totalTime = parseInt(getTimeDiff(timerStart));
	var second = totalTime % 60;
	var minute = Math.floor(totalTime / 60) % 60;
	var hour = Math.floor(totalTime / 3600) % 60;
	var tasksTotalActivity = 0;
	if($('.btn-start') && $("#start-task-"+task_id))
	{
		$("#start-task-"+task_id).remove();
	}
	if(task_time_format == "Minutes" || task_time_format == "Hours" || task_time_format == "Hour")
	{
		if((task_target_time == minute || minute > task_target_time) && task_time_format == "Minutes")
		{
			tasksTotalActivity = task_target_time*60;
			if($('.completed_tasks_overlay'))
			{
				$('.routine-cls-task-'+task_id).find('.completed_tasks_overlay').show();
			}
			is_tasks_completed = true;
		}
		else if(task_target_time == hour)
		{
			if($('.completed_tasks_overlay'))
			{
				$('.routine-cls-task-'+task_id).find('.completed_tasks_overlay').show();
			}
			tasksTotalActivity = task_target_time*60*60;
			is_tasks_completed = true;
		}
		if(is_tasks_completed == true && second == 1)
		{
			
				var params = {};
				params['id'] = timerObj[todayTimer]['task_id'];
				params['consumed'] = tasksTotalActivity;
				routineCompleted(params,function(){
					var options = {
								completed:"completed",
								title:task_title
							 }
					chromeRuntimeSendMsg(options);
					timerObj[todayTimer]['task_id'] = '';
					timerObj[todayTimer]['task_target_time'] = '';
					timerObj[todayTimer]['task_time_format'] = '';
					timerObj[todayTimer]['task_title'] = '';
					timerObj[todayTimer]['is_task_start'] = 0;
					timerObj[todayTimer]['task_start_time'] = '';
					timerObj[todayTimer]['startTime'] = '';
					timerObj[todayTimer]['isMode'] = '';
					timerObj[todayTimer]['isTimerStart'] = 'stop';
					timerObj[todayTimer]['is_writing_reading_paused'] = 0;
					timerObj[todayTimer]['totalActivity'] = timerObj[todayTimer]['totalActivity']+tasksTotalActivity;
					setChromeStorage(timerObj,function(){
						console.log('Tasks completed');
					});
				});
				if($("#left-time-"+task_id))
				{
					$("#left-time-"+task_id).remove();
				}	
		}
		showTaskLeftTime(task_id,task_target_time,task_time_format,totalTime);
	}
}
function showTaskLeftTime(task_id,task_target_time,task_time_format,totalTime)
{
	if(task_time_format == 'Hours' || task_time_format == 'Hour')
	{
		var task_target_time = task_target_time*60*60;
	}
	else
	{
		var task_target_time = task_target_time*60;
	}
	var totalTime = task_target_time - totalTime;
	var second = totalTime % 60;
	var minute = Math.floor(totalTime / 60) % 60;
	var hour = Math.floor(totalTime / 3600) % 60;
	second = (second < 10) ? '0'+second : second;
	minute = (minute < 10) ? '0'+minute : minute;
	hour = (hour < 10) ? '0'+hour : hour;
	var leftTime = "";
	if(hour > 0)
	{
		leftTime = "Hours Left.";
		var remainTime = hour+":"+minute+":"+second+" "+leftTime;
	}
	else if(hour == 0 && minute > 0)
	{
		leftTime = "Minutes Left.";
		var remainTime = minute+":"+second+" "+leftTime;
	}
	else if(minute == 0 && second > 0)
	{
		leftTime = "Seconds Left.";
		var remainTime = minute+":"+second+" "+leftTime;
	}
	if($("#left-time-"+task_id))
	{
		$("#left-time-"+task_id).html(remainTime);
	}
}
function writingReadingLeftTime()
{
	var task_time_format = timerObj[todayTimer]['task_time_format'];
	var task_target_time = parseInt(timerObj[todayTimer]['task_target_time']);
	var task_id  = parseInt(timerObj[todayTimer]['task_id']);
	if(task_time_format == 'Hours' || task_time_format == 'Hour')
	{
		var task_target_time = task_target_time*60*60;
	}
	else
	{
		var task_target_time = task_target_time*60;
	}
	if($('.btn-start'))
	{
		$("#start-task-"+task_id).remove();
	}
	var totalTime = task_target_time - timerObj[todayTimer]['totalActivity']*60;
	console.log(totalTime);
	var second = totalTime % 60;
	var minute = Math.floor(totalTime / 60) % 60;
	var hour = Math.floor(totalTime / 3600) % 60;
	second = (second < 10) ? '0'+second : second;
	minute = (minute < 10) ? '0'+minute : minute;
	hour = (hour < 10) ? '0'+hour : hour;
	var leftTime = "";
	if(hour > 0)
	{
		leftTime = "Hours Left.";
		var remainTime = hour+":"+minute+":"+second+" "+leftTime;
	}
	else if(hour == 0 && minute > 0)
	{
		leftTime = "Minutes Left.";
		var remainTime = minute+":"+second+" "+leftTime;
	}
	else if(minute == 0 && second > 0)
	{
		leftTime = "Seconds Left.";
		var remainTime = minute+":"+second+" "+leftTime;
	}
	if($("#left-time-"+task_id))
	{
		$("#left-time-"+task_id).html(remainTime);
	}
}
dailyRoutineNotification();
function dailyRoutineNotification()
{
	
	chrome.storage.sync.get(["dailyRoutine"], function(items)
	{
			var d = new Date(); // for now
			var h = d.getHours();
			var m = d.getMinutes();
			var s = d.getSeconds();
			console.log(d.getHours(),d.getMinutes(),d.getSeconds());
			console.log(items);
	});	
}
function chooseReadingWritingMode(_this,isActivityType)
{
	startWithRoutinePopUp(function(res){
	   document.body.appendChild(res);
	   document.documentElement.style.overflow = 'hidden';
	    $("#gs_wr_continue").on("click",function(){
				if($(".gs_wr_mode").is(":checked"))
				{
					timerObj[todayTimer]['is_write_read_mode'] = $(".gs_wr_mode:checked").val();
					$("#gs_empty_select").css('display','none');
					setActivityObj(_this,isActivityType);
					$("#gs_start-with").remove();
					
				}
				else
				{
					$("#gs_empty_select").css('display','inline-block');
				}
					
		});
		$("#gs_closePopUp").on("click",function(){
			
				$("#gs_start-with").remove();
				document.documentElement.style.overflow = 'auto';
		});
		
	});
	
}
}());