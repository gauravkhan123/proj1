'use strict';
// Hook begins when a new tab opens
var appId = '';
chrome.windows.onCreated.addListener(function() {
	appId = chrome.runtime.id;
})

// Hook begins when a new tab refreshes or reloads
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete') {
    appId = chrome.runtime.id;
  }
})

// Hook begins when extension is installed
chrome.runtime.onInstalled.addListener(function() {
		appId = chrome.runtime.id;
		var url = "https://development.brstdev.com/productivitystimulus/site/un-install-app?extId="+appId;
				  chrome.runtime.setUninstallURL(url, function(res){
					appId = chrome.runtime.id;
					
				});
  //alert(appId);
});
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse){
  if(message.notify)
  {
	    /* chrome.windows.create({url : "https://www.instagram.com/",type: "popup", height: 562, width:375});
	    chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
			//sendResponse(tabs[0].id);	
		}); */
  }
  else if(message.closeTab)
  {
	  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
			var bodyMsg = "Close your eyes, take five deep breaths, then push foward!";
				showNotification(bodyMsg);
				chrome.tabs.update(message.closeTab, {active: true})
			
	});
  }
  else if(message.routineStart)
  {
		var bodyMsg = message.dec;
		showNotification(bodyMsg);
  }
  else if(message.routineDone)
  {
	   routineNotifyDone("Welcome Message", function(notification){});
  }
  else if(message.unwantedSite)
  {
	  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
			let url = tabs[0].url;
			chrome.tabs.remove(tabs[0].id);	
		});
  }
  else if(message.prohibitedSite)
  {
	  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
			let url = tabs[0].url;
			var restricted = url.split('.').slice(-2).join('.');
			var msg = "You are accessing is a prohibited site!"
			var bodyMsg = "You are accessing "+restricted+" Which is a prohibited site!"
			showNotification(bodyMsg);
	});
	  
  }
  else if(message.boostNotification)
  {
	  var bodyMsg = "20 seconds left only please do fast!";
		 showNotification(bodyMsg);
  }
  else if(message.spikes)
  {
	  var bodyMsg = "You received one strike because you exceeded the time limit for the text line.";
		 showNotification(bodyMsg);
  }
  else if(message.started)
  {
	  var bodyMsg = "it's "+message.title+" routine has been successfully started";
		 showNotification(bodyMsg);
  }
  else if(message.completed)
  {
	  var bodyMsg = "it's "+message.title+" routine has been successfully completed";
		 showNotification(bodyMsg);
  }
  else if(message.pushNotification)
  {
	  var bodyMsg = message.pushMsg;
		 showNotification(bodyMsg);
  }
  return true;
});
function notify(options)
{
    return chrome.notifications.create("", options);
}
function showNotification(bodyMsg) 
{
	if(Notification.permission === "granted") {
	   const notification = new Notification("New message incoming", {
		  body: bodyMsg
	   })
	   return true;
	}else if (Notification.permission !== "denied") {
	  Notification.requestPermission().then(permission => {
		 console.log(permission);
	  });
	}
	/* Notification.onclick = function(event) {
			  //event.preventDefault(); // prevent the browser from focusing the Notification's tab
			  window.open('https://development.brstdev.com/productivitystimulus/social/index', '_blank');
		} */
	
}
function routineNotifyDone(title, callback)
{
    var options = {
        title: title,
        message: "Completed your active routine!",
        type: "basic",
        iconUrl: "icons/img_avatar.png" // A URL to the sender's avatar, app icon, or a thumbnail for image notifications.
    };
    return chrome.notifications.create("", options, callback);
}
chrome.storage.onChanged.addListener(function(changes, namespace) {
  for (key in changes) {
    var storageChange = changes[key];
    console.log('Storage key "%s" in namespace "%s" changed. ' +
                'Old value was "%s", new value is "%s".',
                key,
                namespace,
                storageChange.oldValue,
                storageChange.newValue);
  }
});
window.onerror = function (errorMsg, url, lineNumber, column, errorObj) {
    console.log('Caught background script error');
    console.log('errorMsg: ' + errorMsg);
    console.log('url: ' + url);
    console.log('lineNumber: ' + column);
    console.log('column: ' + column);
    console.log('errorObj follows:');
    console.log(errorObj);
    return true;
};
// It runs when folders are created and then we create bookmarks into those
