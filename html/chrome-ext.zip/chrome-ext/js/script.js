var timer;
var currentTime = new Date();
var startTime = "";
var runningSecond = '';
var timerObj = {};
var time ='';
var setHoursCount ='';
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
var todayTimer = "timer_"+ dd + '/' + mm + '/' + yyyy;
var isTimer = "";
var totalActivity = 0;
var getTypedCount = 0;
var getReadCount = 0;
var readingTime = 1;
var writingTime = 1;
var baseUrl = "https://development.brstdev.com";
var isMode = '';
var storageObj = '';
var isCallbackDone = 0;
var isTimerType = ''; 
var progressBarCount = 59;
var progressSetIn = '';
var is_running_boost_time = 0;
var is_StartWriteRead = 0;
var hslColor = "hsl(63, 100%, 50%)";
var runningSetInterval = '';
timerObj[todayTimer] = {
	"startTime":"",
	"totalActivity":0,
	"isTimerStart":"",
	"funTab":'',
	"isFunTabPopUp":0,
	"currentTab":0,
	"isFunTabBrowsers":0,
	"targetTime":0,
	"isTimePause":0,
	"isMode":'',
	"typedWordsCount":0,
	"readWordsCount":0,
	"hpEarnPopUp":0,
	"funPopUpStartTime":0,
	'giveUp':0,
	'is_StartWriteRead':0,
	'today_strikes':0,
	'user_selected_words' :0,
	'user_typed_words':0,
	'chosen_selected_word':20,
	'chosen_typed_word':20,
	'is_pause_boost':0,
	'boost_countdown':0,
	'is_flame_start':0,
	'total_boost_time':0,
	'is_write_read_mode':'',
	'user_id':'',
	'fub_tab_url':'',
	'is_mobile_view':'',
	'is_open_fun_url':0,
	'is_break_time':'',
	'is_writing_reading_paused':0,
	'task_id':0,
	'task_target_time':0,
	'is_task_start':0,
	'task_title':'',
	'task_start_time':'',
	'user_current_level':0
}
$(".gs_loader").show();
$(document).ready(function () {
	
	setTimeout(function(){
		chrome.storage.sync.get(["loginUser"], function(items)
		{
			if(items && items['loginUser'] && items['loginUser']['email'])
			{
				var params = items['loginUser'];
				params['extId'] = chrome.runtime.id;
				userSignUp(params,function(res){
					if(res['isLogin'] == true)
					{
						userInfo(res);
					}
					else
					{
						$(".loginWithG-mail").show();
						$(".gs_loader").hide();
					}
					
				});
			}
			else
			{
				$(".gs_loader").hide();
				$(".loginWithG-mail").show();
			}
			
		});	
	},1000);
	$(".loginWithG-mail").hide();
	 $('#loginWithGMail').on('click', function() {
		 
			if($("#agreeWithTerm").is(":checked"))
			{
				$(".gs_loader").show();
				load();
			}
			else
			{
				$(".agreeGSTerms").css({"border":"1px solid red"});
			}
	 });
	 $('#gs_flame').on('click', function() {
			var type = $(this).attr('type');
			flameStartAndStop(type);
	 });
	 $('.gs_start_activity').on('click', function() {
		 var getType = $(this).attr("type-mode");
		 flameStartActivity(getType);
	 });
	 $('.gs_start_boost_activity').on('click', function() {
		 var getType = $(this).attr("type-mode");
		 boostModeActivity(getType);
	 });
	  $('#gs-play-pause').on('click', function() {
			flameAlertPauseMessage('boost');
	  });
	 $('.gs_goBack').on('click', function() {
			if($(this).attr('type') == 1)
			{
				$(".gs_activity_boost_reading_typing").hide();
				$(".gs_activity-section").show();
			}
			else
			{
				$(".gs_startStop").show();
				$(".gs_activity-section").hide();
				$('#gs_flame').attr("type","start");
			}
	 });
	  $('.gs_activityReward').on('click', function() {
			 var title = $(this).attr("title");
			 var redirect = "";
			 if(title == "Social")
			 {
				 redirect = "social/index";
			 }
			 else if(title == "Goals")
			 {
				 redirect = "goals/routine";
			 }
			 else if(title == "Mystery Box")
			 {
				  redirect = "mystery/index";
			 }
			 chrome.tabs.create({
				url: baseUrl+'/productivitystimulus/'+redirect
			});
		 });
		 $('#settingIcon').on('click', function() {
			 var extId = chrome.runtime.id;
			  chrome.tabs.create({
					url: baseUrl+'/productivitystimulus/setting/index'
				});
		 });
});
function load() {
    var method = 'GET'
    var url = 'https://www.googleapis.com/userinfo/v2/me?alt=json';
    //var fields = encodeURIComponent("names,genders,birthdays,emailAddresses,photos");
    ///var url = 'https://people.googleapis.com/v1/people/me?personFields=' + fields;
    authenticateRequest(method, url, function(err, response) {
        if (err) {
			alert('authenticateRequest Err >>' + err);
			$(".gs_loader").hide();
            console.log('authenticateRequest Err >>', err);
            return;
        }
		chrome.storage.sync.set({"loginUser": response},function(){
				var params = response;
				params['extId'] = chrome.runtime.id;
				var isSNl = 0;
				if($('#subscribeToNewsletter'))
				{
					if($('#subscribeToNewsletter').is(":checked"))
					{
						isSNl = 1;
					}
				}
				userSignUp(params,function(res){
					userInfo(res,isSNl);
				});	
		});
        //profile = response;
			
	});
       
}
function authenticateRequest(method, url, callback) {
    getToken();

    function getToken() {
        chrome.identity.getAuthToken({
            interactive: true
        }, function(token) {
            if (chrome.runtime.lastError) {
                // chrome.identity.removeCachedAuthToken(token, function() {
                console.log("Cached token has been removed");
                callback(chrome.runtime.lastError.message);
                return;
                // });
            }
            authToken = token; // set token
            let init = {
                method: method,
                //async: true,
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                'contentType': 'json'
            };
            fetch(url, init).then((response) => {
                if (!response.ok) {
                    callback(response.statusText);
                } else {
                    return response.json();
                }
            }).then(function(data) {
                if (!data) {
                    callback('Request failed. Please try again.');
                } else if (data.error) {
                    chrome.identity.removeCachedAuthToken({
                        'token': token
                    }, getToken);
                } else {
                    callback(null, data);
                }
            }).catch((error) => {
                console.log('Error:', error);
                chrome.identity.removeCachedAuthToken({
                    'token': token
                }, getToken);
            });
        })
    }
}
function userInfo(res,isSNl)
{
		$(".gs_loader").hide();
		$(".gs_step1").show();
		if(res && res.data && res.data['user_pic'])
		{
			$(".user-profile img").attr("src",res.data['user_pic']);
			$(".user-profile img").attr("title",res.data['username']);
			if(parseInt(res.data['level']) < 10)
			{
				$(".user-status level").html("Level 0"+res.data['level']);
			}
			else
			{
				$(".user-status level").html("Level "+res.data['level']);
			}
			//timerObj[todayTimer]['user_id'] = res.data['user_id'];
			//timerObj[todayTimer]['user_current_level'] = res.data['level'];
			//setActivityStorage(timerObj);
		}
		$(".agreeGSTerms").removeAttr("style");
		$(".loginWithG-mail").hide();
		var params = {};
		if(isSNl != undefined)
		{
			params['isSNl'] = isSNl;
		}
		if(res.local_storage !="")
		{
			timerObj = JSON.parse(res.local_storage);
			if(timerObj[todayTimer])
			{
				if(timerObj[todayTimer]['startTime'] != "")
				{
					timerObj[todayTimer]['startTime'] = '';
					timerObj[todayTimer]['isMode'] = '';
				}
				if(timerObj[todayTimer]['isTimerStart'] == 'yes')
				{
					timerObj[todayTimer]['isTimerStart'] = 'stop';
				}
				setLocalStorage();
			}
		}
		else
		{
				onloadFlameActivity();
		}
		getTargetTime(params,function(targetRes){
			var setTargetHours = targetRes.target;
				var splitH =  setTargetHours.split(" ");
				var setTime = splitH[0];
				if(setTime == 30)
				{
					setHoursCount = setTime*60;
				}
				else
				{
					setHoursCount = setTime*60*60;
				}
				timerObj[todayTimer]['targetTime'] = setHoursCount;
				timerObj[todayTimer]['funTab'] = targetRes.fun_tab;
				dailyHealthPoints(2);
		});
}
function ajaxCall(url,params,callback,errorcallback)
{
			
			jQuery.ajax({
				url: url,
				type: 'POST',
				data:params,
				dataType: 'json',
				success: function (data) {
					callback(data);
				},
				error: function (e) {
					errorcallback(e);
				}
			});
}
function errorcallback(error)
{
    if(window.console){ console.log(error); }
}
function userSignUp(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/user-sign-up";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function getTargetTime(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/setting";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function dailyHealthPointsApi(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/daily-health-points";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function dailyHealthPoints(is_up_down)
{
	var params = {};
	params['is_up_down'] = is_up_down;
	dailyHealthPointsApi(params,function(pointsRes){
		var hp = pointsRes.flameHp;
		$(".gs_growingPercent").html(hp+"/3 HP");
		var img = "icons/flame"+pointsRes.flameHp+".png";
		$(".gs_flame_image").attr("src",img);
		meterProgressLeftDays(is_up_down);
	})
}
function meterProgressLeftDays(target)
{
		var params = {};
		params['target'] = target;
		progressLeftDaysApi(params,function(pointsRes){
				$(".gs_meterProgress span").css("width",Math.round(pointsRes.hp));
				$(".gs_meterProgress days").html(pointsRes['left-days']);
			});
}
function progressLeftDaysApi(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/progress-left-days";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function flameStartAndStop(type)
{
	switch(type)
	{
		case"start":
			$("#gs_flame").attr("type","stop");
			$(".gs_startStop").hide();
			$(".gs_activity-section").show();
		break;
		case"stop":
			flameAlertPauseMessage('timer');
		break;
	}
}
function flameAlertPauseMessage(pausedType)
{
	var flamePaused = timerObj[todayTimer]['isTimePause'];
	if(flamePaused == 0)
	{
		if(confirm('You are only allowed to have one pause a day so choose it wisely. do you want to take a pause!')) 
		{
					timerObj[todayTimer]['isTimePause'] = 1;
					exceedPauseLimit(1);
		}
	}
	else if(flamePaused == 1)
	{
		if(confirm('You have already consumed your one allowed pause and now if you give up then you will lose your daily health points!')) 
		{
				timerObj[todayTimer]['isTimePause'] = 2;
				dailyHealthPoints(0);
				exceedPauseLimit(1)
		}
	}
	exceedTimerAndBoostLimit();
}
function exceedTimerAndBoostLimit()
{
	var flamePausedTimer = timerObj[todayTimer]['isTimePause'];
	if(flamePausedTimer > 1)
	{
		exceedPauseLimit(2);
	}
}
function exceedPauseLimit(type)
{
	var startTime = timerObj[todayTimer]['startTime'];
	if(startTime !="")
	{
		var delta = getTimeDiff(startTime);
		var totalActivity = Math.floor(delta + timerObj[todayTimer]['totalActivity']);
		timerObj[todayTimer]['totalActivity'] = totalActivity;
	}
	switch(type)
	{
		case 1:
			$("#gs_flame").attr("type","start");
			$("#gs_startGrowing").show();
			$('#gs_stopGrowing').hide();
			$(".gs_activity-section").hide();
			$(".timer_left").hide();
			$(".gs_meterProgress").show();
			$(".boostMode").hide();
			$(".gs_step1").show();
			timerObj[todayTimer]['startTime'] = '';
			timerObj[todayTimer]['isMode'] = '';
			timerObj[todayTimer]['isTimerStart'] = 'stop';
			timerObj[todayTimer]['is_writing_reading_paused'] = 0;
			setActivityStorage();
		break;
		case 2:
			failedFlameActivity();
			timerObj[todayTimer]['startTime'] = '';
			timerObj[todayTimer]['isMode'] = '';
			timerObj[todayTimer]['is_writing_reading_paused'] = 0;
			timerObj[todayTimer]['isTimerStart'] = 'failed';
			setActivityStorage();
		break;
	}
}
function failedFlameActivity()
{
	$(".boostMode").hide();
	$(".gs_step1").show();
	$('.timer_left').hide();
	$('.gs_meterProgress').show();
	$('#gs_startGrowing').html("Failed Today Activity");
	// if($('#gs_startGrowing').html("Failed Today Activity"))
	// {
    //     alert("hello world");
	// 	//$("#gs_wr-re-mode").remove();
	// 	//document.documentElement.style.overflow = 'auto';
	// }
	$('#gs_stopGrowing').remove();
	$('#gs_startGrowing').show();
	$('.gs_meterProgress').show();
	$('#gs_flame').attr("type","");
	$('#gs_flame').css("cursor","no-drop");
}
function boostModeActivity(type)
{
		
		$(".timerMode").hide();
		$(".gs_activity_boost_reading_typing").hide();
		$(".boostMode").show();
		$(".gs_activity-section").hide();
		$("#gs_flame").attr("type","stop");
		$(".timer_left").show();
		$(".gs_meterProgress").hide();
		timerObj[todayTimer]['startTime'] = '';
		timerObj[todayTimer]['isMode'] = 'boost';
		timerObj[todayTimer]['isTimerStart'] = 'yes';
		timerObj[todayTimer]['is_write_read_mode'] = type;
		timerObj[todayTimer]['is_writing_reading_paused'] = 0;
		setActivityStorage();
		boostMode();
}
function finishedFlameActivity()
{
	$(".boostMode").hide();
	$(".gs_step1").show();
	$('.timer_left').hide();
	$('.gs_meterProgress').show();
	$('#gs_startGrowing').html("Finished Today Activity");
	$('#gs_stopGrowing').remove();
	$('#gs_startGrowing').show();
	$('.gs_meterProgress').show();
	$('#gs_flame').attr("type","");
	$('#gs_flame').css("cursor","no-drop");
}
function flameStartActivity(type)
{
	var flamePausedTimer = timerObj[todayTimer]['isTimePause'];
	var flamePausedBoost = timerObj[todayTimer]['is_pause_boost'];
	switch(type)
	{
		case"timer":
				$("#gs_flame").attr("type","stop");
				$(".gs_step1").show();
				$("#gs_startGrowing").hide();
				$('#gs_stopGrowing').show();
				$(".gs_activity-section").hide();
				$(".timer_left").show();
				$(".gs_meterProgress").hide();
				timerObj[todayTimer]['startTime'] = new Date().getTime();
				timerObj[todayTimer]['isMode'] = type;
				timerObj[todayTimer]['isTimerStart'] = 'yes';
				timerObj[todayTimer]['is_writing_reading_paused'] = 0;
				setActivityStorage();
				runningTimeInterval();
		break;
		case"boost":
				$(".gs_activity_boost_reading_typing").show();
				$(".gs_activity-section").hide();
		break;
	}
}
function setLocalStorage()
{
	chrome.storage.sync.remove('todayTimer',function(res){
		chrome.storage.sync.set({"todayTimer": timerObj},function(){
			onloadFlameActivity();
		});
	});
}
function setGetLocalStorage(timerObj)
{
	if(localStorage.getItem("todayTimer"))
	{
		localStorage.removeItem("todayTimer");
	}
	localStorage.setItem("todayTimer", JSON.stringify(timerObj));
}
function setActivityStorage()
{
	chrome.storage.sync.remove('todayTimer',function(res){
		chrome.storage.sync.set({"todayTimer": timerObj},function(){});
	});
}
function onloadFlameActivity()
{
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		console.log(items);
		if(items["todayTimer"] && items['todayTimer'][todayTimer])
		{
			timerObj[todayTimer] = items['todayTimer'][todayTimer];
			todayTimerObjResponse();
		}
	});
}
function getStorageObj()
{
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		
		if(items["todayTimer"] && items['todayTimer'][todayTimer])
		{
			timerObj[todayTimer] = items['todayTimer'][todayTimer];
		}
	});
}
function todayTimerObjResponse(){
	
		console.log(timerObj);
		if(timerObj[todayTimer] && timerObj[todayTimer]['isTimerStart'] != "")
		{
				var items = timerObj[todayTimer];
				isMode = items['isMode'];
				var isTimerOn = items['isTimerStart'];
				totalActivity = items['totalActivity'];
				var today_strikes = items['today_strikes'];
				var boost_countdown = items['boost_countdown'];
				is_pause_boost = items['is_pause_boost'];
				isTimePause = items['isTimePause'];
				if(boost_countdown > 0)
				{
					is_StartWriteRead = 1;
				}
				if(isMode == "boost")
				{
					boostMode();
					var strikes = "("+today_strikes+" strike)";
					if(today_strikes > 1)
					{
						strikes = "("+today_strikes+" strikes)";
					}
					$(".gs_stricks").html(strikes);
					
				}
				if(isTimerOn == "yes")
				{
					runningTimeInterval();
				}
				isTimerType = isTimerOn;
				displayOnLoadEvents(isTimerType,isMode);
		}
	
	
}
function boostMode()
{
		var items = timerObj[todayTimer];
		if(items)
		{
			var consumedTime = getConsumedTime(items);
			generateLeftTime(consumedTime);
		}
}
function displayOnLoadEvents(type,isModeType)
{
	var flamePausedTimer = timerObj[todayTimer]['isTimePause'];
	if(flamePausedTimer > 1)
	{
		 console.log(flamePausedTimer+" flamePausedTimer")
		 failedFlameActivity();
	}
	else
	{
		switch(type)
		{
			case 'yes':
				if(isModeType == "boost")
				{
					$(".timerMode").hide();
					$(".boostMode").show();
					$(".gs_activity-section").hide();
					$("#gs_flame").attr("type","stop");
					$(".timer_left").show();
					$(".gs_meterProgress").hide();
				}
				else
				{
					$("#gs_flame").attr("type","stop");
					$(".gs_step1").show();
					$("#gs_startGrowing").hide();
					$('#gs_stopGrowing').show();
					$(".gs_activity-section").hide();
					$(".timer_left").show();
					$(".gs_meterProgress").hide();
				}
			break;
			case 'stop':
				$("#gs_flame").attr("type","start");
				$("#gs_startGrowing").show();
				$('#gs_stopGrowing').hide();
				$(".gs_activity-section").hide();
				$(".timer_left").hide();
				$(".gs_meterProgress").show();
				$(".boostMode").hide();
				$(".gs_step1").show();
			break;
			case 'completed':
				 finishedFlameActivity();
			break;
		}
	}
}
function runningTimeInterval()
{
	runningSetInterval = setInterval(function(){
					var isTimerType = timerObj[todayTimer]['isTimerStart'];
					calculateLeftTime();
					if(isTimerType == "completed" || isTimerType =="stop")
					{
						clearInterval(runningSetInterval);
					}
		},1000);
}
function calculateLeftTime()
{
			var items = timerObj[todayTimer];
			if(items != undefined && items != "")
			{
					isMode = items['isMode'];
					var isTimerOn = items['isTimerStart'];
					var is_typedWrite = items['is_StartWriteRead'];
						is_StartWriteRead = items['is_StartWriteRead'];
					var countDown = items['boost_countdown'];
					if(isMode == "timer" && isTimerOn == "yes")
					{
						var consumedTime = getConsumedTime(items);
						generateLeftTime(consumedTime);
					}
					if(is_StartWriteRead == 1 && isMode == "boost")
					{
						if(countDown != "")
						{
							    is_running_boost_time = 1;
								is_StartWriteRead = 0;
								clearInterval(progressSetIn);
								progressBarCount = 59 - Math.floor(getTimeDiff(countDown));
								if(progressBarCount <= 0)
								{
									progressBarCount = 59;
								}
								timerObj[todayTimer] = items;
								progrssBar();
						}
					}
			}
}
function getConsumedTime(items)
{
			 var timerStart = Math.floor(items['startTime']);
			 var isTimerOn = items['isTimerStart'];
			 totalActivity = items['totalActivity'];
			 var targetTime = items['targetTime'];
			 isMode = items['isMode'];
			 var consumedTime = totalActivity*60;
			 if(timerStart !="")
			 {
				consumedTime = parseInt(getTimeDiff(timerStart) + consumedTime);
			 }
			consumedTime = targetTime - consumedTime;
			return consumedTime;
}
function generateLeftTime(remainTime)
{
		$(".timer_left font-title").html("<timer id='gs_remainTime'></timer>");
		$(".timer_left").show();
		$(".gs_meterProgress").hide();
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		var leftTime = "";
		if(hour > 0)
		{
			leftTime = "Hours Left.";
		}
		else if(hour == 0 && minute > 0)
		{
			leftTime = "Minutes Left.";
		}
		else if(minute == 0 && second > 0)
		{
			leftTime = "Seconds Left.";
		}
		if(remainTime > 0)
		{
			var totalTime = hour+":"+minute;
			if(minute == 0 && second > 0)
			{
				totalTime = minute+":"+second;
			}
			$('#gs_remainTime').html(totalTime +" "+ leftTime);
		}
		else if(remainTime <= 0)
		{
			timerObj[todayTimer]['isTimerStart'] = "completed";
			setActivityStorage();
			dailyHealthPoints(1);
		}
}
function getTimeDiff(timerStart)
{
	var date1 = timerStart;
	var date2 = new Date();
	var delta = Math.abs(date2 - date1) / 1000;
	return delta;
}
function progrssBar()
{
	if(progressBarCount == 59)
	{
		makeProgressCircle();
	}
	timerObj[todayTimer]['is_StartWriteRead'] = 0;
	setActivityStorage();
	var count = $(('#count'));
	if(progressBarCount == 0)
	{
		boostMode();
	}
	count.text(progressBarCount);
	progressSetIn = setInterval(function(){
		var perVal = 100*progressBarCount/59;
		progress(perVal);
		if(progressBarCount == 0)
		{
			boostMode();
			is_running_boost_time = 0;
			chrome.storage.sync.get(["todayTimer"], function(items)
			{
				console.log(items);
				if(items["todayTimer"] && items['todayTimer'][todayTimer])
				{
					timerObj[todayTimer] = items['todayTimer'][todayTimer];
					var today_strikes = timerObj[todayTimer]['today_strikes'];
					/* var userLevel = timerObj[todayTimer]['user_current_level'];
					if(today_strikes == 10)
					{
						if(userLevel < 10)
						{
							$(".user-status level").html("Level 0"+userLevel);
						}
						else
						{
							$(".user-status level").html("Level "+userLevel);
						}
					} */
					var strikes = "("+today_strikes+" strike)";
					if(today_strikes > 1)
					{
						strikes = "("+today_strikes+" strikes)";
					}
					$(".gs_stricks").html(strikes);
					clearInterval(progressSetIn);
				}
			})
		}
		if(progressBarCount < 0)
		{
			clearInterval(progressSetIn);
		}
		count.text(progressBarCount);
		progressBarCount--;
	},1000);
} 
const SVG_NS = 'http://www.w3.org/2000/svg';
const CIRCUMFERENCE = base.getTotalLength()
const UNIT = CIRCUMFERENCE / 100;
let circles=[];//the array of circles
//create 100 circles each with a different fill color to create the illusion of a gradient
function makeProgressCircle()
{
	for(let i = 0; i<100; i++)
	{
		hslColor = "hsl("+i+", 100%, 50%)";
		let pos = base.getPointAtLength(i*UNIT);
		let o = {cx:pos.x,cy:pos.y,r:5,'fill-opacity':0,fill:hslColor}
		circles.push(drawCircle(o, progress__value));  
	}
}
makeProgressCircle();
progress(100);
//control.addEventListener('input', progress);
function progress(circleVal){
  let val = circleVal;
  for(let i = 0; i<circles.length; i++){
    if(i<=val){
		circles[i].setAttributeNS(null,'fill-opacity',1)    
		//circles[i].setAttributeNS(null,'fill',hslColor)    
    }else{
		circles[i].setAttributeNS(null,'fill-opacity',0)
    }
  } 
}
// a function to create a circle
function drawCircle(o, parent) {
  var circle = document.createElementNS(SVG_NS, 'circle');
  for (var name in o) {
    if (o.hasOwnProperty(name)) {
      circle.setAttributeNS(null, name, o[name]);
    }
  }
  parent.appendChild(circle);
  return circle;
} 