(function() {
console.log('content.js loaded');
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
var todayTyped = "typedWords_"+ dd + '/' + mm + '/' + yyyy;
var todayRead = "readWords_"+ dd + '/' + mm + '/' + yyyy;
var todayTimer = "timer_"+ dd + '/' + mm + '/' + yyyy;
var timerObj = {};
var dailyRoutineObj = {};
var routineTargetObj = {};
var blockWebsiteObj = {};
var funTimer = 10;
var selectedLine = 0;
var selectedString = '';
var selectedCount = '';
var getTypedCount = 0;
var getReadCount = 0;
var isMode ='';
var totalActivity = 0;
var user_id = 0;
var storageObj = {};
var baseUrl = "https://development.brstdev.com/productivitystimulus";
var isTimerType = '';
var boostSetIn = '';
var is_running_time = 0;
var is_typed_word = 0;
var is_typed_word_count = 0;
var minsCantake = 1;
var runningClearIn = '';
chrome.storage.sync.get(null, function(items) {
    var allKeys = Object.keys(items);
    console.log(allKeys);
});
timerObj[todayTimer] = {
	"startTime":"",
	"totalActivity":0,
	"isTimerStart":"",
	"funTab":'',
	"isFunTabPopUp":0,
	"currentTab":0,
	"isFunTabBrowsers":0,
	"targetTime":0,
	"isTimePause":0,
	"isMode":'',
	"typedWordsCount":0,
	"readWordsCount":0,
	"hpEarnPopUp":0,
	"funPopUpStartTime":0,
	'giveUp':0,
	'is_StartWriteRead':0,
	'today_strikes':0,
	'user_selected_words' :0,
	'user_typed_words':0,
	'chosen_selected_word':20,
	'chosen_typed_word':20,
	'is_pause_boost':0,
	'boost_countdown':0,
	'is_flame_start':0,
	'total_boost_time':0
}
dailyRoutineObj[todayTimer] = {};
routineTargetObj[todayTimer] = {};
var typeText = '';
var wordCount = 0;
function listener()
{
    console.debug("listener fired.");
}
var hidden, visibilityChange; 
if (typeof document.hidden !== "undefined") { // Opera 12.10 and Firefox 18 and later support 
  hidden = "hidden";
  visibilityChange = "visibilitychange";
} else if (typeof document.msHidden !== "undefined") {
  hidden = "msHidden";
  visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
  hidden = "webkitHidden";
  visibilityChange = "webkitvisibilitychange";
}
 function handleVisibilityChange(callback) {
  var isBrowserTab = ""; 
  if(document[hidden])
  {
	 isBrowserTab = "hidden";
  } 
  else 
  {
	isBrowserTab = "visible";
  }
  //console.log('++++++++++++');
  callback(isBrowserTab);
  
}
handleVisibilityChange(function(res){
	console.log('+++',res);
})
var timeout = null;
document.addEventListener("DOMSubtreeModified", function() {
    if(timeout) {
        clearTimeout(timeout);
    }
    timeout = setTimeout(listener, 500);
}, false);
function handle(e) {
			//console.log(e.code);
			if(isMode !="boost")
			{
				return true;
			}
			var nodeName = e.target.nodeName;
			if("BODY" != nodeName && e.type !="keydown") 
			{
				if(e.srcElement.textContent != undefined && e.srcElement.textContent !="")
				{
					typeText = e.srcElement.textContent;
					countWords(typeText);
					
				}
				else if(e.srcElement.value != undefined && e.srcElement.value !="")
				{
					typeText = e.srcElement.value;
					countWords(typeText);
				}
			}
			else if(e.key == "Backspace")
			{
				if(e.srcElement.textContent !="")
				{
					typeText = e.srcElement.textContent;
					countWords(typeText);
				}
				else if(e.srcElement.value !="")
				{
					typeText = e.srcElement.value;
					countWords(typeText);
				}
				
			}
			if(e.code == "Space")
			{
				var lastword = typeText.split(" ").pop();
				if(is_typed_word == "")
				{
					is_typed_word = lastword;
				}
				else
				{
					is_typed_word = is_typed_word+" "+lastword;
				}
				is_typed_word = is_typed_word;
				is_typed_word = is_typed_word.replace(/(^\s*)|(\s*$)/gi,"");
				is_typed_word = is_typed_word.replace(/[ ]{2,}/gi," ");
				is_typed_word = is_typed_word.replace(/\n /,"\n");
				is_typed_word_count = parseInt(is_typed_word.split(' ').length);
			}
}
function countWords(typeText)
{
		if(typeText != "")
		{
			s = typeText;
			s = s.replace(/(^\s*)|(\s*$)/gi,"");
			s = s.replace(/[ ]{2,}/gi," ");
			s = s.replace(/\n /,"\n");
			wordCount = parseInt(s.split(' ').length);
			//console.log(wordCount);
			var totalWord = parseInt(wordCount + getTypedCount);
			timerObj[todayTimer]['typedWordsCount'] = totalWord;
			
			userBoostNotification(1);
		}
}
var lastPosi = 0;
var totalWordSel = 0;
function handleUp(e)
{	
	if(isMode != "boost")
	{
		return true;
	}
	var nodeEl = window.getSelection().anchorNode.parentNode.parentNode;
	//nodeEl = $(nodeEl).parents();
	console.log(window.getSelection);
	//console.log(document.selection.createRange().text.length);
	if(window.getSelection && !document.getSelection().isCollapsed) 
	{
				if(e.code == "Enter")
				{
					var pos = getSelectionCharOffsetsWithin(nodeEl);
					lastPosi = pos.end;
					setSelectionRange(nodeEl, pos.end, (lastPosi+totalWordSel));
				}
				var selection = getSelectedText();
				//console.log(selection);
				var selection_text = selection.toString();
				selectedString += selection_text;
				if(totalWordSel < 1)
				{
					var pos = getSelectionCharOffsetsWithin(nodeEl);
					lastPosi = pos.end;
					totalWordSel = pos.end;
					setSelectionRange(nodeEl, pos.start, pos.end);
				}
				splitStr = selectedString.split(" ");
				var selectTotalWord = selection_text.split(" ");
				//console.log(getReadCount);
				var totalCount = parseInt(splitStr.length + getReadCount);
				timerObj[todayTimer]['readWordsCount'] = totalCount;
				timerObj[todayTimer]['user_selected_words'] = selectTotalWord.length;
				timerObj[todayTimer]['is_StartWriteRead'] = 1;
				
				userBoostNotification(2);
	}
}
function getSelectionCharOffsetsWithin(element) {
    var start = 0, end = 0;
    var sel, range, priorRange;
    if (typeof window.getSelection != "undefined") {
        range = window.getSelection().getRangeAt(0);
        priorRange = range.cloneRange();
        priorRange.selectNodeContents(element);
        priorRange.setEnd(range.startContainer, range.startOffset);
        start = priorRange.toString().length;
        end = start + range.toString().length;
    } else if (typeof document.selection != "undefined" &&
            (sel = document.selection).type != "Control") {
        range = sel.createRange();
        priorRange = document.body.createTextRange();
        priorRange.moveToElementText(element);
        priorRange.setEndPoint("EndToStart", range);
        start = priorRange.text.length;
        end = start + range.text.length;
    }
    return {
        start: start,
        end: end
    };
}
function getTextNodesIn(node) {
    var textNodes = [];
    if (node.nodeType == 3) {
        textNodes.push(node);
    } else {
        var children = node.childNodes;
        for (var i = 0, len = children.length; i < len; ++i) {
            textNodes.push.apply(textNodes, getTextNodesIn(children[i]));
        }
    }
    return textNodes;
}
function setSelectionRange(el, start, end) {
    if (document.createRange && window.getSelection) {
        var range = document.createRange();
        range.selectNodeContents(el);
        var textNodes = getTextNodesIn(el);
        var foundStart = false;
        var charCount = 0, endCharCount;

        for (var i = 0, textNode; textNode = textNodes[i++]; ) {
            endCharCount = charCount + textNode.length;
            if (!foundStart && start >= charCount
                    && (start < endCharCount ||
                    (start == endCharCount && i <= textNodes.length))) {
                range.setStart(textNode, start - charCount);
                foundStart = true;
            }
            if (foundStart && end <= endCharCount) {
                range.setEnd(textNode, end - charCount);
				range.app
                break;
            }
            charCount = endCharCount;
        }

        var sel = window.getSelection();
		var percentage = document.createElement('percentage');
		percentage.setAttribute("class", "percentage_"+selectedLine);
		range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
		range.insertNode(percentage);
		//range.detach();
		selectTextRange(el, start, end);
    } else if (document.selection && document.body.createTextRange) {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(true);
        textRange.moveEnd("character", end);
        textRange.moveStart("character", start);
        textRange.select();
    }
}
function selectTextRange(el, start, end)
{
		if (document.createRange && window.getSelection) {
				var range = document.createRange();
				range.selectNodeContents(el);
				var textNodes = getTextNodesIn(el);
				var foundStart = false;
				var charCount = 0, endCharCount;
				for (var i = 0, textNode; textNode = textNodes[i++]; ) {
					endCharCount = charCount + textNode.length;
					if (!foundStart && start >= charCount
							&& (start < endCharCount ||
							(start == endCharCount && i <= textNodes.length))) {
						range.setStart(textNode, start - charCount);
						foundStart = true;
					}
					if (foundStart && end <= endCharCount) {
						range.setEnd(textNode, end - charCount);
						range.app
						break;
					}
					charCount = endCharCount;
				}
		}
		var sel = window.getSelection();
		sel.removeAllRanges();
		sel.addRange(range);
}

function getSelectedText() {
  t = (document.all) ? document.selection.createRange().text : document.getSelection();

  return t;
}
function funPopUp(callback){
	var funCss = "";
	var funHTml = "<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;'></div>\n\
			<div id='gs_funPopUpTimer' class='gs_funPopUp' style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_skipbtn' style='width: 30%;float:right;padding:3% 5%;text-align: center'>\n\
					<span id='gs_skipPausedTimer' style='padding:2% 12%;background-color:#616161;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Skip Pause!</span>\n\
		   </div>\n\
	   <div class='gs_funPauseSection' style='display:table;height:80%;width:100%;'>\n\
	   <div class='gs_funPauseChid' style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size:25px;'>Fun Pause Unlocked</span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
	   <span id='gs_timer_msg' style='width:75%;display: inline-block;font-size: 20px; font-family: auto;letter-spacing: 3px;'>Congratulations! You have been successfully working for <span id='gs_unlockedTimer'>00:25 Minutes </span>. you have unlocked a 00:05 Minutes fun pause! </span>\n\
	   <div style='padding:5%;width:100%'></div>\n\
	   </div>\n\
	   </div>\n\
	   </div>";
	callback(funHTml);
}
function earnHealthPoints(callback){
	var funHTml = "<div id='gs_hpPopUp'>\n\
			<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;'></div>\n\
			<div style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
			<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
					<span id='gs_closePopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
		   </div>\n\
	   <div  style='display:table;height:80%;width:100%;'>\n\
	   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
	   <span style='font-size: 38px;padding: 7px;background-color: #808080;border: 2px solid #FF0000;color: #fff;border-radius: 5px;'>+HP Earned!</span>\n\
	   <div style='padding:4%;width:100%'></div>\n\
	   </div>\n\
	   </div>\n\
	   </div>\n\
	</div>";
	callback(funHTml);
}
function isNotifiOpenPopUp(){
	var options = {
					notify:"notify"
				  }
	chromeRuntimeSendMsg(options);
	timerObj[todayTimer]['funPopUpStartTime'] =  new Date().getTime();
	timerObj[todayTimer]['isTimerStart'] = "stop";
	timerObj[todayTimer]['isFunTabPopUp'] = 1;
	timerObj[todayTimer]['startTime'] = "";
	
}
function appendHtml(totalTime)
{
		funPopUp(function(resHtml){
			 var div = document.createElement("div");
				div.setAttribute("id", "gs_funTimePopUp");
				div.innerHTML = resHtml;
				document.body.appendChild(div);
				var checkHtml = $("#gs_funTimePopUp").html();
				$("#gs_skipPausedTimer").on("click",function(){
					var options = {
								 closeTab:"closeTab"
							 }
					  chromeRuntimeSendMsg(options);
					 if(isMode !="boost")
					 {
						 timerObj[todayTimer]['startTime'] = new Date().getTime();
					 }
					 else
					 {
						 timerObj[todayTimer]['startTime'] = "";
					 }
					timerObj[todayTimer]['isTimerStart'] = "yes";
					timerObj[todayTimer]['isMode'] = isMode;
					
					$("#gs_funTimePopUp").remove();
			});
			$("#gs_unlockedTimer").html(totalTime);
	});	
}
function getTimeDiff(timerStart)
{
	var date1 = timerStart;
	var date2 = new Date();
	var delta = Math.abs(date2 - date1) / 1000;
	return delta;
}
function ajaxCall(url,params,callback,errorcallback)
{
			
			jQuery.ajax({
				url: url,
				type: 'POST',
				data:params,
				dataType: 'json',
				success: function (data) {
					callback(data);
				},
				error: function (e) {
					errorcallback(e);
				}
			});
}
function errorcallback(error)
{
    if(window.console){ console.log(error); }
}
var params = {};
chrome.storage.sync.get(["loginUser"], function(items)
{
		if(items && items['loginUser'] && items['loginUser']['email'])
		{
			var params = items['loginUser'];
				params['extId'] = chrome.runtime.id;
			userSignUp(params,function(res){
			var dataParms = {};
			if(res['data'] && res['data']['user_id'])
			{
				user_id = res['data']['user_id'];
				var dataParms = {"user_id":user_id}
				getUserRoutine(dataParms,function(res){
					dailyRoutineObj[todayTimer] = res['data'];
					chrome.storage.sync.set({"dailyRoutine": dailyRoutineObj},function(){ });
					//checkRoutineTime();
				});
			}
		});
	 }
});
/* function checkRoutineTime()
{
if(localStorage.getItem("actRoutine"))
{
	var jsonString = localStorage.getItem("actRoutine");
	var retrievedObject = JSON.parse(jsonString);
	console.log(retrievedObject);
	var id = retrievedObject[todayTimer]['id'];
	var setTarget = retrievedObject[todayTimer]['setTarget'];
	var getTime = retrievedObject[todayTimer]['startTime'];
	isMode = retrievedObject[todayTimer]['is_mode'];
	var targetT = retrievedObject[todayTimer]['targetT'];
	if(retrievedObject[todayTimer] && retrievedObject[todayTimer]['startedBy'])
	{
		var startedBy = retrievedObject[todayTimer]['startedBy'];
		var parms = {"startedBy":startedBy,"id":id};
		routineStarted(parms,function(){
				routineTargetObj[todayTimer] = {"id":id,"setTarget":setTarget,"startTime" :getTime,"endTime":"","is_routineActive":1,"is_mode":isMode,"targetT":targetT};
				chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ 
					localStorage.removeItem("actRoutine");
				});
		});
	}
	else
	{
		routineTargetObj[todayTimer] = {"id":id,"setTarget":setTarget,"startTime" :getTime,"endTime":"","is_routineActive":1,"is_mode":isMode,"targetT":targetT};
		chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ 
			localStorage.removeItem("actRoutine");
		});
	}
	
}	
	var date = new Date; 
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var Seconds = date.getSeconds();
	var ampm = hours >= 12 ? 'pm' : 'am';
	hours = hours % 12;
	hours = hours ? hours : 12; // the hour '0' should be '12'
	minutes = minutes < 10 ? '0'+minutes : minutes;
  chrome.storage.sync.get(["dailyRoutine"], function(items){
	  if(items['dailyRoutine'] && items['dailyRoutine'][todayTimer])
	  {
		  var routineD = items['dailyRoutine'][todayTimer];
		  for(var i = 0;i< routineD.length;i++)
		  {
			  var id = routineD[i]['id'];
			  var description = routineD[i]['description'];
			  var title = routineD[i]['title'];
			  var hours_amount = routineD[i]['hours_amount'];
			  hours_amount = hours_amount.split(" ");
			  var setTarget = hours_amount[0];
			  var getRoutineH = routineD[i]['time_of_day'];
			  isMode = routineD[i]['is_mode'];
			  getRoutineH = getRoutineH.split(":");
			  var routineH = getRoutineH[0];
			  var routineM = getRoutineH[1];
			  var timeFormat = routineH >= 12 ? 'pm' : 'am';
			  if(routineH > 12)
			  {
					routineH = routineH - 12;
			  }
			  var setTargetHours = routineD[i]['setTime'];
			  var splitH =  setTargetHours.split(" ");
			  var setTime = splitH[0];
			  var targetT = 0;
			  if(setTime == 30)
			  {
				targetT = setTime*60;
			  }
			  else
			  {
				targetT = setTime*60*60;
			  }
			  if(timeFormat == ampm)
			  {
				  if(routineH == hours && routineM == minutes && Seconds == 1)
				  {
					
					  var startTime = new Date();
					  var getTime = startTime.getTime();
					  routineTargetObj[todayTimer] = {"id":id,"setTarget":setTarget,"startTime" :getTime,"endTime":"","is_routineActive":1,"is_mode":isMode,"targetT":targetT,"description":description,'title':title};
					  chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ });
					  //checkRoutineComplete();			
				  }
			  }
		  }
	  }
  });
} */
/* function checkRoutineComplete()
{
	 chrome.storage.sync.get(["currentRoutineActive"], function(items){
		 if(items['currentRoutineActive'] && items['currentRoutineActive'][todayTimer])
		 {
			var isActive = items['currentRoutineActive'][todayTimer]['is_routineActive'];
			if(isActive == 1)
			{
				var startT = items['currentRoutineActive'][todayTimer]['startTime'];
				var setTarget = items['currentRoutineActive'][todayTimer]['setTarget'];
				var id = items['currentRoutineActive'][todayTimer]['id'];
				isMode = items['currentRoutineActive'][todayTimer]['is_mode'];
				var targetT = items['currentRoutineActive'][todayTimer]['targetT'];
				var description = items['currentRoutineActive'][todayTimer]['description'];
				var title = items['currentRoutineActive'][todayTimer]['title'];
				var getTime = getTimeDiff(startT);
				var time = getTime;
				var second = time % 60;
				var minute = Math.floor(time / 60) % 60;
				var hour = Math.floor(time / 3600) % 60;
				second = (second < 10) ? '0'+second : second;
				minute = (minute < 10) ? '0'+minute : minute;
				//console.log(hour , minute , setTarget ,Math.round(second));
				second = Math.round(second);
				if(minute == 0 && second == 5)
				{
						var options = {
									 routineStart:"routineNotify",
									 title:title,
									 dec:description
								 }
					chromeRuntimeSendMsg(options);
					timerObj[todayTimer]['isTimerStart'] = "yes";
					timerObj[todayTimer]['isMode'] = isMode;
					if(isMode !="boost")
					{
						timerObj[todayTimer]['startTime'] = new Date().getTime();
					}
					else{
						timerObj[todayTimer]['startTime'] = "";
					}
					timerObj[todayTimer]['funPopUpStartTime'] = new Date().getTime();
					timerObj[todayTimer]['targetTime'] = targetT;
					setChromeStorage(timerObj);
				}
				if(setTarget == 30)
				{
					if(setTarget == minute)
					{
						var params = {};
						params['id'] = id;
						
						if(isMode !="boost")
						{
							params['consumed'] = minute;
						}
						routineCompleted(params,function(){
							 routineTargetObj[todayTimer] = {"is_routineActive":0};
							 chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ });
							 var options = {
										routineNotifyDone:"routineNotify"
									}
								chromeRuntimeSendMsg(options);
						});
						timerObj[todayTimer]['isTimerStart'] = "stop";
						timerObj[todayTimer]['isMode'] = "";
						isMode = "";
						timerObj[todayTimer]['totalActivity'] = parseInt(setTarget*60 + totalActivity);
						timerObj[todayTimer]['startTime'] = "";
						setChromeStorage(timerObj);	
					}
				}
				else if(setTarget == hour)
				{
						var params = {};
						params['id'] = id;
						params['consumed'] = hour;
						routineCompleted(params,function(){
								routineTargetObj[todayTimer] = {"is_routineActive":0};
								chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ });
								timerObj[todayTimer]['isTimerStart'] = "stop";
								timerObj[todayTimer]['isMode'] = "";
								isMode = "";
								timerObj[todayTimer]['totalActivity'] =  parseInt(setTarget*60*60 + totalActivity);
								timerObj[todayTimer]['startTime'] = "";
								setChromeStorage(timerObj);
								var options = {
										routineNotifyDone:"routineNotify"
									}
								 chromeRuntimeSendMsg(options);
						});
				}
			}
		 }
	 });
	
} */
function funTabOpenFunc(timeType,hours,minute)
{
		var totalTime = 0;
		if(timeType == "Hours")
		{
			totalTime = hours+":"+minute+" Hours";
			timerObj[todayTimer]['totalActivity'] = hours*60*60;
		}
		else if(timeType == "Minutes")
		{
			timerObj[todayTimer]['totalActivity'] = minute*60;
			totalTime = "00:"+minute+" Minutes";
		}
		appendHtml(totalTime);
		setTimeout(function(){	
			isNotifiOpenPopUp();
		},3000);
		
}
function closefunPopUpActivity()
{
	var items = storageObj;
	if(items["todayTimer"] && items)
	{
		
		var modeType = items['isMode'];
		if(modeType == "timer")
		{
				var startT = items['funPopUpStartTime'];
				var isTimerOn = items['isTimerStart'];
				var getTime = getTimeDiff(startT);
				var time = getTime;
				var second = time % 60;
				var minute = Math.floor(time / 60) % 60;
				var hour = Math.floor(time / 3600) % 60;
				second = Math.round(second);
				if(minute == 1 && second == 2 && isTimerOn =="stop")
				{
					var options = {
									closeTab:"closeTab"
								  }
					chromeRuntimeSendMsg(options);
				}
				else if(minute == 1 && second == 5 && isTimerOn =="stop")
				{
				   $("#gs_timer_msg").html("You have done your fun time!");
				}
				else if(minute == 1 && second == 8 && isTimerOn =="stop")
				{
					timerObj[todayTimer]['isFunTabBrowsers'] = 0;
					timerObj[todayTimer]['isFunTabPopUp'] = 2;
					$("#gs_funTimePopUp").remove();
					timerObj[todayTimer]['isTimerStart'] = "yes";
					timerObj[todayTimer]['isMode'] = isMode;
					if(isMode !="boost")
					{
						timerObj[todayTimer]['startTime'] = new Date().getTime();
					}
					else
					{
						timerObj[todayTimer]['startTime'] = "";
					}
					
				}
		}
	}
}
function openFunPopUp()
{
	if(storageObj["todayTimer"] && storageObj["todayTimer"][todayTimer])
	{
		
		var modeType = storageObj["todayTimer"][todayTimer]['isMode'];
		if(modeType == "timer")
		{
			var timerStart = Math.floor(storageObj["todayTimer"][todayTimer]['startTime']);
			var funTabTime = storageObj["todayTimer"][todayTimer]['funTab'];
			var splitFunTime = funTabTime.split(" ");
			var splitFunTime = funTabTime.split(" ");
			var funTime = splitFunTime[0];
			var funTimehourMin = splitFunTime[1];
			var remainTime = parseInt(getTimeDiff(timerStart));
			var second = remainTime % 60;
			var minute = Math.floor(remainTime / 60) % 60;
			var hours = Math.floor(remainTime / 3600) % 60;
			var splitHoursMins = splitFunTime[0].split(":");
			var funHours = splitHoursMins[0];
			var funMins = splitHoursMins[1];
			if(funTimehourMin == "Hours" && funHours == hour && funMins == minute && second == 1)
			{
				funTabOpenFunc(funTimehourMin,hours,minute);
			}
			else if(funTimehourMin == "Minutes" && funTime == minute && second == 1)
			{
				funTabOpenFunc(funTimehourMin,hours,minute);
			}
		}
	}
}
function routineStarted(params,callback)
{
		var url = baseUrl+"/goals/routine-started";
		 //var params = {};
		 ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);  
}
function getUserRoutine(params,callback)
{
	 var url = baseUrl+"/goals/get-user-routine";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function routineCompleted(params,callback)
{
	 var url = baseUrl+"/goals/user-completed-routine";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function userSignUp(params,callback)
{
	 var url = baseUrl+"/site/user-sign-up";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function getBlockWebsite(params,callback)
{
	var params = {};
	 var url = baseUrl+"/block/get-block-site";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function blockWebsitefunc()
{
getBlockWebsite('',function(res){
	var allowWebsite = ['google.com','wikipedia.org','lipsum.com'];
	if(res && res['data'])
	{
		var objLength = Object.keys(res['data']).length;
		if(objLength > 0)
		{
			var whiteListWeb = false;
			for(var i =0; i < objLength; i++)
			{
				var blockSites = res['data'][i][0];
				var restricted = blockSites.split('.').slice(-2).join('.');
				var currentWeb = window.location.href;
				if(currentWeb.indexOf(restricted) > -1)
				{
					whiteListWeb = true;
				}
			}
			var appWeb = window.location.href;
			if(appWeb.indexOf(baseUrl) > -1)
			{
				whiteListWeb = true;
			}
			for(var j=0;j< allowWebsite.length;j++)
			{
				var web = allowWebsite[j];
				if(appWeb.indexOf(web) > -1)
				{
					whiteListWeb = true;
				}
			}
			if(whiteListWeb == false)
			{
				if(!$("#giveUpPopUp").html())
				{
					giveUpPopUp();
					return;
				}
			}
		}
	}
});
}
function giveUpPopUp()
{
		var div = document.createElement("div");
		div.setAttribute("id", "giveUpPopUp");
		var giveUpHTml = "<div id='gs_overlay' style='width: 100%;height: 100%;opacity: 0.5;top: 0;z-index: 999999;   background-color: #000;position: fixed;'></div>\n\
				<div style='position:fixed;width:70%;height:72%;background-color:#fff;color:#000;top:0;z-index:999999;margin:91px 15%;box-shadow: 0 3px 9px rgba(0,0,0,.5);border: 1px solid rgba(0,0,0,.2);'>\n\
				<div id='gs_closeBtn' style='width: 30%;float:right;padding:3% 5%;text-align: right'>\n\
						<span id='gs_closeGiveUpPopUp' class='gs_closeGiveUpPopUp' style='padding:2% 12%;background-color:#808080;border:3px solid #000;border-radius:5px;cursor:pointer;color: #fff;border-radius: 5px;'>Close</span>\n\
			   </div>\n\
		   <div  style='display:table;height:80%;width:100%;'>\n\
		   <div  style='display:table-cell;height:100%;width:100%; vertical-align: middle;text-align:center;'>\n\
					<span style='display:inline-block;width:100%;text-align:center;font-size:50px;' id='giveupLeftTime'>\n\</span>\n\
					<span style='display:inline-block;width:100%;text-align:center;margin: 3% 0px;'>\n\
						<button style='padding: 10px 10px;font-size: 26px;vertical-align: middle;background-color:#808080;color:#fff;border: 1px solid #000;border-radius: 4px;cursor:pointer;' id='gs_giveUp'>Give Up</button>\n\
					</span>\n\
					<span style='color: #fff;font-size:18px;padding: 7px;background-color: #808080;border-radius: 5px;'>Caution! if you give up now you will lose 3 level and go back to level 1. \n\</span>\n\
		   <div style='padding:4%;width:100%'></div>\n\
		   </div>\n\
		   </div>\n\
		   </div>";
		   div.innerHTML = giveUpHTml;     
		   document.body.appendChild(div);
		   document.documentElement.style.overflow = 'hidden';
		   $("#gs_giveUp").on("click",function(){
					timerObj[todayTimer]['giveUp'] = 1;
					
					if(confirm('Do you want give up!')) 
					{
						 giveUp();
						 document.documentElement.style.overflow = 'auto';
					}
					else
					{
						timerObj[todayTimer]['giveUp'] = 0;
						
					}
					
					
			});
			$(".gs_closeGiveUpPopUp").on("click",function(){
						var options = {
										unwantedSite:"unwantedSite"
									  }
					chromeRuntimeSendMsg(options);
			});
			var options = {
							prohibitedSite:"prohibitedSite"
						  }
			chromeRuntimeSendMsg(options);
			
}
function setChromeStorage(timerObj,isUpdatestorage)
{
	chrome.storage.sync.remove('todayTimer',function(res){
		chrome.storage.sync.set({"todayTimer": timerObj},function(){ 
				getChromeStorageItems(isUpdatestorage);
		});
	});
	
	
}
function chromeRuntimeSendMsg(options)
{
	if(chrome.runtime && chrome.runtime.sendMessage){
		chrome.runtime.sendMessage(options, function(response) {	
		});
	}
}
function giveUp()
{
		giveUpLevel(function(res)
		{
			if(res['success'] == "true")
			{
				 timerObj[todayTimer]['giveUp'] = 1;
				 setChromeStorage(timerObj,2);
				 $("#giveUpPopUp").remove();
			}
		});
}
function giveUpLevel(callback)
{
		var params = {"extId":chrome.runtime.id,'user_id':user_id}
		var url = baseUrl+"/site/give-up";
		 //var params = {};
		 ajaxCall(url,params,
				function(response)
				{ 
						 callback(response);
				},
				function(error){ errorcallback(error)}
		);  
}
function calculateLeftTime()
{
		var items = storageObj;
		//console.log(storageObj);
		if(items != undefined && items != "")
		{
			if(items["todayTimer"] && items)
			{
				isMode = items['isMode'];
				var isGiveUp = items['giveUp'];
				var isTimerOn = items['isTimerStart'];
				var isFunTabPopUp = items['isFunTabPopUp'];
				if(isFunTabPopUp == 0)
				{
					
					  openFunPopUp();
				}
				else if(isFunTabPopUp == 1)
				{
					closefunPopUpActivity();
				}
				if(isTimerOn == "yes")
				{
					if(isGiveUp !=1 && user_id > 0)
					{
						if(!$("#giveUpPopUp").html())
						{
							blockWebsitefunc();
						}
					}
					else
					{
						if($("#giveUpPopUp").html())
						{
							$("#giveUpPopUp").remove();
						}
					}
					var consumedTime = getConsumedTime(items);
					generateLeftTime(consumedTime);
					
				}
				else if(isTimerOn == "stop")
				{
						if($("#giveUpPopUp").html())
						{
							$("#giveUpPopUp").remove();
						}
				}
			}
		}
}
function getChromeStorageItems(isUpadate)
{
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		if(items["todayTimer"] && items["todayTimer"][todayTimer])
		{
			//console.log('++++++++++');
			timerObj[todayTimer] = items["todayTimer"][todayTimer];
			console.log(items);
			todayTimerObjResponse();
		}
		
	});
}
function todayTimerObjResponse()
{
		//console.log(timerObj);
		if(timerObj[todayTimer])
		{
			
			var items = timerObj[todayTimer];
			//console.log(timerObj[todayTimer]);
			storageObj = items;
			isMode = items['isMode'];
			var isTimerOn = items['isTimerStart'];
			totalActivity = items['totalActivity'];
			getReadCount = items['readWordsCount'];
			getTypedCount = items['typedWordsCount'];
			var isFunTabPopUp = items['isFunTabPopUp'];
			isTimerType = isTimerOn;
			if(isMode == "boost")
			{
				boostMode();
			if(isMode !="" && isMode == "boost" && isTimerOn == "yes")
			{ 
				onkeypress = onkeydown = handle;
				onmouseup = onkeydown = handleUp;
				styleTag();
			}
			}
			if((isTimerOn == "yes" || isFunTabPopUp == 0))
			{
					runningTimeInterval();
			}
		}
}
function boostMode()
{
		var items = storageObj;
		if(items)
		{
			var consumedTime = getConsumedTime(items);
			generateLeftTime(consumedTime);
			funPopUpBoostMode(consumedTime);
		}
}
function funPopUpBoostMode(remainTime)
{
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		if(remainTime < 0)
		{
			timerObj[todayTimer]['isTimerStart'] = "completed";
			timerObj[todayTimer]['hpEarnPopUp'] = 1;
			setChromeStorage(timerObj,1);
		}
}
function runningTimeInterval()
{
		runningClearIn = setInterval(function(){
			calculateLeftTime();
			if(isTimerType == "completed" || isTimerType =="stop")
			{
				clearInterval(runningClearIn);
			}
		},1000);
}
function getConsumedTime(items)
{
			 var timerStart = Math.floor(items['startTime']);
			 var isTimerOn = items['isTimerStart'];
			 totalActivity = items['totalActivity'];
			 getTypedCount = items['typedWordsCount'];
			 getReadCount = items['readWordsCount'];
			 var targetTime = items['targetTime'];
			 isMode = items['isMode'];
			 var completedTime = 0;
			 var totalReadTypedT = 0;
			 if(getTypedCount > 1 || getReadCount > 1)
			 {
				var getReadWriteTime = 0;
				var getTypedTime = 0;
				if(getTypedCount > 1)
				{
					getTypedTime = getTypedCount/20;
				}
				if(getReadCount > 1)
				{
					getReadWriteTime = getReadCount/20;
				}
				totalReadTypedT = parseInt(getTypedTime+getReadWriteTime)*60;
			}
			var consumedTime = parseInt(totalReadTypedT + totalActivity);
			if(timerStart !="")
			{
				consumedTime = parseInt(getTimeDiff(timerStart)+totalReadTypedT + totalActivity);
			}
			//targetTime = 10*60;
			consumedTime = targetTime - consumedTime;
			if(consumedTime <= targetTime)
			{
				return consumedTime;
			}
			else
			{
				timerObj[todayTimer]['isTimerStart'] = "completed";
				timerObj[todayTimer]['hpEarnPopUp'] = 1;
				setChromeStorage(timerObj,1);
			}
}
function generateLeftTime(remainTime)
{
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		var leftTime = "";
		if(hour > 0)
		{
			leftTime = "Hours Left.";
		}
		else if(hour == 0 && minute > 0)
		{
			leftTime = "Minutes Left.";
		}
		else if(minute == 0 && second > 0)
		{
			leftTime = "Seconds Left.";
		}
		if(remainTime > 0)
		{
			var totalTime = hour+":"+minute
		}
		if($("#giveUpPopUp").html())
		{
			if(remainTime == 0)
			{
				$("#giveupLeftTime").html("Completed");
			}
			else
			{
				$("#giveupLeftTime").html(totalTime+" <span style='font-size:20px;'>"+leftTime+"</span>");
			}
		}
		if(remainTime == 0)
		{
				earnHealthPoints(function(reshtml){
						$("body").append(reshtml);
						timerObj[todayTimer]['isTimerStart'] = "completed";
						timerObj[todayTimer]['hpEarnPopUp'] = 1;
						setChromeStorage(timerObj,2);
						$("#gs_closePopUp").on("click",function(){
								$("#gs_hpPopUp").remove();
								timerObj[todayTimer]['hpEarnPopUp'] = "close";
								setChromeStorage(timerObj,2);
						});
				});
		}
		if(remainTime < 0)
		{
			clearInterval(runningClearIn);
		}
}
//inspectElementBlock();
function inspectElementBlock()
{
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});
	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
		console.log('You cannot inspect Element');
		 return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
		console.log('You cannot inspect Element');
		return false;
	  }
	} 
}
function userBoostNotification(typeMode)
{
	
	if(storageObj["todayTimer"] && storageObj["todayTimer"][todayTimer])
	{
		if(typeMode == 1) //deduct user typing word count
		{
			var readWordsCount = storageObj["todayTimer"][todayTimer]['readWordsCount'];
			var userReadW = storageObj["todayTimer"][todayTimer]['user_selected_words'];
			var chooseTypeWord = storageObj["todayTimer"][todayTimer]['chosen_typed_word'];
			if(is_running_time == 0 && (is_typed_word_count <= chooseTypeWord))
			{
				var convertMins = 1*60;
				notificationInterVal(convertMins,boostMode);
				is_running_time = 1;
				if(minsCantake < 1)
				{
					minsCantake = 1;
				}
			}
			else if(is_running_time == 1 && (is_typed_word_count >= chooseTypeWord))
			{
				is_typed_word = '';
				clearInterval(boostSetIn);
				is_running_time = 0;
			}
		}
		else if(typeMode == 2)// deduct user selected word count
		{
			clearInterval(boostSetIn);
			var userSeletedW = storageObj["todayTimer"][todayTimer]['user_selected_words'];
			var chooseSelWord = storageObj["todayTimer"][todayTimer]['chosen_selected_word'];
			minsCantake = Math.ceil(userSeletedW/chooseSelWord);
			var convertMins = minsCantake*60;
			notificationInterVal(convertMins,boostMode);
		}
	}
}
function notificationInterVal(convertMins,boostMode,takeMins)
{
		clearInterval(boostSetIn);
		var todaySpike = storageObj["todayTimer"][todayTimer]['today_strikes'];
		var boostTime = storageObj["todayTimer"][todayTimer]['total_boost_time'];
		var convertMins = convertMins;
		boostSetIn = setInterval(function(){
		var second = convertMins % 60;
		var minute = Math.floor(convertMins / 60) % 60;
		var hour = Math.floor(convertMins / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		if(minsCantake == minute && second == 0)
		{
				timerObj[todayTimer]['boost_countdown'] = new Date().getTime();
				timerObj[todayTimer]['is_StartWriteRead'] = 1;
				setChromeStorage(timerObj,2);
				minsCantake--;
		}
		if(minute == 0 && second == 20)
		{
			var options = {
				boostNotification:"boostNotification"
			  }
			chromeRuntimeSendMsg(options);
		}
		if(minute == 0 && second == 0)
		{
			var options = {
				spikes:"spikes"
			  }
			chromeRuntimeSendMsg(options);
			is_running_time = 0;
			timerObj[todayTimer]['user_selected_words'] = 0;
			timerObj[todayTimer]['is_StartWriteRead'] = 0;
			timerObj[todayTimer]['boost_countdown'] = 0;
			timerObj[todayTimer]['total_boost_time'] = 0;
			timerObj[todayTimer]['today_strikes'] = parseInt(todaySpike+1);
			
			clearInterval(boostSetIn);
		}
		convertMins--;
	},1000);
}
function activeTabWin()
{
	getChromeStorageItems(1);
}
function styleTag()
{
	var css = '::selection {color: red;background: orange;}';
    var head = document.getElementsByTagName('head')[0];
    var style = document.createElement('style');
	head.appendChild(style);
	style.type = 'text/css';
	style.appendChild(document.createTextNode(css));
}
window.onfocus = function() { activeTabWin(1);}
window.onblur = function() { setChromeStorage(timerObj)}
document.focus = window.focus;
activeTabWin();
}());