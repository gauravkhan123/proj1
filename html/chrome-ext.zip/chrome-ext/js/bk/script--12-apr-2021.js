var timer;

var currentTime = new Date();
var startTime = "";
var runningSecond = '';
var timerObj = {};
var time ='';
var setHoursCount ='';
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
var todayTimer = "timer_"+ dd + '/' + mm + '/' + yyyy;
var isTimer = "";
var totalActivity = 0;
var getTypedCount = 0;
var getReadCount = 0;
var readingTime = 1;
var writingTime = 1;
var baseUrl = "https://development.brstdev.com";
var isMode = '';
var storageObj = '';
var isCallbackDone = 0;
var isTimerType = ''; 
var progressBarCount = 59;
var progressSetIn = '';
var is_running_boost_time = 0;
var is_StartWriteRead = 0;
var hslColor = "hsl(63, 100%, 50%)";
timerObj[todayTimer] = {
	"startTime":"",
	"totalActivity":0,
	"isTimerStart":"",
	"funTab":'',
	"isFunTabPopUp":0,
	"currentTab":0,
	"isFunTabBrowsers":0,
	"targetTime":0,
	"isTimePause":0,
	"isMode":'',
	"typedWordsCount":0,
	"readWordsCount":0,
	"hpEarnPopUp":0,
	"funPopUpStartTime":0,
	'giveUp':0,
	'is_StartWriteRead':0,
	'today_strikes':0,
	'user_selected_words' :0,
	'user_typed_words':0,
	'chosen_selected_word':20,
	'chosen_typed_word':20,
	'is_pause_boost':0,
	'boost_countdown':0,
	'is_flame_start':0,
	'total_boost_time':0
}
getItemsFun();
$(".gs_loader").show();
$(document).ready(function () {
	
	setTimeout(function(){
		chrome.storage.sync.get(["loginUser"], function(items)
		{
			if(items && items['loginUser'] && items['loginUser']['email'])
			{
				var params = items['loginUser'];
				params['extId'] = chrome.runtime.id;
				userSignUp(params,function(res){
					if(res['isLogin'] == true)
					{
						userInfo(res);
					}
					else
					{
						$(".loginWithG-mail").show();
						$(".gs_loader").hide();
					}
					
				});
			}
			else
			{
				$(".gs_loader").hide();
				$(".loginWithG-mail").show();
			}
			
		});	
	},1000);
	$(".loginWithG-mail").hide();
	 $('#loginWithGMail').on('click', function() {
		 
			if($("#agreeWithTerm").is(":checked"))
			{
				$(".gs_loader").show();
				load();
			}
			else
			{
				$(".agreeGSTerms").css({"border":"1px solid red"});
			}
	 });
	 $('#gs_flame').on('click', function() {
			var getTimerType = $(this).attr("type");
			if(getTimerType == undefined)
			{
				return false;
			}
			var _this = this;
			var items = storageObj;
			var is_pause_boost = '';
			var isTimePause = '';
			if(items != undefined && items !='')
			{
					if(items["todayTimer"] && items["todayTimer"][todayTimer])
					{
						is_pause_boost  = items["todayTimer"][todayTimer]['is_pause_boost'];
						isTimePause  = items["todayTimer"][todayTimer]['isTimePause'];
					}
			}
			if(getTimerType !="")
			{
				if(getTimerType == "start")
				{
					$(this).attr("type","stop");
					$(".gs_startStop").hide();
					$(".gs_activity-section").show();
				}
				else
				{
						var items = storageObj;
						if(items["todayTimer"] && items["todayTimer"][todayTimer])
						{
							var isTimerOn = items["todayTimer"][todayTimer]['isTimerStart'];
							isTimer = isTimerOn;
							console.log(items["todayTimer"][todayTimer]['isTimePause']);
							if(isTimerOn !="" && isTimerOn=="yes")
							{
								if(items["todayTimer"][todayTimer]['isTimePause'] == 0)
								{
									chrome.storage.sync.get(["currentRoutineActive"], function(activeItems){
										if(activeItems["currentRoutineActive"] && activeItems["currentRoutineActive"][todayTimer])
										{
											var is_routineActive = activeItems["currentRoutineActive"][todayTimer]['is_routineActive'];
											if(is_routineActive == 1)
											{
												if(confirm('Your routine already running, do you want to stop!')) 
												{
													var routineTargetObj = {};
													routineTargetObj[todayTimer] = {"is_routineActive":0};
													chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ });
													setChromeStorage(items,"stop");
												}
											}
											else
											{
												if(confirm('You are only allowed to have one pause a day so choose it wisely. do you want to take a pause!')) 
												{
													setChromeStorage(items,"stop");
												}
											}
										}
										else
										{
											if(confirm('You are only allowed to have one pause a day so choose it wisely. do you want to take a pause!')) 
											{
												setChromeStorage(items,"stop");
											}
										}
								});
								}
								else if(items["todayTimer"][todayTimer]['isTimePause'] == 1)
								{
									chrome.storage.sync.get(["currentRoutineActive"], function(activeItems){
										if(activeItems["currentRoutineActive"] && activeItems["currentRoutineActive"][todayTimer])
										{
											var is_routineActive = activeItems["currentRoutineActive"][todayTimer]['is_routineActive'];
											if(is_routineActive == 1)
											{
												if(confirm('Your routine already running, do you want to stop!')) 
												{
													var routineTargetObj = {};
													routineTargetObj[todayTimer] = {"is_routineActive":0};
													chrome.storage.sync.set({"currentRoutineActive": routineTargetObj},function(){ });
													setChromeStorage(items,"stop");
												}
											}
											else
											{
												if(confirm('You have already consumed your one allowed pause and now if you give up then you will lose your daily health points!')) 
												{
													dailyHealthPoints(0);
													setChromeStorage(items,"stop");
												}
											}
										}
										else
										{
												if(confirm('You have already consumed your one allowed pause and now if you give up then you will lose your daily health points!')) 
												{
													dailyHealthPoints(0);
													setChromeStorage(items,"stop");
												}
										}
									});
										
								}
								else
								{
									setChromeStorage(items,"stop");
								}
									
							}
							else
							{
								time = setHoursCount;
							}
						}
				}
		}
	 });
		 $('.gs_start_activity').on('click', function() {
				$(".gs_start_activity").removeAttr("style");
				$(this).css("border","2px solid #000");
				var getType = $(this).attr("type-mode");
				timerObj[todayTimer]['isMode'] = getType;
				timerObj[todayTimer]['startTime'] = new Date().getTime();
				timerObj[todayTimer]['totalActivity'] = totalActivity;
				if(totalActivity > 1)
				{
					timerObj[todayTimer]['funPopUpStartTime'] = 0;
					
				}
				else
				{
					timerObj[todayTimer]['funPopUpStartTime'] = new Date().getTime();
				}
				timerObj[todayTimer]['isTimerStart'] = "yes";
				if(getType == "boost")
				{
					var items = storageObj;
					if(items != undefined && items !='')
					{
						if(items["todayTimer"] && items["todayTimer"][todayTimer])
						{
							var is_pause_boost  = items["todayTimer"][todayTimer]['is_pause_boost'];
							if(is_pause_boost > 1)
							{
								alert('You can not start boost mode again. you have already exceed pause limit');
							}
							else
							{
								hideShowTimerBoostEvent();
								$(".timerMode").hide();
								$(".boostMode").show();
								timerObj[todayTimer]['startTime'] = "";
								chromeStorageSetObj(timerObj);
							}
						}
					}
					else
					{
						hideShowTimerBoostEvent();
						$(".timerMode").hide();
						$(".boostMode").show();
						timerObj[todayTimer]['startTime'] = "";
						chromeStorageSetObj(timerObj);
					}
				}
				else
				{
					hideShowTimerBoostEvent();
					chromeStorageSetObj(timerObj);
				}
		 });
		 $('#gs_goBack').on('click', function() {
				$(".gs_startStop").show();
				$(".gs_activity-section").hide();
				$('#gs_flame').attr("type","start");
		 });
		 $('#settingIcon').on('click', function() {
			 var extId = chrome.runtime.id;
			  chrome.tabs.create({
					url: baseUrl+'/productivitystimulus/setting/index'
				});
		 });
		 $('#gs-play-pause').on('click', function() {
				var items = storageObj;
				if(items != undefined)
				{
					if(items["todayTimer"] && items["todayTimer"][todayTimer])
					{
						var is_pause_boost = items["todayTimer"][todayTimer]['is_pause_boost'];
						if(is_pause_boost == 0)
						{
							if(confirm('You are only allowed to have one pause a day so choose it wisely. do you want to take a pause!')) 
							{
								 $(".boostMode").hide();
								 $(".gs_step1").show();
								timerObj[todayTimer]['is_pause_boost'] = parseInt(timerObj[todayTimer]['is_pause_boost']+1);
								setChromeStorage(storageObj,'stop');
							}
						}
						else if(is_pause_boost == 1)
						{
							if(confirm('You have already consumed your one allowed pause and now if you give up then you will lose your daily health points!')) 
							{
								$(".boostMode").hide();
								$(".gs_step1").show();
								dailyHealthPoints(0);
								timerObj[todayTimer]['is_pause_boost'] = parseInt(timerObj[todayTimer]['is_pause_boost']+1);
								setChromeStorage(storageObj,'stop');
							}
						}
					}
				} 
				
		 });
		 $('.gs_activityReward').on('click', function() {
				 var title = $(this).attr("title");
				 var redirect = "";
				 if(title == "Social")
				 {
					 redirect = "social/index";
				 }
				 else if(title == "Goals")
				 {
					 redirect = "goals/routine";
				 }
				 else if(title == "Mystery Box")
				 {
					  redirect = "mystery/index";
				 }
				 chrome.tabs.create({
					url: baseUrl+'/productivitystimulus/'+redirect
				});
		 });
});
function hideShowTimerBoostEvent()
{
			$(".timer_left").hide();
			$("#gs_stopGrowing").show();
			$(".gs_meterProgress").hide();
			$(".gs_startStop").show();
			$(".gs_activity-section").hide();
			$(".timer_left font-title").html("<timer id='gs_remainTime'></timer>");
			$("#gs_startGrowing").hide();
}
function setChromeStorage(items,isTimer)
{
			var timerStart = items["todayTimer"][todayTimer]['startTime'];
			var isMode = items["todayTimer"][todayTimer]['isMode'];
			console.log(isMode);
			if(timerStart > 0 && timerStart !="")
			{
				var params = {};
				var delta = getTimeDiff(timerStart);
				params['extId'] = chrome.runtime.id;
				params['productivity'] = delta;
				productivityTime(params,function(res){
					console.log(res);
				});
				totalActivity = Math.floor(delta + totalActivity);
				timerObj[todayTimer]['totalActivity'] = totalActivity;
			}
			if(isMode == "timer")
			{
				timerObj[todayTimer]['isTimePause'] =  Math.floor(items["todayTimer"][todayTimer]['isTimePause'] + 1);
			}
			timerObj[todayTimer]['startTime'] = "";
			timerObj[todayTimer]['isTimerStart'] = isTimer;
			timerObj[todayTimer]['isMode'] =  "";
			chromeStorageSetObj(timerObj);
			getItemsFun();
}
function chromeStorageSetObj(timerObj)
{
	chrome.storage.sync.set({"todayTimer": timerObj},function(){ getItemsFun();});	
}
function getSetStorageItems()
{
		var items = storageObj;
		if(items != undefined)
		{
			if(items["todayTimer"] && items["todayTimer"][todayTimer])
			{
				timerObj[todayTimer] = items["todayTimer"][todayTimer];
			}
		}
}
function load() {
    var method = 'GET'
    var url = 'https://www.googleapis.com/userinfo/v2/me?alt=json';
    //var fields = encodeURIComponent("names,genders,birthdays,emailAddresses,photos");
    ///var url = 'https://people.googleapis.com/v1/people/me?personFields=' + fields;
    authenticateRequest(method, url, function(err, response) {
        if (err) {
			alert('authenticateRequest Err >>' + err);
			$(".gs_loader").hide();
            console.log('authenticateRequest Err >>', err);
            return;
        }
		chrome.storage.sync.set({"loginUser": response},function(){
				var params = response;
				params['extId'] = chrome.runtime.id;
				var isSNl = 0;
				if($('#subscribeToNewsletter'))
				{
					if($('#subscribeToNewsletter').is(":checked"))
					{
						isSNl = 1;
					}
				}
				userSignUp(params,function(res){
					userInfo(res,isSNl);
				});	
		});
        //profile = response;
			
	});
       
}
function userInfo(res,isSNl)
{
		$(".gs_loader").hide();
		if(res && res.data && res.data['user_pic'])
		{
			$(".user-profile img").attr("src",res.data['user_pic']);
			$(".user-profile img").attr("title",res.data['username']);
			$(".user-status level").html("Level 0"+res.data['level']);
		}
		$(".agreeGSTerms").removeAttr("style");
		$(".loginWithG-mail").hide();
		$(".gs_step1").show();
		$(".timerMode").hide();
		var params = {};
		if(isSNl != undefined)
		{
			params['isSNl'] = isSNl;
		}
		getTargetTime(params,function(targetRes){
			var setTargetHours = targetRes.target;
				var splitH =  setTargetHours.split(" ");
				var setTime = splitH[0];
				if(setTime == 30)
				{
					setHoursCount = setTime*60;
				}
				else
				{
					setHoursCount = setTime*60*60;
				}
				timerObj[todayTimer]['targetTime'] = setHoursCount;
				timerObj[todayTimer]['funTab'] = targetRes.fun_tab;
				dailyHealthPoints(2);
				//getItemsFun();
				getSetStorageItems();
				if(isMode == "boost")
				{
					$(".boostMode").show();
					$(".timerMode").hide();
				}
				else
				{
					$(".timerMode").show();
				}
		});
}
function meterProgressLeftDays(target)
{
		var params = {};
		params['target'] = target;
		progressLeftDaysApi(params,function(pointsRes){
				$(".gs_meterProgress span").css("width",Math.round(pointsRes.hp));
				$(".gs_meterProgress days").html(pointsRes['left-days']);
			});
}
function dailyHealthPoints(is_up_down)
{
	var params = {};
	params['is_up_down'] = is_up_down;
	dailyHealthPointsApi(params,function(pointsRes){
		var hp = pointsRes.flameHp;
		$(".gs_growingPercent").html(hp+"/3 HP");
		var img = "icons/flame"+pointsRes.flameHp+".png";
		$(".gs_flame_image").attr("src",img);
		meterProgressLeftDays(is_up_down);
	})
}
function boostMode()
{
		var items = storageObj;
		if(items["todayTimer"] && items["todayTimer"][todayTimer])
		{
			var consumedTime = getConsumedTime(items);
			generateLeftTime(consumedTime);
		}
}
// Authenticate user account if not logged in then ask login and permission to read gmail messages
function authenticateRequest(method, url, callback) {
    getToken();

    function getToken() {
        chrome.identity.getAuthToken({
            interactive: true
        }, function(token) {
            if (chrome.runtime.lastError) {
                // chrome.identity.removeCachedAuthToken(token, function() {
                console.log("Cached token has been removed");
                callback(chrome.runtime.lastError.message);
                return;
                // });
            }
            authToken = token; // set token
            let init = {
                method: method,
                //async: true,
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                'contentType': 'json'
            };
            fetch(url, init).then((response) => {
                if (!response.ok) {
                    callback(response.statusText);
                } else {
                    return response.json();
                }
            }).then(function(data) {
                if (!data) {
                    callback('Request failed. Please try again.');
                } else if (data.error) {
                    chrome.identity.removeCachedAuthToken({
                        'token': token
                    }, getToken);
                } else {
                    callback(null, data);
                }
            }).catch((error) => {
                console.log('Error:', error);
                chrome.identity.removeCachedAuthToken({
                    'token': token
                }, getToken);
            });
        })
    }
}
function currentTime() {
    let today = new Date();
    let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    return time;
}
function ajaxCall(url,params,callback,errorcallback)
{
			
			jQuery.ajax({
				url: url,
				type: 'POST',
				data:params,
				dataType: 'json',
				success: function (data) {
					callback(data);
				},
				error: function (e) {
					errorcallback(e);
				}
			});
}
function errorcallback(error)
{
    if(window.console){ console.log(error); }
}
function userSignUp(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/user-sign-up";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function progressLeftDaysApi(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/progress-left-days";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function productivityTime(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/save-productivity-time";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function dailyHealthPointsApi(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/daily-health-points";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function getTargetTime(params,callback)
{
	 var url = baseUrl+"/productivitystimulus/site/setting";
     //var params = {};
	 ajaxCall(url,params,
			function(response)
			{ 
					 callback(response);
			},
			function(error){ errorcallback(error)}
	);
		
}
function timerHideShow(timerMode)
{
	if(isMode != "boost")
	{
		switch(timerMode) {
			  case"yes":
					$("#gs_flame").attr("type","stop");
					$("#gs_startGrowing").hide();
					$('#gs_stopGrowing').show();
					$(".gs_activity-section").hide();
					$(".timer_left").show();
					$(".gs_meterProgress").hide();
				break;
			  case "stop":
					$("#gs_flame").attr("type","start");
					$("#gs_startGrowing").show();
					$('#gs_stopGrowing').hide();
					$(".gs_activity-section").hide();
					$(".timer_left").hide();
					$(".gs_meterProgress").show();
				break;
				 case "completed":
					$('.timer_left').hide();
					$('.gs_meterProgress').show();
					$('#gs_startGrowing').html("Finished Today Activity");
					$('#gs_stopGrowing').remove();
					$('#gs_startGrowing').show();
					$('.gs_meterProgress').show();
					$('#gs_flame').attr("type","");
					$('#gs_flame').css("cursor","no-drop");
				break;
			  default:
		}
	}
	
}
function getTimeDiff(timerStart)
{
	var date1 = timerStart;
	var date2 = new Date();
	var delta = Math.abs(date2 - date1) / 1000;
	return delta;
}
function runningTimeInterval()
{
	
	var setIn = setInterval(function(){
					
					calculateLeftTime();
					if(isTimerType == "completed" || isTimerType =="stop")
					{
						clearInterval(setIn);
					}
		},1000);
}
function calculateLeftTime()
{
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		if(items["todayTimer"] && items["todayTimer"][todayTimer])
		{
			storageObj = items;
			if(items != undefined && items != "")
			{
				if(items["todayTimer"] && items["todayTimer"][todayTimer])
				{
					isMode = items["todayTimer"][todayTimer]['isMode'];
					var isTimerOn = items["todayTimer"][todayTimer]['isTimerStart'];
					var is_typedWrite = items["todayTimer"][todayTimer]['is_StartWriteRead'];
					if(is_typedWrite > 0)
					{
						is_StartWriteRead = 1;
					}
					var countDown = items["todayTimer"][todayTimer]['boost_countdown'];
					if(isMode == "timer" && isTimerOn == "yes")
					{
						var consumedTime = getConsumedTime(items);
						generateLeftTime(consumedTime);
					}
					if(is_StartWriteRead == 1 && isMode == "boost")
					{
						console.log(is_StartWriteRead);
						if(countDown != "")
						{
							    is_running_boost_time = 1;
								is_StartWriteRead = 0;
								clearInterval(progressSetIn);
								progressBarCount = 59 - Math.floor(getTimeDiff(countDown));
								timerObj[todayTimer] = items["todayTimer"][todayTimer];
								progrssBar();
						}
					}
				}
			}
		}
	});
}
function getItemsFun()
{
	//console.log("function is calling");
	var is_pause_boost = 0;
	var isTimePause = 0;
	chrome.storage.sync.get(["todayTimer"], function(items)
	{
		if(items["todayTimer"] && items["todayTimer"][todayTimer])
		{
			storageObj = items;
			timerObj[todayTimer] = items["todayTimer"][todayTimer];
			isMode = items["todayTimer"][todayTimer]['isMode'];
			var isTimerOn = items["todayTimer"][todayTimer]['isTimerStart'];
			totalActivity = items["todayTimer"][todayTimer]['totalActivity'];
			var today_strikes = items["todayTimer"][todayTimer]['today_strikes'];
			var boost_countdown = items["todayTimer"][todayTimer]['boost_countdown'];
			is_pause_boost = items["todayTimer"][todayTimer]['is_pause_boost'];
			isTimePause = items["todayTimer"][todayTimer]['isTimePause'];
			if(boost_countdown > 0)
			{
				is_StartWriteRead = 1;
			}
			if(isMode == "boost")
			{
				boostMode();
				var strikes = "("+today_strikes+" strike)";
				if(today_strikes > 1)
				{
					strikes = "("+today_strikes+" strikes)";
				}
				$(".gs_stricks").html(strikes);
				
			}
			if(isTimerOn == "yes")
			{
				runningTimeInterval();
			}
			isTimerType = isTimerOn;
			timerHideShow(isTimerOn);
		}
		else
		{
			timerHideShow('stop');
		}
		if(is_pause_boost > 1 && isTimePause > 1)
		{
				$(".gs_timerEvents").html('You exceed pause limit!');
				$('.gs_flame_image').css("cursor","no-drop");
				$('.gs_flame_image').removeAttr("type");
				$(".timer_left").hide();
				$(".gs_meterProgress").show();
		}
		
	});
}
function getConsumedTime(items)
{
			 var timerStart = Math.floor(items["todayTimer"][todayTimer]['startTime']);
			 var isTimerOn = items["todayTimer"][todayTimer]['isTimerStart'];
			 totalActivity = items["todayTimer"][todayTimer]['totalActivity'];
			 var getTypedCount = items["todayTimer"][todayTimer]['typedWordsCount'];
			 var getReadCount = items["todayTimer"][todayTimer]['readWordsCount'];
			 var targetTime = items["todayTimer"][todayTimer]['targetTime'];
			 isMode = items["todayTimer"][todayTimer]['isMode'];
			 var completedTime = 0;
			 var totalReadTypedT = 0;
			 if(getTypedCount > 1 || getReadCount > 1)
			 {
				var getReadWriteTime = 0;
				var getTypedTime = 0;
				if(getTypedCount > 1)
				{
					getTypedTime = getTypedCount/20;
				}
				if(getReadCount > 1)
				{
					getReadWriteTime = getReadCount/20;
				}
				totalReadTypedT = parseInt(getTypedTime+getReadWriteTime)*60;
			}
			var consumedTime = parseInt(totalReadTypedT + totalActivity);
			if(timerStart !="")
			{
				consumedTime = parseInt(getTimeDiff(timerStart)+totalReadTypedT + totalActivity);
			}
			//targetTime = 10*60;
			consumedTime = targetTime - consumedTime;
			return consumedTime;
}
function generateLeftTime(remainTime)
{
		$(".timer_left font-title").html("<timer id='gs_remainTime'></timer>");
		$(".timer_left").show();
		$(".gs_meterProgress").hide();
		var second = remainTime % 60;
		var minute = Math.floor(remainTime / 60) % 60;
		var hour = Math.floor(remainTime / 3600) % 60;
		second = (second < 10) ? '0'+second : second;
		minute = (minute < 10) ? '0'+minute : minute;
		hour = (hour < 10) ? '0'+hour : hour;
		console.log(hour,minute,second);
		var leftTime = "";
		if(hour > 0)
		{
			leftTime = "Hours Left.";
		}
		else if(hour == 0 && minute > 0)
		{
			leftTime = "Minutes Left.";
		}
		else if(minute == 0 && second > 0)
		{
			leftTime = "Seconds Left.";
		}
		if(remainTime > 0)
		{
			var totalTime = hour+":"+minute;
			$('#gs_remainTime').html(totalTime +" "+ leftTime);
		}
		else if(remainTime == 0 && minute == 0 && second == 0)
		{
			timerObj[todayTimer]['isTimerStart'] = "completed";
			chromeStorageSetObj(timerObj);
			dailyHealthPoints(1);
		}
		else if(remainTime < 0)
		{
			timerObj[todayTimer]['isTimerStart'] = "completed";
			chromeStorageSetObj(timerObj);
			dailyHealthPoints(1);
		}
}
function progrssBar()
{
	if(progressBarCount == 59)
	{
		makeProgressCircle();
	}
	timerObj[todayTimer]['is_StartWriteRead'] = 0;
	chrome.storage.sync.set({"todayTimer": timerObj},function(){});
	var count = $(('#count'));
	if(progressBarCount == 0)
	{
		boostMode();
	}
	count.text(progressBarCount);
	progressSetIn = setInterval(function(){
		var perVal = 100*progressBarCount/59;
		progress(perVal);
		if(progressBarCount == 0)
		{
			boostMode();
			is_running_boost_time = 0;
			clearInterval(progressSetIn);
			setTimeout(function(){
				getItemsFun();
			},1000);
		}
		count.text(progressBarCount);
		progressBarCount--;
	},1000);
}

const SVG_NS = 'http://www.w3.org/2000/svg';
const CIRCUMFERENCE = base.getTotalLength()
const UNIT = CIRCUMFERENCE / 100;
let circles=[];//the array of circles

//create 100 circles each with a different fill color to create the illusion of a gradient
function makeProgressCircle()
{
	for(let i = 0; i<100; i++)
	{
		hslColor = "hsl("+i+", 100%, 50%)";
		let pos = base.getPointAtLength(i*UNIT);
		let o = {cx:pos.x,cy:pos.y,r:5,'fill-opacity':0,fill:hslColor}
		circles.push(drawCircle(o, progress__value));  
	}
}
makeProgressCircle();
progress(100);

//control.addEventListener('input', progress);

function progress(circleVal){
  let val = circleVal;
  for(let i = 0; i<circles.length; i++){
    if(i<=val){
		circles[i].setAttributeNS(null,'fill-opacity',1)    
		//circles[i].setAttributeNS(null,'fill',hslColor)    
    }else{
		circles[i].setAttributeNS(null,'fill-opacity',0)
    }
  } 
}

// a function to create a circle
function drawCircle(o, parent) {
  var circle = document.createElementNS(SVG_NS, 'circle');
  for (var name in o) {
    if (o.hasOwnProperty(name)) {
      circle.setAttributeNS(null, name, o[name]);
    }
  }
  parent.appendChild(circle);
  return circle;
}
//datediff(parseDate(first.value), parseDate(second.value)));